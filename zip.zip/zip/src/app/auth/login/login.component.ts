import { Component, OnInit, inject } from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService, routes } from 'src/app/core/core.index';
import { LocalConstant } from 'src/app/core/helpers/constants/local.constant';
import { PasswordValidator } from 'src/app/core/helpers/constants/pattern.constant';
import { LocalService } from 'src/app/core/services/local/local.service';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { EmployeeService } from 'src/app/feature-module/employee/employees/employee.service';
import { MonthlyChartService } from 'src/app/feature-module/monthly-chart/monthly-chart/service/monthly-chart.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  private toast = inject(ToasterService);
  private employeeService = inject(EmployeeService);
  changePasswordForm!: FormGroup;
  isChangePasswordModalOpen: boolean = false;
  public employeeId: string = '';
  public userId: string = '';
  public companyId: string = '';
  public accountId: string = '';
  public locationId: string = '';
  public routes = routes;
  loginForm!: FormGroup;
  searchForm!: FormGroup;
  password: boolean[] = [false];
  isSubmitted: boolean = false;
  isLoading: boolean = false;

  private localService = inject(LocalService);
  private router = inject(Router);
  private authService = inject(AuthService);
  private fb = inject(FormBuilder);
  private monthlyChartService = inject(MonthlyChartService);

  constructor() {
    // let userData = JSON.parse(localStorage.getItem('authObj') || '');
    // this.employeeId = userData?.employeeId;
    // this.userId = userData?.employeeId;
  }

  ngOnInit(): void {
    this.changePasswordForm = this.fb.group(
      {
        // newPassword: ['', [Validators.required,  PasswordValidator.validate()]],
        // newPassword: ['', [Validators.required, this.passwordMatchValidator]],
        // confirmPassword: ['', [Validators.required,]],
      }
      // { validators: this.passwordMatchValidator } // Attach custom validator
    );
    this.initForms();
  }
  // Open the modal
  openChangePasswordModal(): void {
    this.isChangePasswordModalOpen = true;
  }

  // Close the modal
  closeChangePasswordModal(): void {
    this.isChangePasswordModalOpen = false;
  }

  // Custom validator to check if passwords match
  passwordMatchValidator(group: FormGroup) {
    const newPassword = group.get('newPassword')?.value;
    const confirmPassword = group.get('confirmPassword')?.value;
    return newPassword === confirmPassword ? null : { passwordMismatch: true };
  }

  // Submit form
  onChangePassword(): void {
    if (this.changePasswordForm.invalid) return;

    const { newPassword } = this.changePasswordForm.value;

    // this.employeeService.changePassword(newPassword, this.employeeId, this.userId).subscribe({
    //   next: (res: any) => {
    //     this.toast.typeSuccess('Password changed successfully!')
    //     this.closeChangePasswordModal();
    //     this.changePasswordForm.reset();
    //   },
    //   error: (err) => {
    //     this.toast.typeSuccess('Failed to change password. Please try again.')
    //   },
    // });
  }
  // Initialize both forms
  initForms(): void {
    // Login form
    this.loginForm = this.fb.group({
      email: ['', [Validators.required]],
      password: ['', [Validators.required]],
    });

    // Search form
    // const currentMonth = new Date().toISOString().slice(0, 7);
    // this.searchForm = this.fb.group({
    //   accountID: [''],
    //   locationID: [''],
    //   employeeID: [''],
    //   startDate: [''],
    //   endDate: [''],
    //   ip: ['192.168.1.1'], // Default IP for now
    //   userId: [''],
    //   selectedMonth: [currentMonth], // Default to current month
    // });
  }

  // Get login form controls
  get c(): { [key: string]: AbstractControl } {
    return this.loginForm.controls;
  }

  // Login logic
  Login(): void {
    if (this.loginForm.invalid) return;
    this.isLoading = true;
    this.isSubmitted = true;
    const payload = {
      userName: this.loginForm.value.email,
      password: this.loginForm.value.password,
    };

    this.authService.login(payload).subscribe(
      (response: any) => {
        if (response && response?.statusCode < 399) {
          const userData: any = response.data;

          localStorage.setItem('authObj', JSON.stringify(response.data));
          localStorage.setItem('bearerToken', response.data?.bearerToken);

          this.localService
            .setLocalData(
              LocalConstant.ROLE,
              userData.userType ? userData.userType : 'USER'
            )
            .subscribe((roleSuccess) => {
              if (roleSuccess) {
                this.localService
                  .setLocalData(LocalConstant.USER_DATA, userData)
                  .subscribe((userDataSuccess) => {
                    if (userDataSuccess) {
                      // Redirect after login
                      this.router.navigate([
                        userData.userType === 'SUPER_ADMIN'
                          ? routes.adminDashboard
                          : routes.employee,
                      ]);
                      this.toast.typeSuccess('Login successfully!');
                      this.fetchData(userData);
                      // Fetch data automatically after successful login
                    } else {
                      this.isLoading = false;
                      this.fetchData(userData);
                      this.router.navigate([routes.login]);
                    }
                  });
              } else {
                this.isLoading = false;
                this.router.navigate([routes.login]);
              }
            });
        } else {
          this.isLoading = false;
          this.toast.typeError(response?.message);
        }
      },
      (error) => {
        this.toast.typeError(error?.message);
        this.isLoading = false;
      }
    );
  }
  // fetchData(data:any): void {
  //   const now = new Date();
  //  const startDate = new Date(now.getFullYear(), now.getMonth(), 1); // First day of current month
  //  const endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0); // Last day of current month

  //  const payload = {
  //    accountID: data.accountId || '', // Ensure fallback if `accountId` is missing
  //    locationID: data?.employeeLocation?.[0]?.locationId || '', // Safely access nested properties
  //    employeeID: data.employeeId || '',
  //    startDate: startDate.toISOString(),
  //    endDate: endDate.toISOString(),
  //    ip: data.ip || '192.168.1.1', // Use passed IP if available; otherwise default
  //    userId: data.employeeId || '',
  //  };

  //      this.monthlyChartService.getMonthlyChartData(payload).subscribe(
  //        (response) => {
  //          this.toast.success('Data fetched successfully!');
  //        },

  //      );

  //  }

  // Fetch data method
  fetchData(data: any): void {
    const now = new Date();
    const startDate = new Date(now.getFullYear(), now.getMonth(), 1); // First day of current month
    startDate.setHours(0, 0, 0, 0); // Set time to 00:00:00 for consistency
    const endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0); // Last day of current month

    // Helper function to format the date as "01 Dec 2024"
    const formatDate = (date: Date): string => {
      const year = date.getFullYear();
      const monthNames = [
        'Jan',
        'Feb',
        'Mar',
        'Apr',
        'May',
        'Jun',
        'Jul',
        'Aug',
        'Sep',
        'Oct',
        'Nov',
        'Dec',
      ];
      const month = monthNames[date.getMonth()]; // Get the abbreviated month name
      const day = String(date.getDate()).padStart(2, '0'); // Ensure 2 digits for the day
      return `${day} ${month} ${year}`;
    };

    // Convert both startDate and endDate to the desired format
    const formattedStartDate = formatDate(startDate);
    const formattedEndDate = formatDate(endDate);

    const payload = {
      accountID: data.accountId,
      locationID: data.employeeLocation[0].locationId,
      employeeID: data.employeeId,
      startDate: formattedStartDate,
      endDate: formattedEndDate,
      ip: data.ip || '192.168.1.1',
      userId: data.employeeId,
    };

    // Call your service to fetch data
    this.monthlyChartService
      .getMonthlyChartData(payload)
      .subscribe((response) => {
        // this.toast.success('Data fetched is successfully!');
      });
  }

  // Toggle password visibility
  public togglePassword(index: any) {
    this.password[index] = !this.password[index];
  }
}
