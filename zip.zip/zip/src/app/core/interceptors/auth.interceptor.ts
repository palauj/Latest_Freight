import { inject, Injectable } from '@angular/core';
import {HttpInterceptor,HttpRequest,HttpHandler,HttpEvent} from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { LocalConstant } from '../helpers/constants/local.constant';
import * as CryptoJS from 'crypto-js';
import { environment } from 'src/environments/environment';
import { CommonService } from '../services/common/common.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  constructor(
    private router: Router, 
    private toastrService: ToastrService
  ){}
  secretKey = environment.secretKey;
  private commonService = inject(CommonService);

  intercept(req: HttpRequest<any>,next: HttpHandler): Observable<HttpEvent<any>> {
    let userData: any;
    const encryptData = localStorage.getItem(LocalConstant.USER_DATA) || '';
    const decryptData = CryptoJS.AES.decrypt(
      encryptData,
      this.secretKey
    ).toString(CryptoJS.enc.Utf8);

    if (this.commonService.isValidJson(decryptData)) {
      userData = JSON.parse(decryptData);
    }
    if (
      !userData?.userType ||
      !userData?.bearerToken
    ) {
      return next.handle(req);
    }

    const req1 = req.clone({
      headers: req.headers.set(
        'Authorization',
        `Bearer ${userData?.bearerToken}`
      ),
    });

    return next.handle(req1).pipe(
      tap(
        () => { },
        (err: any) => {
          if (err) {
          // if (err instanceof HttpErrorResponse) {
            if (err.status === 401) {
              localStorage.clear();
              this.router.navigate(['login']);
            } else if (err.error) {
              this.toastrService.error(err?.error);
            } else {
              this.toastrService.error(err.message, "", {
                enableHtml: true
              });
            }
          }
        }
      )
    );
  }
}
