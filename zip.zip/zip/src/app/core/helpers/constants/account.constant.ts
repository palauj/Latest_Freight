export const StepsData = {
  steps: [
    {
      id: 1,
      stepTitle: 'Basic Details',
      iconClass: 'la la-user-tie',
      isStepCompleted: false,
    },
    {
      id: 2,
      stepTitle: 'Address',
      iconClass: 'la la-map-marker',
      isStepCompleted: false,
    },
    {
      id: 3,
      stepTitle: 'Locations',
      iconClass: 'la la-map-marked-alt',
      isStepCompleted: false,
    },
    {
      id: 4,
      stepTitle: 'Social Profiles',
      iconClass: 'la la-icons',
      isStepCompleted: false,
    },
    {
      id: 5,
      stepTitle: 'Access',
      iconClass: 'la la-images',
      isStepCompleted: false,
    },
    {
      id: 6,
      stepTitle: 'License',
      iconClass: 'fas fa-id-badge',
      isStepCompleted: false,
    },
  ],
};
