export class ProjectConstant {
  public static relatedTo = 'PRO';
  public static relatedToName = 'Project';
}
export class TaskConstant {
  public static relatedTo = 'TSK';
  public static relatedToName = 'Tasks';
}
export class AccountConstant {
  public static relatedTo = 'ACN';
  public static relatedToName = 'Account';
}
export class ClientConstant {
  public static relatedTo = 'CLT';
  public static relatedToName = 'Clients';
}
export class CompanyConstant {
  public static relatedTo = 'CMP';
  public static relatedToName = 'Company';
}
export class DocumentConstant {
  public static relatedTo = 'DOC';
  public static relatedToName = 'Document';
}
export class OutSourceClientConstant {
  public static relatedTo = 'OSC';
  public static relatedToName = 'OutSourceClients';
}
export class CandidateConstant {
  public static relatedTo = 'CND';
  public static relatedToName = 'Candidates';
}
export class ServiceRequestConstant {
  public static relatedTo = 'SRN';
  public static relatedToName = 'ClientsServiceRequest';
}
export class VenderConstant {
  public static relatedTo = 'VEN';
  public static relatedToName = 'Venders';
}
export class EmployeeConstant {
  public static relatedTo = 'EMP';
  public static relatedToName = 'Employee';
}
export class LeadConstant {
  public static relatedTo = 'LED';
  public static relatedToName = 'Lead';
}

export class EmailConstant {
  public static relatedTo = 'EML';
  public static relatedToName = 'Emails';
}

export class UserConstant {
  public static relatedTo = 'USR';
  public static relatedToName = 'Users';
}
export class ConsultantAgencyConstant {
  public static relatedTo = 'USR';
  public static relatedToName = 'Users';
}

export class AssetsConstant {
  public static relatedTo = 'INV';
  public static relatedToName = 'Assets';
}

export class PlanPackagesConstant {
  public static relatedTo = 'PKG';
  public static relatedToName = 'PlanPackages';
}

export class TicketConstant {
  public static relatedTo = 'TCK';
  public static relatedToName = 'Ticket';
}

export const LeadLookups = {
  LeadSourceLookUPId: '63cbc956-0329-45fa-aa57-8362d42754b9',
  LeadTypeLookUPId: '1eb322a9-d73e-4c10-9967-932462cdc50f',
  LeadPriorityLookUPId: 'ce0033f2-3e33-46e2-baaf-5593312f62e8',
};

export const LeaveLookups = {
  leaveTypeLookUpId: '2cd3037a-606f-42dd-99d3-adf6bc280727',
};

export const TimesheetLookups = {
  timesheetTypeLookUpId: '28035760-6208-4c1f-8f40-db7256551841',
};

export const StatusLookUps = {
  statusLookUpId: 'de14784d-7ce3-4f40-8e86-2817b1e1109',
};

export const CompanyDomainLookUps = {
  domainLookUpId: 'be6c242e-7801-421d-bca8-e82079fb848e',
};
export const AssetsDomainLookUps = {
  domainLookUpId: 'c9c7bbad-ddf7-40b1-aed9-6850d4341108',
};

export const LeadCompanyCategoryLookUps = {
  categoryLookUpId: '3d31bc15-0fbe-4064-919f-fbf7daad2c3e',
};
export const LeadPriorityLookUps = {
  priorityLookUpId: 'ce0033f2-3e33-46e2-baaf-5593312f62e8',
};
export const TravelModeLookUps = {
  travelModeLookUpId: '8656350d-a867-4286-8ea6-5df3ef153127',
};
export const EmployeeTypeLookUps = {
  employeeTypeLookUpId: '47fe0198-a703-4a9e-b3af-30e52e71e488',
};
export const CompanyCategoryLookUps = {
  companyCategoryLookUpId: '3d31bc15-0fbe-4064-919f-fbf7daad2c3e',
};
export const ProjectModelLookUps = {
  projectModelLookUpId: 'c8a918e2-09d6-4c10-b986-d1fc53c9084a',
};
export const GetDropdownForStatusMasterSubLookUpId = {
  StatusMasterSubLookUpId: '05cd7bed-aa20-4d35-8fc5-293e3cbc9d7d',
};
export const GetDropdownForCommonServiceMasterSubLookUpId = {
  CommonServiceSubLookUpId: '7cb91dbe-73d5-4430-aa59-788baa724f86',
};
export const TicketsModuleLookUps = {
  ticketModelLookUpId: '1c20ee4d-8373-483b-83e4-cc2e12f04ad3',
};
export const CandidateModuleLookUps = {
  candidateModelLookUpId: '071e3915-4619-48f7-9e6a-1a73921f5ab1',
};
export const HeaderCountName = {
  Total: 'Total',
  Active: 'Active',
  InActive: 'In-Active',
  srCount: 'Service Request',
  ServiceRequest: 'Service Request',
  InProgress: 'In-Progress',
  Deferred: 'Deferred',
  Open: 'Open',
  Close: 'Close',
  Project: 'Project',
  Location: 'Location',
  Probation: 'Probation',
  Consultant: 'Consultant',
  Contract: 'Contract',
  Permanent: 'Permanent',
  Weekend: 'Weekend',
  Holiday: 'Holiday',
  WorkingDays: 'Working Days',
  Pending: 'Pending',
  Reject: 'Reject',
  Approved: 'Approved',
  New: 'New',
  WorkItem: 'Work Item',
  Amc: 'Amc',
  WarrantyExpired: 'WarrantyExpired',
  UnderWarranty: 'UnderWarranty',
};
