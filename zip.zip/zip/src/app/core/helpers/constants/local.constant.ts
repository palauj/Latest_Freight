export class LocalConstant {
  public static ROLE = 'role';
  public static USER_DATA = 'user-data';
}
