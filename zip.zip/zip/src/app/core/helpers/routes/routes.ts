import { BehaviorSubject } from 'rxjs';

export class routes {
  public static layoutDirection: BehaviorSubject<string> =
    new BehaviorSubject<string>(localStorage.getItem('rtl') || '');
  private static Url = '';
  static rtl = this.layoutDirection.subscribe((res: string) => {
    this.Url = res;
  });

  public static get baseUrl(): string {
    return this.Url;
  }
  public static get login(): string {
    return this.baseUrl + '/login';
  }
  public static get forgot_password(): string {
    return this.baseUrl + '/forgot-password';
  }
  public static get register(): string {
    return this.baseUrl + '/register';
  }
  public static get lock_screen(): string {
    return this.baseUrl + '/lock-screen';
  }
  public static get dashboard(): string {
    return this.baseUrl + '/dashboard';
  }
  public static get baseUi(): string {
    return this.baseUrl + '/base-ui';
  }

  public static get admin(): string {
    return this.baseUrl + '/dashboard/admin';
  }
  public static get employee(): string {
    return this.baseUrl + '/admin/dashboard/employee';
  }

  public static get apps(): string {
    return this.baseUrl + '/admin/apps';
  }
  public static get chat(): string {
    return this.baseUrl + '/admin/chart/monthly-chart';
  }
  public static get consultant(): string {
    return this.baseUrl + '/admin/consultant';
  }
  public static get voicecall(): string {
    return this.baseUrl + '/admin/apps/voice-call';
  }
  public static get videocall(): string {
    return this.baseUrl + '/admin/apps/video-call';
  }
  public static get outgoingcall(): string {
    return this.baseUrl + '/admin/apps/outgoing-call';
  }
  public static get incomingcall(): string {
    return this.baseUrl + '/admin/apps/incoming-call';
  }
  public static get contacts(): string {
    return this.baseUrl + '/admin/apps/contacts';
  }
  public static get employeeManagement(): string {
    return this.baseUrl + '/admin/employee-management';
  }
  public static get management(): string {
    return this.baseUrl + '/admin/employee-management/management';
  }
  public static get employeerecord(): string {
    return this.baseUrl + '/admin/employee-management/emp-record';
  }
  public static get employeedirectory(): string {
    return this.baseUrl + '/admin/employee-management/emp-directory';
  }
  public static get employeesdocument(): string {
    return this.baseUrl + '/admin/employee-management/emp-document';
  }
  public static get confirmation(): string {
    return this.baseUrl + '/admin/onboarding/confirmation';
  }
  public static get interviewFeedback(): string {
    return this.baseUrl + '/admin/onboarding/interview-feedback';
  }
  public static get multiPayroll(): string {
    return this.baseUrl + '/admin/onboarding/multi-payroll';
  }
  public static get payrollConfirguration(): string {
    return this.baseUrl + '/admin/onboarding/payroll-confirguration';
  }
  public static get taskAutomation(): string {
    return this.baseUrl + '/admin/onboarding/task-automation';
  }
  public static get checklistManagement(): string {
    return this.baseUrl + '/admin/onboarding/onboarding-checklist';
  }
  public static get hirePortal(): string {
    return this.baseUrl + '/admin/onboarding/hire-portal';
  }
  public static get reporting(): string {
    return this.baseUrl + '/admin/onboarding/reporting-analytics';
  }
  public static get document(): string {
    return this.baseUrl + '/admin/onboarding/document-verify';
  }
  public static get appointment(): string {
    return this.baseUrl + '/admin/onboarding/appointment';
  }

  public static get calendar(): string {
    return this.baseUrl + '/admin/apps/calendar';
  }
  public static get email(): string {
    return this.baseUrl + '/admin/apps/email';
  }
  public static get filemanager(): string {
    return this.baseUrl + '/admin/apps/file-manager';
  }
  public static get employees(): string {
    return this.baseUrl + '/admin/employees';
  }
  public static get employee_page(): string {
    return this.baseUrl + '/admin/employees/employee-page';
  }
  public static get holidays(): string {
    return this.baseUrl + '/admin/employees/holidays';
  }
  public static get calendarMaster(): string {
    return this.baseUrl + '/admin/employees/calendar-master';
  }
  public static get policy(): string {
    return this.baseUrl + '/admin/employees/policies';
  }
  public static get permissions(): string {
    return this.baseUrl + '/admin/employees/permissions';
  }
  public static get generalSetting(): string {
    return this.baseUrl + '/admin/employees/general-setting';
  }
  public static get accessSetting(): string {
    return this.baseUrl + '/admin/employees/access-setting';
  }
  public static get integartionSetting(): string {
    return this.baseUrl + '/admin/employees/integration-setting';
  }
  public static get notificationSetting(): string {
    return this.baseUrl + '/admin/employees/notification-setting';
  }
  public static get profileSetting(): string {
    return this.baseUrl + '/admin/employees/profile-setting';
  }
  public static get feedback(): string {
    return this.baseUrl + '/admin/employees/feedback';
  }
  public static get permission(): string {
    return this.baseUrl + '/admin/employees/permission';
  }
  public static get leaveadmin(): string {
    return this.baseUrl + '/admin/employees/leave-admin';
  }
  public static get leaveemployee(): string {
    return this.baseUrl + '/admin/employees/leave-employee';
  }
  public static get leavesettings(): string {
    return this.baseUrl + '/admin/employees/leave-settings';
  }
  public static get attendanceadmin(): string {
    return this.baseUrl + '/admin/employees/attendance-admin';
  }
  public static get attendanceemployee(): string {
    return this.baseUrl + '/admin/employees/attendance-employee';
  }
  public static get departments(): string {
    return this.baseUrl + '/admin/employees/departments';
  }
  public static get designations(): string {
    return this.baseUrl + '/admin/employees/designations';
  }
  public static get clientPage(): string {
    return this.baseUrl + '/admin/clients/client-list';
  }
  public static get accountPage(): string {
    return this.baseUrl + '/admin/accounts/account-page';
  }
  public static get accountDetails(): string {
    return this.baseUrl + '/admin/accounts/account-details';
  }
  public static get createAccount(): string {
    return this.baseUrl + '/admin/accounts/create-account';
  }
  public static get projects(): string {
    return this.baseUrl + '/admin/projects';
  }
  public static get projectpage(): string {
    return this.baseUrl + '/admin/projects/project-list';
  }
  public static get tasks(): string {
    return this.baseUrl + '/admin/projects/tasks';
  }
  public static get taskboard(): string {
    return this.baseUrl + '/admin/projects/task-board';
  }
  public static get sprintMeeting(): string {
    return this.baseUrl + '/admin/projects/sprint-meeting';
  }
  public static get taskHours(): string {
    return this.baseUrl + '/admin/projects/task-hours';
  }
  public static get ticketpage(): string {
    return this.baseUrl + '/admin/tickets/ticket-page';
  }
  public static get sales(): string {
    return this.baseUrl + '/admin/sales';
  }
  public static get estimatepage(): string {
    return this.baseUrl + '/admin/sales/estimate-page';
  }
  public static get invoicepage(): string {
    return this.baseUrl + '/admin/sales/invoice-page';
  }
  public static get payments(): string {
    return this.baseUrl + '/admin/sales/payments';
  }
  public static get expenses(): string {
    return this.baseUrl + '/admin/sales/expenses';
  }
  public static get providentfund(): string {
    return this.baseUrl + '/admin/sales/provident-fund';
  }
  public static get taxes(): string {
    return this.baseUrl + '/admin/sales/taxes';
  }
  public static get templates(): string {
    return this.baseUrl + '/admin/templates';
  }
  public static get customTemplate(): string {
    return this.baseUrl + '/admin/templates/custom-template';
  }
  public static get onboarding(): string {
    return this.baseUrl + '/admin/onboarding';
  }
  public static get vender(): string {
    return this.baseUrl + '/admin/vender';
  }
  public static get offerLetterGeneration(): string {
    return this.baseUrl + '/admin/onboarding/offer-letter';
  }
  public static get accounting(): string {
    return this.baseUrl + '/admin/accounting';
  }
  public static get category(): string {
    return this.baseUrl + '/admin/accounting/category';
  }
  public static get subcategory(): string {
    return this.baseUrl + '/admin/accounting/sub-category';
  }
  public static get budgets(): string {
    return this.baseUrl + '/admin/accounting/budgets';
  }
  public static get budgetexpenses(): string {
    return this.baseUrl + '/admin/accounting/budget-expenses';
  }
  public static get budgetrevenues(): string {
    return this.baseUrl + '/admin/accounting/budget-revenues';
  }
  public static get payroll(): string {
    return this.baseUrl + '/admin/payroll';
  }
  public static get employeesalary(): string {
    return this.baseUrl + '/admin/payroll/employee-salary';
  }
  public static get payrollitems(): string {
    return this.baseUrl + '/admin/payroll/payroll-items';
  }
  public static get salaryview(): string {
    return this.baseUrl + '/admin/payroll/salary-view';
  }
  public static get policies(): string {
    return this.baseUrl + '/admin/policies/main';
  }
  public static get reports(): string {
    return this.baseUrl + '/admin/reports';
  }
  public static get expensereport(): string {
    return this.baseUrl + '/admin/reports/expense-report';
  }
  public static get invoicereport(): string {
    return this.baseUrl + '/admin/reports/invoice-report';
  }
  public static get paymentsreport(): string {
    return this.baseUrl + '/admin/reports/payments-report';
  }
  public static get projectreport(): string {
    return this.baseUrl + '/admin/reports/project-report';
  }
  public static get taskreport(): string {
    return this.baseUrl + '/admin/reports/task-report';
  }
  public static get userreport(): string {
    return this.baseUrl + '/admin/reports/user-report';
  }
  public static get employeereport(): string {
    return this.baseUrl + '/admin/reports/employee-report';
  }
  public static get payslipreport(): string {
    return this.baseUrl + '/admin/reports/payslip-report';
  }
  public static get attendancereport(): string {
    return this.baseUrl + '/admin/reports/attendance-report';
  }
  public static get leavereport(): string {
    return this.baseUrl + '/admin/reports/leave-report';
  }
  public static get dailyreport(): string {
    return this.baseUrl + '/admin/reports/daily-report';
  }
  public static get performance(): string {
    return this.baseUrl + '/performance';
  }
  public static get appraisal(): string {
    return this.baseUrl + '/admin/performance/appraisal';
  }
  public static get indicator(): string {
    return this.baseUrl + '/admin/performance/indicator';
  }
  public static get review(): string {
    return this.baseUrl + '/performance/review';
  }
  public static get crosshairs(): string {
    return this.baseUrl + '/goals';
  }
  public static get goalTracking(): string {
    return this.baseUrl + '/admin/goals/goal-tracking';
  }
  public static get goalType(): string {
    return this.baseUrl + '/admin/goals/goal-type';
  }
  public static get training(): string {
    return this.baseUrl + '/training';
  }
  public static get lists(): string {
    return this.baseUrl + '/admin/training/lists';
  }
  public static get types(): string {
    return this.baseUrl + '/admin/training/types';
  }
  public static get trainer(): string {
    return this.baseUrl + '/admin/training/trainer';
  }
  public static get promotion(): string {
    return this.baseUrl + '/admin/promotion/views';
  }
  public static get resignation(): string {
    return this.baseUrl + '/admin/resignation/res-main';
  }
  public static get termination(): string {
    return this.baseUrl + '/admin/termination/term-main';
  }

  public static get page(): string {
    return this.baseUrl + '/admin/pages';
  }
  public static get jobs(): string {
    return this.baseUrl + '/jobs';
  }
  public static get userDashboard(): string {
    return this.baseUrl + '/admin/jobs/user-dashboard';
  }
  public static get jobsdashboard(): string {
    return this.baseUrl + '/admin/jobs/jobs-dashboard';
  }
  public static get managejobs(): string {
    return this.baseUrl + '/admin/jobs/manage-jobs';
  }
  public static get manageresumes(): string {
    return this.baseUrl + '/admin/jobs/manage-resumes';
  }
  public static get shortlist(): string {
    return this.baseUrl + '/admin/jobs/shortlist';
  }

  public static get jobview(): string {
    return this.baseUrl + '/admin/jobs/job-view';
  }
  public static get interviewquestions(): string {
    return this.baseUrl + '/admin/jobs/interview-questions';
  }
  public static get offerapproval(): string {
    return this.baseUrl + '/admin/jobs/offer-approval';
  }
  public static get experiencelevel(): string {
    return this.baseUrl + '/admin/jobs/experience-level';
  }
  public static get candidateslist(): string {
    return this.baseUrl + '/admin/jobs/candidates-list';
  }
  public static get scheduletiming(): string {
    return this.baseUrl + '/admin/jobs/schedule-timing';
  }
  public static get aptituderesult(): string {
    return this.baseUrl + '/admin/jobs/aptitude-result';
  }
  public static get appliedcandidates(): string {
    return this.baseUrl + '/jobs/applied-candidates';
  }
  public static get knowledgebasemain(): string {
    return this.baseUrl + '/admin/knowledgebase/main';
  }
  public static get activities(): string {
    return this.baseUrl + '/admin/crm/activities';
  }
  public static get users(): string {
    return this.baseUrl + '/admin/users/user-view';
  }
  public static get companysettings(): string {
    return this.baseUrl + '/admin/settings/company-settings';
  }
  public static get roleSettings(): string {
    return this.baseUrl + '/admin/settings/role';
  }
  public static get profile(): string {
    return this.baseUrl + '/profile';
  }
  public static get employeeProfile(): string {
    return this.baseUrl + '/admin/employees/employee-details';
  }
  public static get clientProfile(): string {
    return this.baseUrl + '/admin/clients/client-details';
  }
  public static get loginpro(): string {
    return this.baseUrl + '/login';
  }
  public static get registers(): string {
    return this.baseUrl + '/register';
  }
  public static get forgotpassword(): string {
    return this.baseUrl + '/forgot-password';
  }
  public static get otp(): string {
    return this.baseUrl + '/otp';
  }
  public static get lockscreen(): string {
    return this.baseUrl + '/lock-screen';
  }
  public static get error(): string {
    return this.baseUrl + '/error-404';
  }
  public static get errors(): string {
    return this.baseUrl + '/error-500';
  }
  public static get subscriptions(): string {
    return this.baseUrl + '/subscriptions';
  }
  public static get subadmin(): string {
    return this.baseUrl + '/subscriptions/admins';
  }
  public static get subscribedcompanies(): string {
    return this.baseUrl + '/subscriptions/subscribed-companies';
  }
  public static get pages(): string {
    return this.baseUrl + '/admin/pages/view';
  }
  public static get search(): string {
    return this.baseUrl + '/pages/search';
  }
  public static get faq(): string {
    return this.baseUrl + '/pages/faq';
  }
  public static get terms(): string {
    return this.baseUrl + '/pages/terms';
  }
  public static get privacy(): string {
    return this.baseUrl + '/pages/privacy-policy';
  }
  public static get blankpage(): string {
    return this.baseUrl + '/pages/blank-page';
  }
  public static get components(): string {
    return this.baseUrl + '/components';
  }
  public static get forms(): string {
    return this.baseUrl + '/forms';
  }
  public static get basicinput(): string {
    return this.forms + '/form-basic-inputs';
  }
  public static get inputgroups(): string {
    return this.forms + '/form-input-groups';
  }
  public static get horizontalform(): string {
    return this.forms + '/form-horizontal';
  }
  public static get verticalform(): string {
    return this.forms + '/form-vertical';
  }
  public static get formmask(): string {
    return this.forms + '/form-mask';
  }
  public static get formvalidation(): string {
    return this.forms + '/form-validation';
  }
  public static get fileUpload(): string {
    return this.forms + '/form-fileupload';
  }
  public static get formSelect2(): string {
    return this.forms + '/form-select-2';
  }
  public static get tables(): string {
    return this.baseUrl + '/tables';
  }
  public static get basictables(): string {
    return this.baseUrl + '/table/tables-basic';
  }
  public static get datatables(): string {
    return this.baseUrl + '/table/data-basic';
  }
  public static get userAssetsDetails(): string {
    return this.baseUrl + '/assets/user-assets-details';
  }
  public static get assets(): string {
    return this.baseUrl + '/assets';
  }
  public static get assetCat(): string {
    return this.baseUrl + '/admin/assets/assets-category';
  }
  public static get assetDetail(): string {
    return this.baseUrl + '/admin/assets/assets-details';
  }
  public static get assetMain(): string {
    return this.baseUrl + '/admin/assets/assets-main';
  }
  public static get assetNew(): string {
    return this.baseUrl + '/admin/assets/assets-new';
  }
  public static get assetReports(): string {
    return this.baseUrl + '/admin/assets/assets-reports';
  }
  public static get assetDet(): string {
    return this.baseUrl + '/admin/assets/user-assets-details';
  }

  public static get assetDashboard(): string {
    return this.baseUrl + '/admin/assets/assets-dashboard';
  }
  public static get assetRegistration(): string {
    return this.baseUrl + '/admin/assets/assets-registration';
  }
  public static get assetTrack(): string {
    return this.baseUrl + '/admin/assets/assets-track';
  }
  public static get assetCost(): string {
    return this.baseUrl + '/admin/assets/assets-cost';
  }
  public static get assetWokflow(): string {
    return this.baseUrl + '/admin/assets/assets-workflow';
  }
  public static get assetAnalytics(): string {
    return this.baseUrl + '/admin/assets/assets-analytics';
  }
  public static get assetReport(): string {
    return this.baseUrl + '/admin/assets/assets-report';
  }
  public static get assetProduct(): string {
    return this.baseUrl + '/admin/assets/product';
  }
  public static get assetsDetails(): string {
    return this.baseUrl + '/admin/assets/assets-details';
  }
  public static get adminDashboard(): string {
    return this.baseUrl + '/admin/dashboard/admin';
  }
  public static get jobAptitude(): string {
    return this.baseUrl + '/jobs/job-aptitude';
  }
  public static get mailView(): string {
    return this.baseUrl + '/admin/apps/mailview';
  }
  public static get compose(): string {
    return this.baseUrl + '/admin/apps/compose';
  }

  public static get projectDetails(): string {
    return this.baseUrl + '/admin/projects/project-details';
  }
  public static get workItems(): string {
    return this.baseUrl + '/admin/projects/work-items';
  }
  public static get jobDetails(): string {
    return this.baseUrl + '/jobs/jobs-details';
  }
  public static get userAllJobs(): string {
    return this.baseUrl + '/jobs/user-all-jobs';
  }
  public static get savedJobs(): string {
    return this.baseUrl + '/jobs/saved-jobs';
  }
  public static get appliedJobs(): string {
    return this.baseUrl + '/jobs/applied-jobs';
  }
  public static get interviewJobs(): string {
    return this.baseUrl + '/jobs/interview-jobs';
  }
  public static get offeredJobs(): string {
    return this.baseUrl + '/jobs/offered-jobs';
  }
  public static get visitedJobs(): string {
    return this.baseUrl + '/jobs/visited-jobs';
  }
  public static get archivedJobs(): string {
    return this.baseUrl + '/jobs/archived-jobs';
  }
  public static get projectList(): string {
    return this.baseUrl + '/admin/projects/project-list';
  }
  public static get jobList(): string {
    return this.baseUrl + '/jobs/job-list';
  }
  public static get advancedUi(): string {
    return this.baseUrl + '/advanced-ui';
  }
  public static get ribbon(): string {
    return this.advancedUi + '/ui-ribbon';
  }
  public static get clipboards(): string {
    return this.advancedUi + '/ui-clipboard';
  }
  public static get dragDrop(): string {
    return this.advancedUi + '/ui-drag-drop';
  }
  public static get rating(): string {
    return this.advancedUi + '/ui-rating';
  }
  public static get textEditor(): string {
    return this.advancedUi + '/ui-text-editor';
  }
  public static get counter(): string {
    return this.advancedUi + '/ui-counter';
  }
  public static get scrollbar(): string {
    return this.advancedUi + '/ui-scrollbar';
  }
  public static get notification(): string {
    return this.advancedUi + '/notification';
  }
  public static get stickyNote(): string {
    return this.advancedUi + '/sticky-note';
  }
  public static get timeline(): string {
    return this.advancedUi + '/ui-timeline';
  }
  public static get horizontal(): string {
    return this.advancedUi + '/horizontal-timeline';
  }
  public static get formWizard(): string {
    return this.forms + '/form-wizard';
  }
  public static get charts(): string {
    return this.baseUrl + '/charts';
  }
  public static get apexChart(): string {
    return this.charts + '/apex-charts';
  }
  public static get ngTwoCharts(): string {
    return this.charts + '/ng2-charts';
  }
  public static get icon(): string {
    return this.baseUrl + '/icon';
  }
  public static get fontawesome(): string {
    return this.icon + '/fontawesome';
  }
  public static get feather(): string {
    return this.icon + '/feather';
  }
  public static get ionic(): string {
    return this.icon + '/ionic';
  }
  public static get material(): string {
    return this.icon + '/material';
  }
  public static get pe7(): string {
    return this.icon + '/pe7';
  }
  public static get themify(): string {
    return this.icon + '/themify';
  }
  public static get typicon(): string {
    return this.icon + '/typicon';
  }
  public static get weather(): string {
    return this.icon + '/weather';
  }
  public static get simpleLine(): string {
    return this.icon + '/simple-line';
  }
  public static get flag(): string {
    return this.icon + '/flag';
  }
  public static get alert(): string {
    return this.baseUi + '/ui-alerts';
  }
  public static get accordions(): string {
    return this.baseUi + '/ui-accordion';
  }
  public static get avatar(): string {
    return this.baseUi + '/ui-avatar';
  }
  public static get badges(): string {
    return this.baseUi + '/ui-badges';
  }
  public static get buttons(): string {
    return this.baseUi + '/ui-buttons';
  }
  public static get buttonGroup(): string {
    return this.baseUi + '/ui-buttons-group';
  }
  public static get breadcrumb(): string {
    return this.baseUi + '/ui-breadcrumb';
  }
  public static get cards(): string {
    return this.baseUi + '/ui-cards';
  }
  public static get carousel(): string {
    return this.baseUi + '/ui-carousel';
  }
  public static get dropDown(): string {
    return this.baseUi + '/ui-dropdowns';
  }
  public static get grid(): string {
    return this.baseUi + '/ui-grid';
  }
  public static get images(): string {
    return this.baseUi + '/ui-images';
  }
  public static get lightBox(): string {
    return this.baseUi + '/ui-lightbox';
  }
  public static get media(): string {
    return this.baseUi + '/ui-media';
  }
  public static get modal(): string {
    return this.baseUi + '/ui-modals';
  }
  public static get offcanvas(): string {
    return this.baseUi + '/ui-offcanvas';
  }
  public static get pagination(): string {
    return this.baseUi + '/ui-pagination';
  }
  public static get placeholder(): string {
    return this.baseUi + '/ui-placeholders';
  }
  public static get popover(): string {
    return this.baseUi + '/ui-popover';
  }
  public static get progressBars(): string {
    return this.baseUi + '/ui-progress';
  }
  public static get rangeSlider(): string {
    return this.baseUi + '/ui-rangeslider';
  }
  public static get spinner(): string {
    return this.baseUi + '/ui-spinner';
  }
  public static get tabs(): string {
    return this.baseUi + '/ui-tabs';
  }
  public static get sweetAlert(): string {
    return this.baseUi + '/ui-sweet-alerts';
  }
  public static get toasts(): string {
    return this.baseUi + '/ui-toasts';
  }
  public static get tooltip(): string {
    return this.baseUi + '/ui-tooltips';
  }
  public static get typography(): string {
    return this.baseUi + '/ui-typography';
  }
  public static get video(): string {
    return this.baseUi + '/ui-video';
  }
  public static get crm(): string {
    return this.baseUrl + '/admin/crm';
  }
  public static get pipeline(): string {
    return this.crm + '/pipeline';
  }
  public static get deals(): string {
    return this.crm + '/deals';
  }
  public static get dealsDetails(): string {
    return this.crm + '/admin/deals/deals-details';
  }
  public static get dealsDashboard(): string {
    return this.baseUrl + '/admin/dashboard/deals';
  }
  public static get leadDashboard(): string {
    return this.baseUrl + '/admin/dashboard/leads';
  }
  public static get leadList(): string {
    return this.baseUrl + '/admin/crm/leads/leads-list';
  }
  public static get ticketDetails(): string {
    return this.baseUrl + '/admin/tickets/ticket-details';
  }
  public static get contact(): string {
    return this.baseUrl + '/contact';
  }
  public static get contactDetails(): string {
    return this.baseUrl + '/admin/contact/contact-details';
  }
  public static get contactList(): string {
    return this.baseUrl + '/admin/crm/contact/contact-list';
  }
  public static get contactGrid(): string {
    return this.crm + '/contact/contact-grid';
  }
  public static get companies(): string {
    return this.crm + '/company/companies';
  }
  public static get companiesGrid(): string {
    return this.crm + '/company/companies-grid';
  }
  public static get companyDetails(): string {
    return this.crm + '/company/company-details';
  }
  public static get analytics(): string {
    return this.crm + '/analytics';
  }
  public static get dealsList(): string {
    return this.crm + '/deals/deals-list';
  }
  public static get leadsKanban(): string {
    return this.crm + '/leads/leads-kanban';
  }
  public static get dealsKanban(): string {
    return this.crm + '/deals/deals-kanban';
  }
  public static get leadsList(): string {
    return this.crm + '/leads/leads-list';
  }
  public static get outsourceList(): string {
    return this.crm + '/outsource-client/outsource-client-list';
  }
  public static get consultantList(): string {
    return this.crm + '/consultancy-agency/consultancy-agency-list';
  }
  public static get companyList(): string {
    return this.crm + '/company/company-list';
  }
  public static get leadsDetails(): string {
    return this.crm + '/leads/leads-details';
  }
  public static get leads(): string {
    return this.crm + '/leads';
  }
  public static get companySubscriptions(): string {
    return this.baseUrl + '/admin/subscriptions/company';
  }
  public static get emailview(): string {
    return this.baseUrl + '/admin/apps/mailview';
  }
  public static get color(): string {
    return this.baseUi + '/ui-colors';
  }

  public static get chartPrime(): string {
    return this.charts + '/prime-ng';
  }
  public static get horizontalTimeline(): string {
    return this.forms + '/admin/horizontal-timeline';
  }
  public static get editInvoice(): string {
    return this.baseUrl + '/admin/sales/edit-invoice';
  }
  public static get comingSoon(): string {
    return this.baseUrl + '/admin/pages/coming-soon';
  }
  public static get underMaintanance(): string {
    return this.baseUrl + '/admin/pages/under-maintenance';
  }
  public static get changePassword(): string {
    return this.baseUrl + '/admin/change-password';
  }
  public static get communication(): string {
    return this.baseUrl + 'communication';
  }
  public static get IMapPop(): string {
    return this.baseUrl + '/admin/communication/IMapPop-email';
  }
  public static get smtpEmail(): string {
    return this.baseUrl + '/admin/communication/smtp-email';
  }
  public static get emailTemplate(): string {
    return this.baseUrl + '/admin/communication/email-template';
  }
  public static get sendEmail(): string {
    return this.baseUrl + '/admin/communication/send-mail';
  }
  public static get smsTemplate(): string {
    return this.baseUrl + '/admin/communication/SMS-template';
  }
  public static get smsSetting(): string {
    return this.baseUrl + '/admin/communication/SMS-setting';
  }
  public static get smsSend(): string {
    return this.baseUrl + '/admin/communication/SMS-send';
  }
  public static get whatsappSetting(): string {
    return this.baseUrl + '/admin/communication/whatsapp-setting';
  }
  public static get settings(): string {
    return this.baseUrl + 'settings';
  }

  public static get profileSettings(): string {
    return this.baseUrl + '/admin/settings/profile-settings';
  }
  public static get securitySettings(): string {
    return this.baseUrl + '/admin/settings/security-settings';
  }
  public static get notificationSettings(): string {
    return this.baseUrl + '/admin/settings/notifications-settings';
  }
  public static get connectedAppsSettings(): string {
    return this.baseUrl + '/admin/settings/connected-apps';
  }
  public static get approvalSettings(): string {
    return this.baseUrl + '/admin/settings/approval-settings';
  }
  public static get salarySettings(): string {
    return this.baseUrl + '/admin/settings/salary-settings';
  }
  public static get invoiceSettings(): string {
    return this.baseUrl + '/admin/settings/invoice-settings';
  }
  public static get customSettings(): string {
    return this.baseUrl + '/admin/settings/custom-settings';
  }
  public static get leaveSettings(): string {
    return this.baseUrl + '/admin/settings/leave-settings';
  }
  public static get paymentSettings(): string {
    return this.baseUrl + '/admin/settings/payment-settings';
  }
  public static get cronjobSettings(): string {
    return this.baseUrl + '/admin/settings/cron-settings';
  }
  public static get banSettings(): string {
    return this.baseUrl + '/admin/settings/ban-ip-address';
  }
  public static get emailSettings(): string {
    return this.baseUrl + '/admin/settings/email-settings';
  }
  public static get smsSettings(): string {
    return this.baseUrl + '/admin/settings/sms-settings';
  }
  public static get smsTemplateSettings(): string {
    return this.baseUrl + '/admin/settings/sms-templates';
  }
  public static get otpSettings(): string {
    return this.baseUrl + '/admin/settings/otp';
  }
  public static get taxSettings(): string {
    return this.baseUrl + '/admin/settings/tax-settings';
  }
  public static get currenciesSettings(): string {
    return this.baseUrl + '/admin/settings/currencies-settings';
  }
  public static get whatsappTemplate(): string {
    return this.baseUrl + '/admin/communication/whatsapp-template';
  }
  public static get whatsappSend(): string {
    return this.baseUrl + '/admin/communication/whatsapp-send';
  }
  public static get reminderList(): string {
    return this.baseUrl + '/admin/communication/reminder-list';
  }
  public static get leaves(): string {
    return this.baseUrl + '/admin/leaves';
  }
  public static get leaveDashboard(): string {
    return this.baseUrl + '/admin/attendance/leave-dashboard';
  }
  public static get leaveApproval(): string {
    return this.baseUrl + '/admin/attendance/leave-approval';
  }
  public static get leaveBalance(): string {
    return this.baseUrl + '/admin/attendance/leave-balance';
  }
  public static get attenTrack(): string {
    return this.baseUrl + '/admin/attendance/attendance-track';
  }
  public static get attenReport(): string {
    return this.baseUrl + '/admin/attendance/attendance-report';
  }
  public static get empDaychart(): string {
    return this.baseUrl + '/admin/attendance/emp-daychart';
  }
  public static get timesheet(): string {
    return this.baseUrl + '/admin/attendance/timesheet';
  }
  public static get shiftschedule(): string {
    return this.baseUrl + '/admin/attendance/employee-roaster';
  }
  public static get overtime(): string {
    return this.baseUrl + '/admin/attendance/overtime';
  }
  public static get outStationTimesheet(): string {
    return this.baseUrl + '/admin/attendance/outstation-duty';
  }
  public static get OdTimesheet(): string {
    return this.baseUrl + '/admin/attendance/out-of-duty';
  }
  public static get Expense(): string {
    return this.baseUrl + '/admin/attendance/expense';
  }
}
