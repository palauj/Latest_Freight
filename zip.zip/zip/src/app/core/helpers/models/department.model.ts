export interface AddDepartment {
  id: string;
  serialNumber: number;
  departmentId: string;
  departmentName: string;
  edit: number;
  isActive: boolean;
}

export interface MasterDepartment {
  createdDate?: string;
  departmentId: string;
  departmentName: string;
  isActive: boolean;
}

export interface Department {
  departmentId: string;
  departmentName: string;
}

export interface Employee {
  departmentName: string;
  designationName: string;
  employeeCode: string;
  employeeId: string;
  employeeName: string;
  backgroundColor: string;
}
