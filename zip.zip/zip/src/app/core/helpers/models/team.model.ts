import { employeeLocation } from "./auth.model";

export interface AddTeam {
  teamId: string;
  id: string;
  serialNumber: number;
  edit: number;
  isActive: boolean;
  locationId: string;
  teamName: string;
  accountId: string;
  createdDate: string;
}

export interface MasterTeam {
  teamId: string;
  isActive: boolean;
  createdDate: string;
  teamName: string;
}
export interface Consultant {
  venderId: string;
  venderCode: string;
  venderName: string;
  contactPersonName: string;
  email: string;
  phone: string;
  cityName: string;
  countryName: string;
  stateName: string;
  venderAddress: string;
}
export interface OutsourceClient {
  consultantId: string;
  name: string;
  email: string;
  phone: string;
  country: string;
  state: string;
  city: string;
  accountId: string;
  locationId: string;
  employeeLocation: employeeLocation[];
}

export interface AddTeamMember {
  noOfEmployees: string;
  departmentName: string;
  teamId: string;
  id: string;
  serialNumber: number;
  edit: number;
  isActive: boolean;
  locationId: string;
  teamName: string;
  accountId: string;
  createdDate: string;
  departmentId: string;
  employeeId: string;
  teamMemberId: string;
  accountTeamId: string;
  totalEmployeeCount: number;
  employeeInfo: EmployeeInfo[];
}

export interface EmployeeInfo {
  employeeCode: string;
  employeeId: string;
  employeeName: string;
  fIleData: string;
  isActive: boolean;
}

export interface Team {
  teamId: string;
  teamName: string;
}
