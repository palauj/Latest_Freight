export interface AddRole {
  id: string;
  serialNumber: number;
  userId: string;
  name: string;
  edit: number;
  roleName: string;
  isActive: boolean;
  roleId: string;
  locationId: string;
  accountId: string;
}

export interface MasterRole {
  id: string;
  isActive: boolean;
  createdDate: string;
  name: string;
  isSuperRole: boolean;
}

export interface Roles {
  id?: string;
  roleId: string;
  roleName: string;
}

export interface Category {
  id: string;
  categoryId?: string;
  relatedTo: string;
  relatedToName: string;
  relatedToId: string;
  parentId: string;
  name: string;
  categoryName?: string;
  isActive: Boolean;
  categoryType: string;
}

export interface category {
  id?: string;
  categoryId: string;
  name: string;
  categoryType: string;
  categoryName: string;
}
