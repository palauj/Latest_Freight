export interface ProjectData {
  accountId: string;
  serialNumber: number;
  accountName: string;
  clientId: string;
  clientName: string;
  createdDate: string;
  description: string;
  endProjectDate: string;
  isActive: boolean;
  locationId: string;
  locationName: string;
  priorityName: string;
  priorityId?: string;
  productOwner: string;
  projectCode: string;
  projectId: string;
  projectManagerName: string;
  scrumMaster: string;
  projectName: string;
  rate: string;
  startProjectDate: string;
  accountTeamName: string;
  accountTeamMemberIds: string;
  subStatus: string;
  status: string;
  productOwnerId: string;
  projectIP: string;
  projectManagerId: string;
  projectScrumMasterId: string;
  projectScrumMasterName: string;
  statusId: number;
  statusName: string;
  subStatusId: number;
  subStatusName: string;
  accountTeamId: string;
  createdByName: string;
  profilePicture: string;
}

export interface ProjectDetails {
  projectId: string;
  projectName: string;
  startProjectDate: string;
  endProjectDate: string;
  locationName: string;
  accountName: string;
  accountId: string;
  locationId: string;
  clientId: string;
  clientName: string;
  accountTeamId: string;
  accountTeamName: string;
  accountTeamMemberIds: string;
  description: string;
  productOwner: string;
  projectManagerName: string;
  projectScrunMasterName: string;
  rate: string;
  priorityName: string;
  productOwnerId: string;
  projectManagerId: string;
  projectScrunMasterId: string;
  statusId: number;
  subStatusId: number;
  statusName: string;
  subStatusName: string;
  userId: string;
}

export interface TaskRecordData {
  id: string;
  relatedTo: string;
  relatedToId: string;
  relatedToName: string;
  transactionNumber: string;
  taskEventId: number;
  serialNumber: number;
  taskEventName: string;
  taskSubject: string;
  ownerId: string;
  ownerName: string;
  taskPercentage: number;
  openTime: string;
  endTime: string;
  targetEndTime: string;
  taskDescription: string;
  endRemarks: string;
  taskStatusId: number;
  taskStatusDesc: string;
  taskStatusReasonId: number;
  taskStatusReasonDesc: string;
  taskNetHrs: number;
  taskCloseTime: string;
  taskCount: number;
  emailCount: number;
  documentCount: number;
  specialNoteCount: number;
  internalNoteCount: number;
  accountId: string;
  locationId: string;
  accountName: string;
  locationName: string;
  workItemType: string;
  assignedToId?: string;
  assignToId?: string;
  assignedToName?: string;
  assignToName?: string;
  priorityName?: string;
}

export interface TaskTimeTrackData {
  id?: string;
  taskId?: string;
  transactionNumber?: string;
  userId?: string;
  isTrackerStart?: boolean;
  isTrackerEnd?: boolean;
  isTaskFirstOpenTime?: boolean;
  firstOpenTime?: string;
}

export interface ProjectDocuments {
  documentDescription: string;
  documentExtension: string;
  documentFileName: string;
  documentMimeType: string;
  documentName: string;
  documentPath: string;
  documentReferenceNumber: string;
  documentSize: string;
  documentType: string;
  fileData: string;
  id: string;
  relatedTo: string;
  relatedToName: string;
}

export interface BreakData {
  breakType: string;
  endTime: string;
  id: string;
  startTime: string;
  totalTime: number;
}

export interface NoteList {
  accountId: string;
  accountName: string;
  createdDate: string;
  createdIP: string;
  id: string;
  isActive: boolean;
  locationId: string;
  locationName: string;
  modifiedIP: string;
  nextFollowUpDate: string;
  noteDescription: string;
  noteType: string;
  relatesTo: string;
  relatesToId: string;
  relatesToName: string;
  userId: string;
  backgroundColor: string;
}

export interface ProjectCount {
  active: number;
  close: number;
  inActive: number;
  inProgress: number;
  open: number;
  total: number;
}
