export interface Leave {

}