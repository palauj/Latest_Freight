import { Roles } from './role.model';

export interface BreakTimeRecord {
  startTime: string;
  endTime: string;
  relatedTo: string;
  relatedToId: string;
  relatedToName: string;
  employeeId: string;
  locationId: string;
  locationName: string;
  accountId: string;
  accountName: string;
  breakType: string;
  isBreakEnd: boolean;
  isBreakStart: boolean;
  userId: string;
}

export interface UpdateEmployeeBreakRecord {
  id: string;
  userId: string;
  isBreakEnd: boolean;
}

export interface BreakTimePayload {
  relatedToId: string;
  employeeId: string;
}

export interface Time {
  time: string;
  value: string;
}

export interface CalendarHoliday {
  calendarDate: string;
  calendarDateRemarks: string;
  calendarDateType: string;
}

export interface EmployeeModal {
  accountId: string;
  accountName: string;
  address: string;
  adharCardNumber: string;
  age: number;
  bankAccountNumber: string;
  bankName: string;
  city: string;
  contactName: string;
  country: string;
  createdDate: string;
  createdIP: string;
  dateOfBirth: string;
  dateOfJoining: string;
  departmentId: string;
  departmentName: string;
  deputationLocation: string;
  designationId: string;
  designationName: string;
  email?: string;
  officialEmail?: string;
  personalEmail: string;
  officeContact?: string;
  personalContact?: string;
  emergencyContactNo: string;
  employeeCode: string;
  employeeContactNo: string;
  employeeEducationalInformation: any[];
  employeeExperiancesInformation: any[];
  employeeId: string;
  employeeRoles: Roles[];
  employeeTypeId: string;
  employeeTypeName: string;
  employmentSpouseStatus: string;
  esiNumber: string;
  fileData: string;
  firstName: string;
  gender: string;
  ifscCode: string;
  isMedicalInsurance: boolean;
  isPfStatus: boolean;
  jobType: string;
  lastName: string;
  locationId: string;
  locationName: string;
  maritalStatus: string;
  modifiedIP: string;
  name: string;
  nationality: string;
  panNumber: string;
  passportExpiryDate: string;
  passportNo: string;
  password: string;
  passwordHash: string;
  passwordSalt: string;
  phone1?: string;
  phone2?: string;
  regionalHeadQuarter: string;
  relationshipName: string;
  religion: string;
  reportManagerId: string;
  reportManagerName: string;
  state: string;
  uanNumber: string;
  uniqueEmpCode: string;
  userType: string;
  yearOfExperience: string;
  countryId: number;
  countryName: string;
  workType: string;
  cityId: number;
  cityName: string;
  stateId: number;
  stateName: string;
  remarks: string;
  exitDate: string;
  ipRestriction?: string | null;
  resignationDate: string;
  reIfscCode?: string;
  reBankName?: string;
  reBankAccountNumber?: string;
}

export interface EducationPayload {
  educationalInformation: EducationDetails[];
}
export interface EmployeeCountData {
  total: number;
  probation: number;
  consultant: number;
  contract: number;
  permanent: number;
  wfh: number;
  hybrid: number;
}

export interface EducationDetails {
  collageName: string;
  courseName: string;
  passingYear: string;
  stream?: string;
  startYear: string;
  marksPercentage: string;
  userId: string;
  employeeId: string;
  educationId: string;
  isActive: boolean;
}

export interface ExperiencePayload {
  experiences: EducationDetails[];
}

export interface ExperienceDetails {
  companyName: string;
  designationName: string;
  startDate: string;
  skills: string;
  endDate: string;
  userId: string;
  employeeId: string;
  experiancesId: string;
  isActive: boolean;
}

export interface ResignationRecord {
  resignationDate: string;
  exitDate: string;
  remarks: string;
  employeeId: string;
  userId: string;
}

export interface UpdateEmployeeLeaveStatus {
  id: string;
  approvedById: string;
  approvedByName: string;
  approvedByRemarks: string;
  status: string;
  userId: string;
}

export interface LeaveStatusByHR {
  id: string;
  approvedById: string;
  approvedByName: string;
  approvedByRemarks: string;
  status: string;
  userId: string;
}

export interface Birthday {
  employeeName: string;
  employeeCode: string;
  officialContact: string;
  officialEmail: string;
  personalContact: string;
  personalEmail: string;
  dateOfBirth: string;
  departmentName: string;
  designationName: string;
  backgroundColor: string;
}
