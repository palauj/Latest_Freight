export interface AttendancePayload {
  leaveId: string;
  leaveEmpId: string;
  leaveTypeRequest: string;
  leaveFromDateTime: string;
  leaveToDateTime: string;
  leaveHalf: string;
  leaveRemark: string;
  leaveEmergencyNo: string;
  leaveStatus: string;
  employeeId: string;
  accountId: string;
  locationId: string;
  accountName: string;
  locationName: string;
}

export interface EmpLeaveBalancePayload {
  userId: string;
  leaveId: string;
  leaveEmpCode: string;
  leaveTypeCl: string;
  leaveTypePl: string;
  leaveTypeAl: string;
  leaveTypeMl: string;
  leaveTypeComL: string;
  leaveTypeLwp: string;
  leaveTypeSl: string;
  leaveTypePdl: string;
  leaveTypeMdl: string;
  leaveTypePll: string;
  isDeleted: boolean;
  isActive: boolean;
  createdDate: string;
  createdBy: string;
  modifiedDate: string;
  modifiedBy: string;
  deletedDate: string;
  deletedBy: string;
  createdIp: string;
  modifiedIp: string;
  accountId: string;
  locationId: string;
  accountName: string;
  locationName: string;
}

export interface EmpChartInOutPayload {
  accountID: string;
  locationID: string;
  inTime?: string;
  outTime?: string;
  currentDate: string;
  employeeId: string;
  status: string;
  isCheckOut: boolean;
  isCheckIn: boolean;
  isOT: boolean;
}

export interface EmpInoutTimeUpdate {
  accountId: string;
  locationId: string;
  inTime: number;
  outTime: number;
  currentDate: string | null;
  empId: string;
}

export interface CalenderHolidayUpdate {
  accountId: string;
  locationId: string;
  calenderDate: string | null;
  remark: string;
  userId: string;
}

export interface EmployeeChartInsert {
  accountID: string;
  locationID: string;
  employeeID: string;
  startDate: string;
  endDate: string;
  userId: string;
}

export interface EmpDailyActivity {
  dateFrom: string;
  dateTo: string;
  accountId: string;
  locationId: string;
  userId: string;
}

export interface EmpTimesheetInsertUpdate {
  accountId: string;
  locationId: string;
  id: string;
  employeeId: string;
  fromTime: string | null;
  date: string;
  toTime: string | null;
  actionType: string;
  taskId: string;
  projectId: string;
  taskNumber: string;
  remark: string;
}

export interface EmpOutStationInsertUpdate {
  outstationId: string;
  empId: string;
  fromLocId: string;
  fromLocName: string;
  accountId: string;
  locationId: string;
  toLocName: string;
  fromDateTime: string;
  toDateTime: string;
  remark: string;
  amountRequired: number;
}

export interface EmpODInsertUpdate {
  accountId: string;
  locationId: string;
  id: string;
  empId: string;
  date: string;
  fromDateTime: string | null;
  toDateTime: string | null;
  fromLocId: string;
  fromLoc: string;
  toLoc: string;
  taskId: string;
  taskNumber: string;
  remark: string;
}

export interface RosterInsert {
  employeeId: string;
  accountId: string;
  locationId: string;
  startDate: string;
  endDate: string;
  userId: string;
}

export interface EmpApprovalDetails {
  employeeId: string;
  fromDate: string;
  toDate: string;
  type: string;
  status: string;
  reportingToId: string;
  pending: string;
  userId: string;
}

export interface EmpApprovalHRDetails {
  accountId: string;
  locationId: string;
  employeeId: string;
  fromDate: string;
  toDate: string;
  type: string;
  status: string;
  userId: string;
}

export interface UpdateLeaveBalance {
  calendarId: number;
  calendarDateType: string;
  calendarDateRemarks: string;
}

export interface UpdateEmployeeTimesheetByID {
  id: string;
  approvedById: string;
  approvedByName: string;
  approvedByRemarks: string;
  status: string;
  userId: string;
}

export interface UpdateEmployeeTimesheetByHR {
  id: string;
  approvedByHrId: string;
  approvedByHrName: string;
  approvedByHrRemarks: string;
  status: string;
  userId: string;
}

export interface Count {
  approvedCount: number;
  pendingCount: number;
  rejectedCount: number;
  totalCount: number;
}
export interface leadCount {
  total: number;
  ledOpen: number;
  ledInProgress: number;
  ledClosed: number;
  ledDeferred: number;
  ledNew: number;
}
export interface assetsCount {
  total: number;
  active: number;
  inActive: number;
  amc: number;
  warrantyExpired: number;
  underWarranty: number;
}
export interface taskData {
  projectId: string;
  projectName: string;
  accountTeamName: string;
  startProjectdate: string;
  endProjectdate: string;
  statusName: string;
  subStatusName: string;
  clientName: string;
}
export interface projectData {
  id: string;
  transactionNumber: string;
  openTime: string | null;
  isActive: boolean;
  priorityName: string;
  taskSubject: string;
  ownerName: string;
  taskStatusDescription: string;
  taskStatusReasonDescription: string;
  workItemType: string;
  assignToName: string;
}

export interface AttendanceCount {
  onTimeCount: number;
  lateCount: number;
  workFromHomeCount: number;
  absentCount: number;
  approvedCount: number;
  leaveAbscentCount: number;
  leaveTakenCount: number;
  pendingCount: number;
  presentCount: number;
  rejectedCount: number;
  sickLeaveCount: number;
  totalAttendanceCount: number;
  totalLeaveCount: number;
}
 
export interface LeaveCountData {
  total: number;
  probation: number;
  consultant: number;
  contract: number;
  permanent: number;
  wfh: number;
  hybrid: number;
}

export interface DataCount {
  employeeLeaveCount: {
    pendingCount: number;
    approvedCount: number;
    rejectedCount: number;
    totalCount: number;
  };
  employeeDayChartCount: {
    workedDayCount: number;
    absentCount: number;
  };
  approvedCount: number;
  pendingCount: number;
  rejectedCount: number;
  totalCount: number;
  open?: number;
  total: number;
  active: number;
  inActive: number;
  location: number;
  inProgress: number;
  close: number;
  project: number;
  deferred: number;
  probation: number;
  consultant: number;
  contract: number;
  permanent: number;
  weeknd: number;
  holiday: number;
  workingDays: number;
  serviceRequest: number;
  LEDNew: number;
  ledOpen: number;
  ledInProgress: number;
  ledClosed: number;
  ledDeferred: number;
  new: number;
  amc: number;
  warrantyExpired: number;
  underWarranty: number;

  srCount: number;
}

export interface AddUpdateExpense {
  id: string;
  type: string;
  expenseDate: string;
  amountClaim: number;
  travelMode: string;
  isBillAttached: boolean;
  distance: number;
  odId: string;
  employeeId: string;
  outstationId: string;
  remark: string;
  hotelName: string;
  fromDate: string;
  toDate: string;
  additionalExpense: number;
  billNumber: number;
}

export interface CalenderInsert {
  year: number;
  locationId: string | undefined;
  accountId: string | undefined;
}

export interface CountsDetail {
  name: string;
  count: number | string | null;
  icon: string;
  class: string;
  router?: string;
}

export interface ChartDetails {
  chartDateRemarks: string;
  chartDateType: string;
  chartLocationName: string;
  chartModifyFlag: string;
  date: string;
  expApproved: number;
  expClaimed: number;
  extraDuration: string;
  id: string;
  inTime: string;
  odCount: number;
  odDuration: string;
  outTime: string;
  outstation: string;
  timeDiff: string;
  tsCount: number;
  tsDuration: string;
  webInTime: string;
  webOutTime: string;
  webTimeDiff: string;
  workingDate: string;
}

export interface UpdateEmpApproval {
  id: string;
  userId: string;
  leaveStatus: string;
  remarks: string;
  actionType: string;
}
