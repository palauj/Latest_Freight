export interface AddDesignation {
  id: string;
  serialNumber: number;
  designationId: string;
  designationName: string;
  edit: number;
  isActive: boolean;
  masterDesignationIds: string;
}

export interface MasterDesignation {
  createdDate?: string;
  designationId: string;
  designationName: string;
  isActive: boolean;
}

export interface Designation {
  designationId: string;
  designationName: string;
  isActiveL: boolean;
}
