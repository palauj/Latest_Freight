export interface ClientData {
  clientId: string;
  locationId: string;
  accountId: string;
  clientCode?: string;
  companyAddress: string;
  email: string;
  phone: string;
  clientName?: string;
  firstName: string;
  lastName: string;
  companyName: string;
  locationName: string;
  accountName: string;
  serialNumber?: number;
  userId: string;
  countryId: number;
  countryName: string;
  stateId: number;
  stateName: string;
  cityId: number;
  cityName: string;
  projectName?: string;
}

export interface ClientDetails {
  clientId: string;
  locationId: string;
  accountId: string;
  clientCode?: string;
  country: string;
  state: string;
  city: string;
  companyAddress: string;
  email: string;
  phone: string;
  firstName: string;
  lastName: string;
  companyName: string;
  locationName: string;
  accountName: string;
  serialNumber?: number;
  isActive: boolean;
  name: string;
  profilePicture: string;
  projectId: string;
  projectName: string;
  createdDate: string;
}
