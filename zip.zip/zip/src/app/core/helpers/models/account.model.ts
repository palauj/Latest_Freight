export interface AccountBasicDetails {
  accountId?: string;
  companyName: string;
  email: string;
  phone1: string;
  phone2: string;
  fax: string;
  website: string;
  ownerName: string;
  tags: string;
  aboutCompany: string;
  userId: string;
}

export interface AddressDetails {
  streetAddress: string;
  cityName: string;
  stateName: string;
  countryName: string;
  zipCode: string;
  addressId: string;
  countryId: number;
  stateId: number;
  cityId: number;
  userId: string;
  accountId: string;
}

export interface LocationDetails {
  locationName: string;
  shortName: string;
  address: string;
  state: string;
  country: string;
  zipCode: string;
  accountId: string;
}

export interface SocialProfiles {
  socialInfoId: string;
  socialInfoName: string;
  socialInfoLink: string;
  accountId: string;
  userId: string;
}

export interface SocialDropdown {
  id: string;
  socialName: string;
}

export interface AccessDetails {
  accountId: string;
  visibility: string;
  status: boolean;
  userId?: string;
}

export interface AccountList {
  searchQuery: string;
  pageNumber: number;
  pageSize: number;
}

export interface addAccountLocation {
  locationId?: string;
  accountId: string;
  accountName: string;
  locationAddress: string;
  shortName: string;
  locationName: string;
  zipCode: string;
  edit: number;
  street: string;
  userId: string;
  countryId: number;
  countryName: string;
  stateId: number;
  stateName: string;
  cityId: number;
  cityName: string;
}

export interface addAccountDepartment {
  accountId: string | null;
  departmentId: string | null;
  departmentName?: string;
  edit: number;
  isActive: boolean;
  userId: string;
  id?: string;
  locationId: string;
}

export interface addAccountDesignation {
  id?: string | null;
  designationId: string;
  accountId: string;
  locationId: string;
  edit: number;
  isActive: boolean;
  userId: string;
}

export interface addAccountTeam {
  id?: string | null;
  teamId?: string;
  accountId: string;
  userId: string;
  teamName?: string;
  isActive: boolean;
  edit: number;
  locationId: string;
}

export interface addAccountTeamMember {
  teamMemberId: string;
  teamId: string;
  employeeId: string;
  departmentId: string;
  locationId: string;
  accountId: string;
  accountTeamId: string;
  isActive: boolean;
  userId: string;
}

export interface addAccountRole {
  id: string;
  accountId: string;
  isActive: boolean;
  edit?: number;
  locationId: string;
  roleId: string;
  userId: string;
}
export interface addAccountCategory {
  id?: string | null;
  accountId: string;
  userId: string;
  isActive: boolean;
  edit?: number;
  locationId: string;
  categoryId: string;
}

export interface addLicenseDetails {
  licenseId?: string;
  accountId: string;
  licenseType: string;
  licenseStartDate: string;
  licenseEndDate: string;
  noOfUser: number;
  noOfProject: number;
  price?: string;
  userId: string;
}

export interface LocationModel {
  id?: number;
  accountId: string;
  accountName?: string;
  isActive: boolean;
  locationAddress?: string;
  locationId: string;
  locationName: string;
  shortName: string;
  street: string;
  zipCode?: string;
  cityId: number;
  cityName: string;
  countryId: number;
  countryName: string;
  stateId: number;
  stateName: string;
}

export interface LocationDialog {
  id?: string;
  title: string;
  accountId: string;
  accountName: string;
  submitBtn: string;
  closeBtn: string;
}

export interface AccountDropDown {
  accountId: string;
  accountName: string;
}

export interface AccountLocationDropDown {
  locationId: string;
  locationName: string;
}

export interface AccountEmployeeDropDown {
  employeeId: string;
  employeeName: string;
  employeeCode?: string;
  designationName?: string;
  departmentName?: string;
}

export interface AccountTeamDropDown {
  accountTeamId: string;
  accountTeamName: string;
}

export interface AccountTeamMemberDropDown {
  teamMemberId: string;
  teamMemberName: string;
}

export interface AccountDetails {
  accountAccessList: AccessList[];
  accountAddressInfoList: AddressInfoList[];
  accountBasicInfoList: BasicInfoList[];
  accountLicensePlanList: LicensePlanList[];
  accountLocationList: LocationModel[];
  accountSocialInfoList: SocialProfiles[];
}

export interface AccessList {
  accessId: string;
  accountId: string;
  createdDate: string;
  status: boolean;
  visibility: string;
}

export interface AddressInfoList {
  accountId: string;
  addressId: string;
  city: string;
  country: string;
  createdDate: string;
  state: string;
  streetAddress: string;
  zipCode: string;
}

export interface BasicInfoList {
  aboutCompany: string;
  accountId: string;
  companyName?: string;
  createdDate: string;
  email: string;
  accountTransactionNumber: string;
  fax: string;
  isActive: boolean;
  ownerName: string;
  phone1: string;
  phone2: string;
  fileData: string;
  tags: string;
  website: string;
}

export interface LicensePlanList {
  accountId: string;
  isActive: boolean;
  licenseEndDate: string;
  licenseId: string;
  licenseStartDate: string;
  licenseType: string;
  noOfProject: number;
  noOfUser: number;
  price: string;
}
