export interface OutSourceClient {
clientId: string,
clientName?: string,
email: string,
phone: string | number,
countryId: number,
countryName: string,
stateId: number,
stateName: string,
cityId: number,
cityName: string,
clientAddress: string,
createdIP?: string| number,
modifiedIP?: string| number,
clientCode?: string| number,
locationId?: string,
locationName?: string,
accountId?: string,
accountName?:string|null
requestParam?:any
}