// import { Injectable } from '@angular/core';
// import {
//   CanActivate,
//   ActivatedRouteSnapshot,
//   RouterStateSnapshot,
//   Router,
// } from '@angular/router';
// import { AuthService } from '../services/auth/auth.service';

// @Injectable({
//   providedIn: 'root',
// })
// export class AuthGuard implements CanActivate {
//   constructor(private authService: AuthService, private router: Router) {}

//   canActivate(
//     route: ActivatedRouteSnapshot,
//     state: RouterStateSnapshot
//   ): boolean {
//     if (this.authService.isLogin()) {
//       return true;
//     } else {
//       this.router.navigate(['/login']); // Redirect to login if not authenticated
//       return false;
//     }
//   }
// }

import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  Router,
  CanActivateChild,
  CanLoad,
  Route,
} from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs';
import { AuthService } from '../core.index';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate, CanActivateChild, CanLoad {
  constructor(
    private authService: AuthService,
    private router: Router,
    private toastr: ToastrService
  ) {}

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    if (this.authService.isLogin()) {
      // let claimType: string = next.data["claimType"];
      // if (claimType) {
      //   if (!this.authService.hasClaim(claimType)) {
      //     this.toastr.error(`You don't have right to access this page`);
      //     this.router.navigate(['/admin/profile']);
      //     return false;
      //   }
      // }
      return true;
    } else {
      this.router.navigate(['login']);
      return false;
    }
    return true;
  }

  canActivateChild(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    if (this.authService.isLogin()) {
      let claimType: string = next.data['claimType'];
      // if (claimType) {
      //   if (!this.securityService.hasClaim(claimType)) {
      //     this.toastr.error(`You don't have right to access this page `);
      //     return false;
      //   }
      // }
      return true;
    } else {
      this.router.navigate(['login']);
      return false;
    }
  }
  canLoad(route: Route): boolean {
    if (this.authService.isLogin()) {
      return true;
    } else {
      this.router.navigate(['login']);
      return false;
    }
  }
}
