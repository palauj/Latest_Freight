import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mask',
})
export class MaskPipe implements PipeTransform {
  // Transform method will be called when the pipe is used
  transform(
    value: string,
    maskChar: string = '*',
    maskLength: number = -1
  ): string {
    if (!value) return value; // Return the value unchanged if it's falsy

    // If maskLength is -1, mask the entire string, otherwise, mask only part of it
    const lengthToMask = maskLength === -1 ? value.length : maskLength;
    const maskedPortion = maskChar.repeat(lengthToMask);
    const unmaskedPortion = value.substring(lengthToMask); // The remaining unmasked portion

    return maskedPortion + unmaskedPortion;
  }
}
