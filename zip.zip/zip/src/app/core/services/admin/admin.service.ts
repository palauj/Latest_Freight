import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private httpService: HttpClient) { }


  public getEmployeeAttendanceCount(accountId: string, locationId: string) {
    const url = `/api/Clients/GetClientCount?accountId=${accountId}&locationId=${locationId}`;
    return this.httpService.get(url);
  }
}
