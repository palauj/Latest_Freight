import { inject, Injectable } from '@angular/core';
import { HttpService } from '../http/http.service';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root',
})
export class ContactDetailService {
  private http = inject(HttpService);
  constructor() {}

  public getContactDetailById(id: string): Observable<any> {
    const url = `/api/ContactDetail/GetContactDetailsFilterList?RelatedToId=${id}`;
    return this.http.get(url);
  }

  public getAllContactList(data: any): Observable<any> {
    const url = `/api/ContactDetail/GetContactFilterList?PageSize=${data?.pageSize}&PageNumber=${data?.pageNumber}&SearchKeyword=${data?.search}&AccountId=${data?.accountId}&LocationId=${data?.locationId}`;
    return this.http.get(url);
  }

  public deleteContactDetailById(id: string, userId: string): Observable<any> {
    const url = `/api/ContactDetail/DeleteContactDetailsDataById?id=${id}&userId=${userId}`;
    return this.http.delete(url);
  }

  public addContactDetail(data: any) {
    const url = `/api/ContactDetail/SaveContactDetailsRecord`;
    return this.http.post(url, data);
  }

  public updateContactDetail(data: any) {
    const url = `/api/ContactDetail/UpdateContactDetailsRecord`;
    return this.http.put(url, data);
  }
}
