import { inject, Injectable } from '@angular/core';
import { HttpService } from '../http/http.service';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BaseResponse } from '../../helpers/models/common.model';
import {
  AccessDetails,
  AccountBasicDetails,
  AccountList,
  addAccountCategory,
  addAccountDepartment,
  addAccountDesignation,
  addAccountLocation,
  addAccountRole,
  addAccountTeam,
  addAccountTeamMember,
  addLicenseDetails,
  AddressDetails,
  SocialProfiles,
} from '../../helpers/models/account.model';

@Injectable({
  providedIn: 'root',
})
export class AccountService {
  private httpService = inject(HttpService);

  headers = new HttpHeaders({
    clientId: 'DigiHRMS',
    clientSecret: 'DigiHRMSSecret',
  });
  options = { headers: this.headers };

  // POST Methods
  addBasicDetails(data: AccountBasicDetails): Observable<BaseResponse> {
    return this.httpService.post(
      `/api/Account/InsertAccountBasicInfo`,
      data,
      this.options
    );
  }

  addAddressDetails(data: AddressDetails): Observable<BaseResponse> {
    return this.httpService.post(
      `/api/Account/InsertAccountAddressInfo`,
      data,
      this.options
    );
  }

  addSocialDetails(data: SocialProfiles): Observable<BaseResponse> {
    return this.httpService.post(
      `/api/Account/InsertSocialAccountInfo`,
      data,
      this.options
    );
  }

  addAccessDetails(data: AccessDetails): Observable<BaseResponse> {
    return this.httpService.post(
      `/api/Account/InsertAccountAccessInfo`,
      data,
      this.options
    );
  }

  addLicenseDetails(data: addLicenseDetails): Observable<BaseResponse> {
    return this.httpService.post(
      `/api/Account/SaveAndUpdateAccountLicensePlan`,
      data,
      this.options
    );
  }

  getAccountList(data: AccountList): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Account/GetAccountList?SearchQuery=${data.searchQuery}&PageNumber=${data.pageNumber}&PageSize=${data.pageSize}`,
      this.options
    );
  }

  updateAccountStatus(
    accountId: string,
    isActive: boolean,
    userId: string
  ): Observable<BaseResponse> {
    return this.httpService.post(
      `/api/Account/UpdateAccountStatusByAccountId?isActive=${isActive}&accountId=${accountId}&userId=${userId}`,
      this.options
    );
  }

  getAccountDetailById(accountId: string): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Account/GetAccountDetailListByAccountId?accountId=${accountId}`,
      this.options
    );
  }

  addAccountLocation(data: addAccountLocation): Observable<BaseResponse> {
    return this.httpService.post(
      `/api/Account/SaveAndUpdateAccountLocation`,
      data,
      this.options
    );
  }

  addAccountDepartment(data: addAccountDepartment): Observable<BaseResponse> {
    return this.httpService.post(
      `/api/Account/SaveAndUpdateAccountDepartment`,
      data,
      this.options
    );
  }

  addAccountDesignation(data: addAccountDesignation): Observable<BaseResponse> {
    return this.httpService.post(
      `/api/Account/SaveAndUpdateAccountDesignation`,
      data,
      this.options
    );
  }

  addAccountTeam(data: addAccountTeam): Observable<BaseResponse> {
    return this.httpService.post(
      `/api/Account/SaveAndUpdateAccounTeam`,
      data,
      this.options
    );
  }

  addAccountTeamMember(data: addAccountTeamMember): Observable<BaseResponse> {
    return this.httpService.post(
      `/api/Account/SaveAndUpdateAccounTeamMember`,
      data,
      this.options
    );
  }

  addAccountRole(data: addAccountRole): Observable<BaseResponse> {
    return this.httpService.post(
      `/api/Account/SaveAndUpdateAccountRoles`,
      data,
      this.options
    );
  }
  addAccountCategory(data: addAccountCategory): Observable<BaseResponse> {
    return this.httpService.post(
      `/api/CommonMasterCategory/SaveMasterCategoryRecord`,
      data,
      this.options
    );
  }

  // PUT Methods
  updateBasicDetails(data: AccountBasicDetails): Observable<BaseResponse> {
    return this.httpService.put(
      `/api/Account/UpdateAccountBasicInfo`,
      data,
      this.options
    );
  }

  UpdateAccountProfile(formData: FormData): Observable<BaseResponse> {
    return this.httpService.put(
      `/api/Account/UpdateAccountProfile`,
      formData,
      this.options
    );
  }

  updateAddressDetails(data: AddressDetails): Observable<BaseResponse> {
    return this.httpService.put(
      `/api/Account/UpdateAccountAddressInfo`,
      data,
      this.options
    );
  }

  updateSocialDetails(data: SocialProfiles): Observable<BaseResponse> {
    return this.httpService.put(
      `/api/Account/UpdateSocialAccountInfo`,
      data,
      this.options
    );
  }

  updateAccessDetails(data: AccessDetails): Observable<BaseResponse> {
    return this.httpService.put(
      `/api/Account/UpdateAccountAccessInfo`,
      data,
      this.options
    );
  }

  // GET Methods
  getAccountLocationById(locationId: string): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Account/GetAccountLocationRecordByLocationId?locationId=${locationId}`,
      this.options
    );
  }

  getAccountLocationList(accountId: string): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Account/GetAccountLocationList?accountId=${accountId}`,
      this.options
    );
  }

  getAccountDepartmentById(departmentId: string): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Account/GetAccountDepartmentDataById?id=${departmentId}`,
      this.options
    );
  }

  getAccountDepartmentList(id: string): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Account/GetAccountDepartmentList?locationId=${id}`,
      this.options
    );
  }

  getAccountDesignationById(id: string): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Account/GetAccountDesignationDataById?id=${id}`,
      this.options
    );
  }

  getAccountDesignationList(locationId: string): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Account/GetAccountDesignationList?locationId=${locationId}`,
      this.options
    );
  }

  getAccountTeamById(id: string): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Account/GetAccountTeamById?id=${id}`,
      this.options
    );
  }

  getAccountTeamList(id: string): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Account/GetAccountTeamList?locationId=${id}`,
      this.options
    );
  }

  getAccountTeamMemberById(id: string): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Account/GetAccountTeamMemberDataById?teamMemberId=${id}`,
      this.options
    );
  }

  getAccountTeamMemberList(
    id: string,
    pageNumber: number,
    pageSize: number
  ): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Account/GetAccountTeamMemberList?AccountTeamId=${id}&PageNumber=${pageNumber}&PageSize=${pageSize}`,
      this.options
    );
  }

  getAccountRoleById(id: string): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Account/GetAccountRolesById?id=${id}`,
      this.options
    );
  }

  getAccountCategoryById(
    id: string,
    categoryType: string
  ): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/CommonMasterCategory/GetMasterCategoryByIdRecord?id=${id}&categoryType=${categoryType}`,
      this.options
    );
  }

  getAccountRoleList(id: string): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Account/GetAccountRoleListByLocationId?locationId=${id}`,
      this.options
    );
  }
  getAccountCategoryList(data: any): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/CommonMasterCategory/GetMasterCategoryFilterList?=${data?.parentId}&categoryType=${data?.categoryType}&PageNumber=1&PageSize=100`,
      this.options
    );
  }

  public accountCount() {
    const url = '/api/Account/GetAccountCount';
    return this.httpService.get(url);
  }

  // DELETE Methods
  deleteAccountLocationById(
    locationId: string,
    userId: string
  ): Observable<BaseResponse> {
    return this.httpService.delete(
      `/api/Account/DeleteAccountLocationRecordById?locationId=${locationId}&userId=${userId}`,
      this.options
    );
  }

  deleteAccountDepartmentById(
    departmentId: string,
    userId: String
  ): Observable<BaseResponse> {
    return this.httpService.delete(
      `/api/Account/DeleteAccountDepartmentRecordById?departmentId=${departmentId}&userId=${userId}`,
      this.options
    );
  }

  deleteAccountDesignationById(
    designitionId: string,
    userId: String
  ): Observable<BaseResponse> {
    return this.httpService.delete(
      `/api/Account/DeleteAccountDesignationRecordById?designitionId=${designitionId}&userId=${userId}`,
      this.options
    );
  }

  deleteAccountTeamById(id: string, userId: String): Observable<BaseResponse> {
    return this.httpService.delete(
      `/api/Account/DeleteAccountTeamRecordById?id=${id}&userId=${userId}`,
      this.options
    );
  }

  deleteAccountTeamMemberById(
    id: string,
    userId: String
  ): Observable<BaseResponse> {
    return this.httpService.delete(
      `/api/Account/DeleteAccountTeamMemberRecordById?teamMemberId=${id}&userId=${userId}`,
      this.options
    );
  }

  deleteAccountRoleById(id: string, userId: String): Observable<BaseResponse> {
    return this.httpService.delete(
      `/api/Account/DeleteAccountRolesById?id=${id}&userId=${userId}`,
      this.options
    );
  }
  deleteAccountCategoryById(
    id: string,
    userId: String
  ): Observable<BaseResponse> {
    return this.httpService.delete(
      `/api/CommonMasterCategory/DeleteMasterCategoryRecord?id=${id}&userId=${userId}`,
      this.options
    );
  }

  deleteAccountSocialInfoById(
    id: string,
    userId: String
  ): Observable<BaseResponse> {
    return this.httpService.delete(
      `/api/Account/DeleteAccountSocialInformationById?socialInfoId=${id}&userId=${userId}`,
      this.options
    );
  }
}
