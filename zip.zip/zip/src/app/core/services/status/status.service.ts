import { inject, Injectable } from '@angular/core';
import { BaseResponse, StatusPayload } from '../../helpers/models/common.model';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
import { HttpService } from '../http/http.service';

@Injectable({
  providedIn: 'root',
})
export class StatusService {
  private httpService = inject(HttpService);

  headers = new HttpHeaders({
    clientId: 'DigiHRMS',
    clientSecret: 'DigiHRMSSecret',
  });
  options = { headers: this.headers };

  getStatusMasterList(data: StatusPayload): Observable<BaseResponse> {
    let param = `PageNumber=${data.pageNumber}&PageSize=${data.pageSize}&StatusType=${data.statusType}`;
    if (data?.id) param += `&Id=${data?.id}`;
    return this.httpService.get(
      `/api/StatusMaster/GetStatusMasterList?${param}`,
      this.options
    );
  }
  getDropdownListForStatusMaster(parentId: number): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Dropdown/GetDropdownListForStatusMaster?parentId=${parentId}`,
      this.options
    );
  }
  getDropdownForStatusMasterListBySubLookUpId(subLookUpId: string): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Dropdown/GetDropdownForStatusMasterListBySubLookUpId?subLookUpId=${subLookUpId}`,
      this.options
    );
  }

  getDropdownForStatusMasterListByParentId(id:number): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Dropdown/GetDropdownForStatusMasterList?parentId=${id}`,
      this.options
    );
  }
}
