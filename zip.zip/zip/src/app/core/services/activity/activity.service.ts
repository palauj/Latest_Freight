import { inject, Injectable } from '@angular/core';
import { HttpService } from '../http/http.service';
import { Observable } from 'rxjs';
import { AuthService } from '../auth/auth.service';

@Injectable({
  providedIn: 'root',
})
export class ActivityService {
  private http = inject(HttpService);
  private authService = inject(AuthService);
  constructor() {}

  public addActivity(data: any) {
    const url = `/api/ActivityHistory/SaveActivityHistoryRecord`;
    return this.http.post(url, data);
  }

  public getActivityList(
    id: string,
    relatedTo: string,
    pageNo: number,
    pageSize: number
  ): Observable<any> {
    let userDetail = this.authService.getUserDetail();
    const url = `/api/ActivityHistory/GetActivityHistoryList?ActivityRelatedToId=${id}&AccountId=${userDetail?.accountId}&LocationId=${userDetail.employeeLocation[0]?.locationId}&RelatedTo=${relatedTo}&PageNumber=${pageNo}&PageSize=${pageSize}`;
    return this.http.get(url);
  }

  public getDashboardActivityHistoryList(id: string): Observable<any> {
    const url = `/api/ActivityHistory/GetDashboardActivityHistoryList?employeeId=${id}`;
    return this.http.get(url);
  }
}
