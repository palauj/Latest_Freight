import { inject, Injectable } from '@angular/core';
import { HttpService } from '../http/http.service';
import { HttpHeaders } from '@angular/common/http';
import { BaseResponse, Notes } from '../../helpers/models/common.model';
import { Observable } from 'rxjs';
import { AuthService } from '../auth/auth.service';

@Injectable({
  providedIn: 'root',
})
export class NotesService {
  private httpService = inject(HttpService);
  private authService = inject(AuthService);
  headers = new HttpHeaders({
    clientId: 'DigiHRMS',
    clientSecret: 'DigiHRMSSecret',
  });
  options = { headers: this.headers };
  userDetail = this.authService.getUserDetail();
  addNote(data: Notes): Observable<BaseResponse> {
    return this.httpService.post(`/api/Note/InsertNotes`, data, this.options);
  }

  getAllNotes(
    RelatedToId: string,
    AccountId: string,
    LocationId: string,
    PageNumber: number,
    PageSize: number
  ): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Note/GetNotesRecordsList?RelatedToId=${RelatedToId}&AccountId=${AccountId}&LocationId=${LocationId}&PageNumber=${PageNumber}&PageSize=${PageSize}`,
      this.options
    );
  }

  deleteNote(id: string, userId: string): Observable<BaseResponse> {
    return this.httpService.delete(
      `/api/Note/DeleteNoteRecordById?id=${id}&userId=${userId}`,
      this.options
    );
  }

  getAllActivities(leadId: string): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Lead/GetLeadActivitesByLeadId?leadId=${leadId}`,
      this.options
    );
  }
}
