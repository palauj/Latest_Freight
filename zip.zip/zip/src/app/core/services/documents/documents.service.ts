import { inject, Injectable } from '@angular/core';
import { HttpService } from '../http/http.service';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BaseResponse } from '../../helpers/models/common.model';
import { environment } from 'src/environments/environment';
import { AuthService } from '../auth/auth.service';

@Injectable({
  providedIn: 'root',
})
export class DocumentsService {
  private httpService = inject(HttpService);
  private http = inject(HttpClient);
  private authService = inject(AuthService);

  headers = new HttpHeaders({
    clientId: 'DigiHRMS',
    clientSecret: 'DigiHRMSSecret',
  });
  options = { headers: this.headers };
  userDetail = this.authService.getUserDetail();
  getDocumentById(
    projectId: string,
    relatedto: string
  ): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Document/GetDocumentDataById?projectId=${projectId}&relatedto=${relatedto}`,
      this.options
    );
  }

  getViewDocumentById(documentId: number): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Document/GetViewDocumentDataById?documentId=${documentId}`,
      this.options
    );
  }

  saveAndUpdateDocument(data: FormData): Observable<BaseResponse> {
    return this.httpService.post(
      `/api/Document/SaveAndUpdateDocumentRecord`,
      data,
      this.options
    );
  }

  getDocumentList(
    PageNumber: number,
    PageSize: number,
    RelatedToId: string,
    AccountId: string,
    LocationId: string
  ): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Document/GetDocumentRecordList?PageNumber=${PageNumber}&PageSize=${PageSize}&RelatedToId=${RelatedToId}&AccountId=${AccountId}&LocationId=${LocationId}`,
      this.options
    );
  }

  getViewDocumentByDocumentId(
    id: string,
    relatedToId: string
  ): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Document/GetDocumentDataByDocumentId?id=${id}&relatedToId=${relatedToId}`,
      this.options
    );
  }

  getDownloadViewDocumentById(id: string, mode: string) {
    let apiUrl = environment.apiUrl;
    const url = `/api/Document/GetDownloadViewDocumentById?documentId=${id}&mode=${mode}`;
    // return this.httpService.get(url, { responseType: 'arraybuffer' });
    return this.http.get(apiUrl + url, { responseType: 'arraybuffer' });
  }

  deleteDocumentById(id: string, userId: string): Observable<BaseResponse> {
    return this.httpService.delete(
      `/api/Document/DeleteDocumentRecordByDocumentId?id=${id}&userId=${userId}`,
      this.options
    );
  }
}
