import { inject, Injectable } from '@angular/core';
import { HttpService } from '../http/http.service';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BaseResponse } from '../../helpers/models/common.model';
import { AddDepartment } from '../../helpers/models/department.model';

@Injectable({
  providedIn: 'root',
})
export class DepartmentsService {
  private httpService = inject(HttpService);

  headers = new HttpHeaders({
    clientId: 'DigiHRMS',
    clientSecret: 'DigiHRMSSecret',
  });
  options = { headers: this.headers };

  addDepartment(data: AddDepartment): Observable<BaseResponse> {
    return this.httpService.post(
      `/api/Department/SaveAndUpdateDepartment`,
      data,
      this.options
    );
  }

  editDepartment(id: string): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Department/GetDepartmentDataById?departmentId=${id}`,
      this.options
    );
  }

  getAllDepartment(): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Department/GetDepartmentList`,
      this.options
    );
  }

  deleteDepartment(id: string): Observable<BaseResponse> {
    return this.httpService.delete(
      `/api/Department/DeleteDepartmentRecordById?departmentId=${id}`,
      this.options
    );
  }
}
