import { StickyDirection } from '@angular/cdk/table';
import { StringValueToken } from 'html2canvas/dist/types/css/syntax/tokenizer';

export interface apiResultFormat {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  data: Array<any>;
  totalData: number;
  totalData2?: any;
  statusCode?: string | number;
}

export interface SideBarMenu {
  showMyTab?: boolean;
  menuValue: string;
  claim?: string[] | string,
  route?: string;
  hasSubRoute?: boolean;
  showSubRoute: boolean;
  icon: string;
  base?: string;
  last1?: string;
  last?: string;
  page?: string;
  last2?: string;
  materialicons: string;
  subMenus: SubMenu[];
  dot?: boolean;
  changeLogVersion?: boolean;
  hasSubRouteTwo?: boolean;
  page1?: string;
}

export interface SubMenu {
  menuValue: string;
  materialicons? : string;
  icon?: string;
  claim?: string[] | string,
  route?: string;
  base?: string;
  page?: string;
  page1?: string;
  page2?: string;
  base2?: string;
  base3?: string;
  base4?: string;
  base5?: string;
  base6?: string;
  base7?: string;
  base8?: string;
  role?: number;
  currentActive?: boolean;
  hasSubRoute?: boolean;
  showSubRoute?: boolean;
  customSubmenuTwo?: boolean;
  subMenusTwo?: SubMenu[];
}
export interface SubMenusTwo {
  menuValue: string;
  route?: string;
  base?: string;
  page?: string;
  base2?: string;
  base3?: string;
  base4?: string;
  base5?: string;
  base6?: string;
  base7?: string;
  base8?: string;
  currentActive?: boolean;
  hasSubRoute?: boolean;
  showSubRoute?: boolean;
}

export interface SideBar {
  showMyTab?: boolean;
  tittle: string;
  icon: string;
  claim?: string[];
  showAsTab: boolean;
  separateRoute: boolean;
  role?: number;
  materialicons?: string;
  menu: SideBarMenu[];
  hasSubRoute?: boolean;
}

export interface HorizontalSideBar {
  showMyTab?: boolean;
  tittle: string;
  icon: string;
  showAsTab: boolean;
  separateRoute: boolean;
  materialicons?: string;
  menu: SideBarMenu[];
}

export interface routerlink {
  id?: number;
  type?: number;
  url: string;
  urlAfterRedirects?: string;
}

export interface getUsers {
  id: number;
  name: string;
  designation: string;
  email: string;
  company: string;
  role: string;
  img: string;
}

export interface getTrainType {
  id: number;
  type: string;
  description: string;
  status: string;
}

export interface getTrainList {
  id: number;
  trainingType: string;
  trainer: string;
  employee: string;
  timeDuration: string;
  startDate: string;
  endDate: string;
  description: string;
  cost: string;
  status: string;
  img: string;
}

export interface getTrainer {
  id: number;
  name: string;
  lname: string;
  role: string;
  contactNumber: string;
  mail: string;
  description: string;
  status: string;
  img: string;
}

export interface getTickets {
  ticketId: string;
  ticketSubject: string;
  assignedStaff: string;
  client: string;
  priority: string;
  cc: string;
  assigne: string;
  addfollow: string;
  description: string;
  createdDate: string;
  lastReply: string;
  status: string;
  id: number;
  action: string;
}

export interface getTermination {
  id: number;
  employee: string;
  department: string;
  terminationType: string;
  terminationDate: string;
  reason: string;
  noticedDate: string;
}

export interface getDataTable {
  name: string;
  position: string;
  office: string;
  age: string;
  salary: string;
  id: number;
}

export interface getSubscribed {
  isSelected: boolean;
  image: string;
  company: string;
  trainer: string;
  client: string;
  plan: string;
  startdate: string;
  enddate: string;
  amount: string;
  availability: string;
  checked: string;
  id: number;
}

export interface allroles {
  roleName: string;
  id: number;
}

export interface allLeaveType {
  leaveType: string;
  leaveDays: string;
  id: number;
  status: string;
}

export interface Integration {
  name: string;
  key: string;
  id: number;
  status: string;
}

export interface getTaxes {
  taxName: string;
  taxPercentage: string;
  id: number;
  status: string;
}

export interface getProvidentFund {
  employeeName: string;
  providentFundType: string;
  employeeShare: string;
  organizationShare: string;
  id: number;
}

export interface getPayment {
  invoiceId: string;
  client: string;
  paymenttype: string;
  paidDate: string;
  paidAmount: string;
  id: number;
}

export interface getInvoice {
  id: number;
  number: string;
  client: string;
  project: string;
  email: string;
  tax: string;
  client_address: string;
  billing_address: string;
  estimate_date: string;
  expiry_date: string;
  items: items[];
  totalamount: number;
  discount: number;
  grandTotal: number;
  other_information: string;
  status: string;
}

export interface getTemplates {
  id: number;
  number: string;
  name: string;
  status: string;
}

export interface items {
  item: string;
  description: string;
  unit_cost: string;
  qty: number;
  amount: number;
}

export interface getExpenses {
  item: string;
  purchaseFrom: string;
  purchaseDate: string;
  purchasedBy: string;
  amount: string;
  paidby: string;
  status: string;
  id: number;
}

export interface getResignation {
  id: number;
  employee: string;
  department: string;
  reason: string;
  noticedDate: string;
  resignDate: string;
}

export interface getUserReport {
  id: number;
  name1: string;
  name2: string;
  company: string;
  email: string;
  role: string;
  designation: string;
  status: string;
  img: string;
}

export interface getTaskReport {
  id: number;
  taskname: string;
  startdate: string;
  enddate: string;
  status: string;
}

export interface getProjectReport {
  id: number;
  projecttitle: string;
  clientname: string;
  startdate: string;
  expiredate: string;
  status: string;
}

export interface getPayslipReport {
  id: number;
  name1: string;
  name2: string;
  paidamount: string;
  paymentmonth: string;
  paymentyear: string;
  actions: string;
  img: string;
}

export interface getPaymentReport {
  id: number;
  transactionid: string;
  date: string;
  clientname: string;
  paymentmethod: string;
  invoice: string;
  amount: string;
}

export interface getInvoiceReport {
  id: number;
  number: string;
  client: string;
  project: string;
  email: string;
  tax: string;
  client_address: string;
  billing_address: string;
  invoice_date: string;
  due_date: string;
  totalamount: number;
  discount: number;
  grandTotal: number;
  other_information: string;
  status: string;
}

export interface getEmployeeReport {
  id: number;
  name1: string;
  name2: string;
  employeetype: string;
  email: string;
  department: string;
  designation: string;
  joiningdate: string;
  dob: string;
  marritalstatus: string;
  gender: string;
  terminateddate: string;
  relievingdate: string;
  salary: string;
  address: string;
  contactnumber: string;
  experience: string;
  status: string;
  contactsnumber: string;
  img: string;
  emergencynumber: string;
}

export interface getExpenseReport {
  item: string;
  purchaseFrom: string;
  purchaseDate: string;
  purchasedBy: string;
  amount: string;
  paidBy: string;
  img: string;
  id: number;
  status: string;
}

export interface getLeaveReport {
  id: number;
  name1: string;
  name2: string;
  date: string;
  department: string;
  leavetype: string;
  noofdays: string;
  remainingleave: string;
  totalleaves: string;
  totalleavetaken: string;
  leavecarryforward: string;
  img: string;
}

export interface getDailyReport {
  id: number;
  name1: string;
  name2: string;
  date: string;
  department: string;
  status: string;
  img: string;
}
export interface attendanceReport {
  id: number;
  employee: string;
  role: string;
  date: string;
  workday: string;
  work: string;
  lateArrival: string;
  missingWork: string;
  extraTime: string;
  img: string;
  workdayContent1: string;
  workdayContent2: string;
  workdayButton: string;
  employeeName: string;
  totalDays: string;
  totalTime: string;
  totalTimeWorked: string;
  totalLateArrival: string;
  totalMissedWork: string;
  totalExtraWork: string;
}
export interface getAttendReport {
  id: number;
  name: string;
  subname: number;
  img: string;
  date: string;
  workingdays: number;
  workingemployee: number;
  late: string;
  work: string;
  night: string;
  time: string;
  leave: string;
}
export interface getPromotion {
  id: number;
  employee: string;
  department: string;
  designation: string;
  promotionFrom: string;
  promotionTo: string;
  promotionDate: string;
}
export interface getProjects {
  name: string;
  description: string;
  endDate: string;
  startDate: string;
  priority: string;
  projectleader: string;
  teamMember: string;
  projectId: string;
  id: number;
}
export interface getPolicies {
  policyName: string;
  department: string;
  description: string;
  createdDate: string;
  id: number;
}
export interface getEmployee {
  name: string;
  phone: string;
  email: string;
  department: string;
  role: string;
  id: number;
}
export interface getPerformanceReport {
  id: number;
  designation: string;
  experience: string;
  integrirty: string;
  Marketing: string;
  professionalism: string;
  managementskill: string;
  teamwork: string;
  adminstartion: string;
  criticalthinking: string;
  presentationskil: string;
  conflictmanagement: string;
  qualityofwork: string;
  attendance: string;
  effientcy: string;
  meetdeadline: string;
  department: string;
  addedBy: string;
  createdBy: string;
  status: string;
}
export interface getPerformanceappraisal {
  id: number;
  employee: string;
  designation: string;
  apparaisaldate: string;
  department: string;
  status: string;
}
export interface getAddPayroll1 {
  name: string;
  category: string;
  unitCost: string;
  id: number;
  rate: string;
}
// export interface getAddPayroll2 {
//   name: string;
//   rate: string;
//   id: number;
// }
// export interface getAddPayroll3 {
//   name: string;
//   amount : string;
//   id: number;
// }
export interface getEmployeeSalary {
  employee: string;
  employeeId: string;
  email: string;
  joinDate: string;
  role: string;
  employeeRole: string;
  status: string;
  salary: string;
  Basic: string;
  tdS: string;
  da: string;
  hra: string;
  pf: string;
  conveyance: string;
  leave: string;
  allowance: string;
  proTax: string;
  medAllowance: string;
  labourWelfare: string;
  othersAdd: string;
  othersDed: string;
  esi: string;
  id: number;
}
export interface getLeads {
  leadName: string;
  email: string;
  phone: string;
  project: string;
  status: string;
  created: string;
  id: number;
}
export interface allKnowledgeBase {
  title: string;
  list1: string;
  list2: string;
  list3: string;
  list4: string;
  list5: string;
  id: number;
}
export interface getShortList {
  id: number;
  name1: string;
  name2: string;
  jobtitle: string;
  department: string;
  status: string;
  img: string;
}
export interface getSchedule {
  id: number;
  name1: string;
  name2: string;
  jobtitle: string;
  useravailable: string;
  useravailabletimings: string;
  useravailable1: string;
  useravailabletimings1: string;
  useravailable2: string;
  useravailabletimings2: string;
  image: string;
}
export interface getOffer {
  id: number;
  name1: string;
  name2: string;
  jobtitle: string;
  jobtype: string;
  pay: string;
  annualip: string;
  longtermip: string;
  status: string;
  img: string;
}
export interface getManageResume {
  id: number;
  name1: string;
  name2: string;
  jobtitle: string;
  department: string;
  startdate: string;
  expiredate: string;
  jobtype: string;
  status: string;
  resume: string;
  img: string;
}
export interface getManageJobs {
  jobTitle: string;
  department: string;
  startDate: string;
  expireDate: string;
  id: number;
  staff: string;
  time: string;
  available: string;
}
export interface getVisited {
  id: number;
  jobtitle: string;
  department: string;
  startdate: string;
  expiredate: string;
  jobtype: string;
  status: string;
}
export interface getAllJobs {
  id: number;
  jobtitle: string;
  department: string;
  startdate: string;
  expiredate: string;
  jobtype: string;
  status: string;
}
export interface getinterview {
  id: number;
  jobtitle: string;
  department: string;
  jobtype: string;
}
export interface getOfferedJobs {
  id: number;
  jobtitle: string;
  department: string;
  jobtype: string;
}
export interface allAppliedCandidates {
  name: string;
  email: string;
  phone: string;
  applyDate: string;
  id: number;
  status: string;
}
export interface getInterview {
  id: number;
  questions: string;
  option1: string;
  option2: string;
  option3: string;
  option4: string;
  correctanswer: string;
  questions1: string;
  questions2: string;
  questions3: string;
}
export interface getExpire {
  id: number;
  experience: string;
  status: string;
}
export interface getCandidate {
  id: number;
  name: string;
  mobilenumber: string;
  email: string;
  createddate: string;
  img: string;
}
export interface getAptitudeResult {
  id: number;
  name1: string;
  name2: string;
  jobtitle: string;
  department: string;
  categorywise: string;
  categorywisemark: string;
  categorywise1: string;
  categorywisemark1: string;
  totalmark: string;
  status: string;
  img: string;
}
export interface getAptitudeCandidate {
  name: string;
  email: string;
  phone: string;
  applyDate: string;
  id: number;
}
export interface getTimeSheet {
  id: number;
  employee: string;
  designation: string;
  date: string;
  deadline: string;
  project: string;
  assignedhours: string;
  hrs: string;
  description: string;
  status: string;
  img: string;
}
export interface getShiftSchedule {
  id: number;
  name1: string;
  name2: string;
  img: string;
}
export interface getShiftList {
  id: number;
  shiftname: string;
  minstarttime: string;
  starttime: string;
  maxstarttime: string;
  minendtime: string;
  endtime: string;
  maxendtime: string;
  breaktime: string;
  status: string;
}
export interface getOverTime {
  id: number;
  name: string;
  otDate: string;
  otHrs: string;
  otType: string;
  status: string;
  approvedBy: string;
  description: string;
}
export interface allCustomPolicy {
  id: number;
  name: string;
  days: number;
}
export interface getLeave {
  id: number;
  employeeName: string;
  designation: string;
  leaveType: string;
  from: string;
  to: string;
  noofDays: string;
  remainleaves: string;
  reason: string;
  status: string;
}
export interface getholidays {
  id: number;
  title: string;
  holidaydate: string;
  day: string;
}
export interface getDesignations {
  id?: number;
  designationId: string;
  designation: string;
  departmentName: string;
}
export interface lstEmployee {
  firstname: string;
  lastname: string;
  username: string;
  password: string;
  confirmpassword: string;
  department: string;
  designation: string;
  phone: string;
  email: string;
  mobile: string;
  joindate: string;
  role: string;
  employeeId: string;
  company: string;
  id: number;
  img?: string;
}

export interface members {
  id: number;
  memberName: string;
  departmentName: string;
}

export interface getDepartment {
  id: number;
  departmentName: string;
  members: members[];
}

export interface Employees {
  firstName: string;
  lastname: string;
  username?: string;
  confirmpassword: string;
  department: string;
  designation: string;
  phone?: string;
  email?: string;
  officialEmail:string;
personalEmail:string;
officeContact:string;
personalContact:string;
  mobile: string;
  joindate: string;
  dateOfJoining: string;
  role: string;
  employeeId: string;
  company: string;
  id: number;
  img: string;
  phone1: string;
  username1?: string;
}
export interface getGoalList {
  id: number;
  goalType: string;
  subject: string;
  targetAchivement: string;
  startDate: string;
  endDate: string;
  description: string;
  status: string;
  progress: string;
}
export interface getClient {
  name: string;
  role: string;
  company: string;
  image: string;
  clientId: string;
  email: string;
  phone: string;
  status: string;
  status1: string;
  id: number;
  img: string;
}
export interface companiesList {
  id: number;
  company: string;
}
export interface clientsDatas {
  name: string;
  role: string;
  company: string;
  image: string;
  clientId: string;
  email: string;
  phone: string;
  status: string;
  id: number;
  img?: string;
}
export interface getAssets {
  assetUser: string;
  assetName: string;
  assetId: string;
  assetStatus: string;
  purchaseDate: string;
  warrenty: string;
  warrentyEnd: string;
  Amount: string;
  id: number;
}
export interface getAssetsCategory {
  id: number;
  categoryName: string;
  createdOn: string;
  img: string;
}
export interface getAssetsNew {
  id: number;
  name: string;
  img1: string;
  img2: string;
  assetId: string;
  category: string;
  department: string;
  allocatedTo: string;
  emailId: string;
  status: string;
  status1: string;
  status2: string;
  status3: string;
}
export interface getGoalType {
  id: number;
  type: string;
  description: string;
  status: string;
}
export interface getCategories {
  id: number;
  categoryname: string;
  subcategoryname: string;
}
export interface getBudgets {
  id: number;
  budgettitle: string;
  budgettype: string;
  startdate: string;
  enddate: string;
  totalrevenue: string;
  totalexpenses: string;
  taxamount: string;
  budgetamount: string;
  notes: string;
  categoryname: string;
  subcategoryname: string;
  amount: string;
  revenuedate: string;
}
export interface projectContent {
  project: string;
  projectId: string;
  deadline: string;
  priority: string;
  status: string;
  id: number;
  img: string;
}
export interface getpipeline {
  id: number;
  employeeName: string;
  designation: string;
  leaveType: string;
  from: string;
  to: string;
  noofDays: string;
  remainleaves: string;
  reason: string;
  status: string;
  pipelineName: string;
  totalDealValue: string;
  noOfDeals: string;
  stages: string;
  createdDate: string;
}
export interface getcontactlist {
  id: number;
  name: string;
  position: string;
  phone: string;
  email: string;
  tags: string;
  location: string;
  rating: string;
  owner: string;
  contact: string;
  status: string;
  img: string;
  isRating: boolean;
}
export interface url {
  url: string;
}
export interface companies {
  id?: number;
  aboutCompany: string;
  accountId: string;
  companyName: string;
  email: string;
  fax?: string;
  isActive?: boolean;
  ownerName: string;
  phone1: string;
  phone2?: string;
  profilePicture?: string;
  tags: string;
  website?: string;
  status?: string;
  isRating?: string;
}
export interface leads {
  id: number;
  leadName: string;
  phone: string;
  email: string;
  leadStatus: string;
  companyName: string;
  rating: string;
  owner: string;
  status: string;
  static: string;
  img: string;
  createdDate: string;
  leadOwner: string;
  isRating: boolean;
}
export interface deals {
  id: number;
  dealName: string;
  tags: string;
  expectedClosedDate: string;
  owner: string;
  status: string;
  probability: string;
  img: string;
  stage: string;
  dealValue: string;
  isRating: boolean;
}
export interface attendanceReports {
  id: number;
  sNo: string;
  date: string;
  clockIn: string;
  clockOut: string;
  workStatus: string;
}
export interface getTeams {
  id: number;
  name: string;
  departmentName: string;
  numberOfMembers: number;
}
export interface activities {
  id: number;
  title: string;
  activityType: string;
  dueDate: string;
  owner: string;
  createdAt: string;
}
export interface datatables {
  isSelected: boolean;
  sNo?: number;
  name?: string;
  position?: string;
  office?: string;
  age?: string;
  salary?: string;
  startDate?: string;
  id?: string;
}
export interface tablePageSize {
  skip: number;
  limit: number;
  pageSize: number;
}
export interface Star {
  show?: boolean;
  half?: boolean;
}

export interface DepartmentDailog {
  leaveType: string;
  leave: string;
  selectField?: string;
  accountId: string;
  id?: string;
  title: string;
  fieldName: string;
  fieldType: string;
  submitBtn: string;
  closeBtn: string;
  isDepartment: boolean;
  departments?: getDepartment[];
}

export interface ShareProject {
  title: string;
  subTitle: string;
  submitBtn: string;
  closeBtn: string;
}

export interface PreviewFile {
  title: string;
  file: File;
  src: string;
  submitBtn: string;
  closeBtn: string;
}

export interface AddTask {
  title: string;
  submitBtn: string;
  closeBtn: string;
}

export interface Employee {
  firstName: string;
  lastName: string;
  userName: string;
  email: string;
  password: string;
  confirmPassword: string;
  employeeId: string;
  joiningDate: string;
  phone: string;
  company: string;
  department: string;
  designation: string;
  reportTo: string;
  modulePermission: Module;
}

export interface Module {
  holidays: Permission[];
  leaves: Permission[];
  clients: Permission[];
  projects: Permission[];
  tasks: Permission[];
  chats: Permission[];
  assests: Permission[];
  timingSheets: Permission[];
}

export interface Permission {
  read: boolean;
  write: boolean;
  create: boolean;
  delete: boolean;
  import: boolean;
  export: boolean;
}
export interface LookUp {
  lookUpId?: string;
  subLookUpId?: string;
  lookUpName: string;
  edit: string;
  isActive: boolean;
  createdDate: string;
  collapsed?: boolean;
}
export interface LookUpAction {
  subLookUpId?: string;
  lookUpId?: string;
  lookUpName: string;
  isActive: boolean;
  edit: string;
  collapsed?: boolean;
}
export interface designation {
  designationId: string;
  designationName?: string;
  createdDate: string;
  isActive: boolean;
}
export interface department {
  departmentId?: string;
  departmentName?: string;
  createdDate?: string;
  isActive?: boolean;
}
export interface Pages {
  id: string;
  name: string;
  code: string;
  order: Number;
  createdDate: string;
  collapsed?: boolean;
  isActive?: boolean;
}

export interface PageAction {
  id: string;
  pageId: string;
  name: string;
  order: Number;
  edit: string;
  isActive?: boolean;
  collapsed?: boolean; // Add the collapsed property
}
export interface LookUpPages {
  id: string;
  name: string;
  code: string;
  order: Number;
  createdDate: string;
  collapsed?: boolean;
  isActive?: boolean;
}

export interface LookUpPageAction {
  id: string;
  pageId: string;
  name: string;
  order: Number;
  edit: string;
  isActive?: boolean;
  collapsed?: boolean; // Add the collapsed property
}

export interface Role {
  roletId?: string;
  roleName?: string;
  createdDate?: string;
  isActive?: boolean;
}
export interface Country {
  id: string;
  name: string;
  isActive?: boolean;
  nIndex?: any;
}
export interface State {
  countryId: string;
  name: string;
  isActive?: boolean;
  nIndex: number;
}

export interface City {
  countryId: string;
  stateId: string;
  name: string;
  isActive?: boolean;
  nIndex: number;
}
export interface EmailSMTPSetting {
  id?: string;
  host: string;
  userName: string;
  password: string;
  isEnableSSL: boolean;
  port: number;
  isDefault: boolean;
}
export interface CompanyList {
  id?: string;
  locationId: string;
  accountId: string;
  accountName: string;
  cityId:  number;
  cityName: string;
  companyAddress: string;
  companyCode: string;
  companyName: string;
  contactPersonName: string;
  countryId: string;
  countryName: string;
  createdDate: string;
  createdIP: string;
  email: string;
  isActive: string;
  locationName: string;
  modifiedIP: string;
  name: string;
  phone: string;
  stateId: string;
  stateName: string;
  

}

export interface leaveEmpList {
  userId?: string;
  leaveId: string;
  leaveTransactionNumber: string;
  leaveEmpId: string;
  leaveLocation: string;
  leaveTypeRequest: string;
  leaveFromDateTime: string;
  leaveToDateTime: string;
  leaveHalf: string;
  leaveRemark: string;
  leaveEmergencyNo: string;
  leaveStatus: string;
  leaveTypeApproved: string;
  leaveTypeApproveCount: string;
  leaveApprovedById: string;
  leaveApprovedByName: string;
  leaveApprovedByRemarks: string;
  leaveApprovedByHrId: string;
  leaveApprovedByHrName: string;
  leaveApprovedByHrRemarks: string;
  leaveEmailStatusMgr: string;
  leaveEmailStatusMgrApproved: string;
  leaveEmailStatusMgrRejected: string;
  leaveEmailStatusHr: string;
  leaveEmailStatusHrApproved: string;
  leaveSmsStatusMgr: string;
  leaveSmsStatusHr: string;
  leaveAutoApprovalStatus: string;
  isDeleted: Boolean;
  isActive: Boolean;
  createdDate: string;
  createdBy: string;
  modifiedDate: string;
  modifiedBy: string;
  deletedDate: string;
  deletedBy: string;
  createdIp: string;
  modifiedIp: string;
  accountId: string;
  locationId: string;
  accountName: string;
  locationName: string;
}

export interface EmpChartInsert {
  accountID: string;
  locationID: string;
  employeeID: string;
  startDate: string;
  endDate: string;
  ip: string;
  userId: string;
}

export interface EmpOutstationTimesheet {
  outstationId: string;
  empId: string;
  fromLocId: string;
  fromLocName: string;
  accountId: string;
  locationId: string;
  fromDateTime: string;
  toDateTime: string;
  remark: string;
  amountRequired: string;
  ip: string;
  userId: string;
}

export interface EmpODInsertTimesheet {
  accountId: string;
  locationId: string;
  id: string;
  empId: string;
  fromDateTime: string;
  toDateTime: string;
  status: string;
  actionType: string;
  taskId: string;
  taskNumber: string;
  remark: string;
  ip: string;
  userId: string;
}

export interface EmpChartDetails {
  id?: string;
  workingDate: string;
  chartDateType: string;
  chartLocationName: string;
  outstation: string;
  inTime: string;
  outTime: string;
  timeDiff: string;
  webInTime: string;
  webOutTime: string;
  date: string;
  webTimeDiff: string;
  chartDateRemarks: string;
  chartModifyFlag: string;
  odCount: string;
  odDuration: string;
  tsCount: string;
  tsDuration: string;
  extraDuration: string;
  expClaimed: string;
  expApproved: string;
}
export interface Product {
  productId: number;
  productName: string;
  productDescription: string;
  isActive: boolean;
}

export interface OutsourceClient {
  clientId?: string;
  clientName: string;
  accountId: string;
  accountName: string;
  cityId: number;
  cityName: string;
  clientAddress: string;
  clientCode: null;
  countryId: string;
  countryName: string;
  createdIP: string;
  email: string;
  locationId: string;
  locationName: string;
  modifiedIP: string;
  phone: string;
  stateId: string;
  stateName: string;
}

export interface ConsultantAgency {
  venderId?: string;
  venderCode: string;
  venderName: string;
  accountId: string;
  accountName: string;
  cityId: number;
  cityName: string;
  contactPersonName: string;
  countryId: string;
  countryName: string;
  createdDate: string;
  createdIP: string;
  email: string;
  locationId: string;
  locationName: string;
  modifiedIP: string;
  phone: string;
  stateId: string;
  stateName:string;
  venderAddress: string;
  
}

export interface Ticket{
  assignLevel: string;
  assignToId: string;
  assignToName: string;
  closeTime: string;
  createdBy: string;
  createdDate: string;
  createdIp: string;
  deletedBy: string;
  deletedDate: string;
  description: string;
  documentCount: string;
  endRemarks: string;
  endTime: string;
  firstOpenTime: string;
  id?: string;
  isDeleted: string;
  modifiedBy: string;
  modifiedDate: string;
  modifiedIp: string;
  openTime: string;
  ownerId?: string;
  ownerName: string;
  percentage: string;
  relatedTo: string;
  relatedToId: string;
  relatedToName?: string;
  statusDesc: string;
  statusId: string;
  statusReasonDesc: string;
  statusReasonId: string;
  subject: string;
  targetEndTime: string;
  transactionNumber: string;
  priority: string;
  category: string;
  subCategory: string;

 }

 export interface IpData{
  userId: string;
  createdIP: string;
  remoteIP: string;
  remarks: string;
  isActive: boolean;
  }