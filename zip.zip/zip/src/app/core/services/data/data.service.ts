import { inject, Injectable } from '@angular/core';
import { Observable, BehaviorSubject, map } from 'rxjs';
import {
  HorizontalSideBar,
  SideBar,
  SideBarMenu,
  apiResultFormat,
  routes,
} from '../../core.index';
import { HttpService } from '../http/http.service';
import { BaseResponse } from '../../helpers/models/common.model';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root',
})
export class DataService {
  constructor(private httpClient: HttpClient) {}

  addEmployee(newEmployee: any) {
    throw new Error('Method not implemented.');
  }
  updateEmployee(updatedEmployee: any) {
    throw new Error('Method not implemented.');
  }
  deleteEmployee(employeeId: number) {
    throw new Error('Method not implemented.');
  }
  allAppliedCandidates!: Array<object>;

  // constructor(private http: HttpClient) {}
  private http = inject(HttpService);

  public getAssetsCount(accountId: string, locationId: string) {
    const url = `/api/Assets/GetAssetsCount?accountId=${accountId}&locationId=${locationId}`;
    return this.http.get(url);
  }

  public getPageList(param: any): Observable<BaseResponse> {
    const url = `/api/Page/GetPageList?SearchQuery=${param?.search}&PageNumber=${param?.pageNo}&PageSize=${param?.pageSize}`;
    return this.http.get(url);
  }

  public getRoleList(param: any): Observable<BaseResponse> {
    const url = `/api/Role/GetRoleList?SearchQuery=${param?.search}&PageNumber=${param?.pageNo}&PageSize=${param?.pageSize}`;
    return this.http.get(url);
  }

  public getLookUpList(param: any): Observable<BaseResponse> {
    const url = `/api/LookUp/GetLookUpList?SearchQuery=${param?.search}&PageNumber=${param?.pageNo}&PageSize=${param?.pageSize}`;
    return this.http.get(url);
  }
  public getDepartmentist(param: any): Observable<BaseResponse> {
    const url = `/api/Department/GetDepartmentList?SearchQuery=${param?.search}&PageNumber=${param?.pageNo}&PageSize=${param?.pageSize}`;
    return this.http.get(url);
  }
  public getLookup(param: any): Observable<BaseResponse> {
    const url = `/api/Employee/GetEmployeeRecordList?SearchQuery=${param?.search}&PageNumber=${param?.pageNo}&PageSize=${param?.pageSize}`;
    return this.http.get(url);
  }
  public getallAppliedCandidates(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/applied-candidate.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getholidays(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/holidays.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getLeave(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/leave-admin.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getTimeFormats(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/timeFormat.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getDepartment(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/department.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getDesignations(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/designation.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getEmployee(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/management.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getTeams(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/teams.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getTimeSheet(): Observable<apiResultFormat> {
    // return this.http.get('assets/JSON/timesheet.json')
    return this.http.get('/assets/JSON/timesheet.json');
    // .pipe(
    //   map((res: apiResultFormat) => {
    //     return res;
    //   })
    // );
  }
  public getShiftSchedule(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/shift.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getShiftList(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/shiftlist.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getOverTime(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/overtime.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getClient(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/clients.json');
  }
  public getProjects(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/projects.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }

  public getTickets(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/tickets.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getEstimate(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/estimates.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }

  public getTemplate(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/templates.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }

  public getInvoice(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/invoice-page.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getPayment(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/payments.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getExpenses(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/expenses.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getProvidentFund(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/provident-fund.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getTaxes(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/taxes.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getCategories(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/categories.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getBudgets(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/budgets.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getEmployeeSalary(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/employee-salary.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getAddPayroll1(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/payroll-item1.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getAddPayroll2(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/payroll-item2.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getAddPayroll3(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/payroll-item3.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getPolicies(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/policies.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getExpenseReport(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/expense-report.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getInvoiceReport(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/invoice-report.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getPaymentReport(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/payment-report.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getProjectReport(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/project-report.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }

  public getTaskReport(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/task-report.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getUserReport(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/user-report.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getEmployeeReport(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/employee-report.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getPayslipReport(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/payslip-report.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getAttendanceReport(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/attendance-report.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getAttendReport(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/attend-report.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getLeaveReport(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/leave-report.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getDailyReport(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/daily-report.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getPerformanceReport(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/performance-indicator.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getPerformanceappraisal(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/performance-appraisal.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getGoalList(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/goal-list.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getGoalType(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/goal-type.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getTrainList(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/training-list.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getTrainType(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/training-type.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getTrainer(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/trainers.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getPromotion(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/promotion.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getResignation(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/resignation.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getTermination(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/termination.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getAssets(): Observable<apiResultFormat> {
    return this.http.get('assets/JSONassets-page.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getAllJobs(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/user-dashboard-all.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getSavedJobs(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/user-dashboard-saved.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getAppliedJobs(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/user-dashboard-applied.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getOfferedJobs(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/user-dashboard-offered.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getVisited(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/user-dashboard-visited.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getArchived(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/user-dashboard-archived.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getManageJobs(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/manage-jobs.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getManageResume(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/manage-resumes.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getShortList(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/shortlist-candidate.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getInterview(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/interview-questions.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getOffer(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/offer-approval.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getExpire(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/experience-level.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getSchedule(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/schedule-timing.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getCandidate(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/candidates-list.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getAptitudeResult(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/aptitude-result.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getAptitudeResults(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/aptitude-result.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getAptitudeCandidate(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/applied-candidate.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getUsers(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/users.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getSubscribed(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/subscribed-company.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getDataTable(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/form-tables.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getAssetsCategory(): Observable<apiResultFormat> {
    return this.http.get('assets/JSONassets-category.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getAssetsNew(): Observable<apiResultFormat> {
    return this.http.get('assets/JSONassets-new.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getAssetsReports(): Observable<apiResultFormat> {
    return this.http.get('assets/JSONassets-reports.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getProjectContent(): Observable<any> {
    return this.httpClient.get('assets/JSON/project-content.json');
  }
  public getinterview(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/interview.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getPipeline(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/pipeline.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getContactlist(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/contact-list.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getCompanies(): Observable<any> {
    return this.httpClient.get('assets/JSON/companies.json');
  }
  public getLeads(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/leads-list.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public getDeals(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/deals-list.json');
    // .pipe(
    //   map((res: apiResultFormat) => {
    //     return res;
    //   })
    // );
  }
  public getActivities(): Observable<apiResultFormat> {
    return this.http.get('assets/JSON/activity.json').pipe(
      map((res: apiResultFormat) => {
        return res;
      })
    );
  }
  public sideBar: SideBar[] = [
    {
      tittle: 'Super Admin',
      icon: 'layers',
      claim: ['Super_Admin_View'],
      showAsTab: false,
      separateRoute: false,
      menu: [
        {
          menuValue: 'Super Admin',
          claim: ['Super_Admin_View'],
          route: 'accounts',
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'user',
          base: 'accounts',
          page1: 'account-page',
          materialicons: 'person',
          subMenus: [
            {
              claim: ['DASH_SADMIN'],
              menuValue: 'Dashboard',
              route: '/admin/super-admin-dashboard',
              base: 'admin',
            },
            {
              claim: [
                'ACC_VIEW',
                'ACC_ADD',
                'ACC_EDIT',
                'ACC_UPDATE',
                'ACC_DEL',
                'ACC_EXPO',
                'ACC_HIST',
                'ACC_LOC_VIEW',
              ],
              menuValue: 'Accounts',
              route: '/admin/accounts',
              base: 'admin',
            },
            {
              claim: [
                'SA_SUBS_VIEW',
                'SA_SUBSCRIPTIONS_ADD',
                'SA_SUB_UPDATE',
                'SA_SUB_DEL',
              ],
              menuValue: 'Subscriptions',
              route: '/admin/subscriptions',
              base: 'admin',
            },
            {
              claim: [
                'SA_PKG_VIEW',
                'SA_PKG_ADD',
                'SA_PKG_UPDATE',
                'SA_PKG_DEL',
                'SA_PKG_EXPO',
              ],
              menuValue: 'Packages',
              route: '/admin/packages',
              base: 'admin',
            },
            // {
            //   claim: ['SuperAdmin_Domain_View', 'SuperAdmin_Domain_Add', 'SuperAdmin_Domain_Update', 'SuperAdmin_Domain_Delete'],
            //   menuValue: 'Domain',
            //   route: '/admin/accounts',
            //   base: 'admin',
            // },
            {
              claim: [
                'SA_TRASA_VIEW',
                'SA_TRANS_ADD',
                'SA_TRANS_UPDATE',
                'SA_TRANS_DEL',
                'SA_TRANS_EXPO',
              ],
              menuValue: 'Transaction',
              route: '/admin/transactions',
              base: 'admin',
            },
          ],
        },
      ],
    },
    {
      tittle: 'Main',
      icon: 'airplay',
      claim: ['DASH_DEAL', 'DASH_ADMIN', 'DSH_EMP', 'DASH_ACC', 'DASH_LED'],
      showAsTab: true,
      separateRoute: false,
      menu: [
        {
          menuValue: 'Dashboard',
          route: routes.dashboard,
          claim: ['DASH_DEAL', 'DASH_ADMIN', 'DSH_EMP', 'DASH_ACC', 'DASH_LED'],
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'dashcube',
          base: 'dashboard',
          materialicons: 'home',
          subMenus: [
            {
              claim: ['DASH_ADMIN'],
              menuValue: 'Admin Dashboard',
              route: '/admin/dashboard',
              base: 'admin',
            },
            {
              claim: ['DSH_EMP'],
              menuValue: 'Employee Dashboard',
              route: '/admin/dashboard/employee',
              base: 'employee',
            },
            {
              claim: ['DASH_DEAL'],
              menuValue: 'Deals Dashboard',
              route: '/admin/dashboard/deals',
              base: 'deals',
            },
            {
              claim: ['DASH_LED'],
              menuValue: 'Leads Dashboard',
              route: '/admin/dashboard/leads',
              base: 'leads',
            },
          ],
        },
        {
          menuValue: 'Apps',
          claim: ['USR_ADD_USER'],
          route: routes.apps,
          hasSubRouteTwo: true,
          showSubRoute: false,
          icon: 'cube',
          base: 'apps',
          materialicons: 'dashboard',
          subMenus: [
            {
              claim: ['USR_ADD_USER'],
              menuValue: 'Chat',
              route: routes.chat,
              base: 'apps',
              customSubmenuTwo: false,
            },
            {
              menuValue: 'Calls',
              customSubmenuTwo: true,
              hasSubRoute: true,
              showSubRoute: false,
              route: routes.calendar,
              page1: 'voice-call',
              page2: 'videocall',
              subMenusTwo: [
                {
                  menuValue: 'Voice Call',
                  route: routes.voicecall,
                  hasSubRoute: false,
                  showSubRoute: false,
                  page: 'call',
                },
                {
                  menuValue: 'Video Call',
                  route: routes.videocall,
                  hasSubRoute: false,
                  showSubRoute: false,
                },
                {
                  menuValue: 'Outgoing Call',
                  route: routes.outgoingcall,
                  hasSubRoute: false,
                  showSubRoute: false,
                },
                {
                  menuValue: 'Incoming Call',
                  route: routes.incomingcall,
                  hasSubRoute: false,
                  showSubRoute: false,
                },
              ],
            },
            {
              menuValue: 'Calendar',
              hasSubRoute: true,
              showSubRoute: false,
              route: routes.calendar,
              customSubmenuTwo: false,
            },
            {
              menuValue: 'Contacts',
              hasSubRoute: true,
              showSubRoute: false,
              route: routes.contacts,
              customSubmenuTwo: false,
            },
            {
              menuValue: 'Email',
              hasSubRoute: true,
              showSubRoute: false,
              route: routes.email,
              customSubmenuTwo: false,
            },
            {
              menuValue: 'File Manager',
              hasSubRoute: true,
              showSubRoute: false,
              route: routes.filemanager,
              customSubmenuTwo: false,
            },
          ],
        },
      ],
    },
    {
      tittle: 'Project',
      icon: 'layers',
      showAsTab: false,
      separateRoute: false,
      claim: ['PROJECT_VIEW'],
      menu: [
        {
          menuValue: 'Clients',
          claim: [
            'CLIENT_DEL',
            'CLIENT_EXPO',
            'CLIENT_ADD',
            'CLIENT_UPDATE',
            'CLIENT_VIEW',
          ],
          route: routes.clientPage,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'users',
          base: 'clients',
          page1: 'client-page',
          materialicons: 'person',
          subMenus: [],
        },
        {
          claim: [
            'Project_History',
            'Project_View',
            'Project_Add',
            'Project_Export',
            'Project_Delete',
            'Project_Edit',
          ],
          menuValue: 'Projects',
          route: 'admin/projects',
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'rocket',
          base: 'projects',
          materialicons: 'topic',
          subMenus: [
            {
              claim: ['PRO_HISTRY', 'PROJECT_VIEW', 'PROJ_DEL', 'PROJECT_EDIT'],
              menuValue: 'Projects',
              route: routes.projects,
              base: 'project-page',
              base2: 'project-list',
            },
            {
              claim: [
                'TSK_EXPO',
                'TASK_HIST',
                'TSK_VIEW',
                'TASK_ADD',
                'TSK_DEL',
                'TASK_EDIT',
              ],
              menuValue: 'Tasks',
              route: routes.workItems,
              base: 'project-page',
              base2: 'project-list',
            },
            {
              claim: ['DASH_TASK'],
              menuValue: 'Task Board',
              route: routes.taskboard,
              base: 'project-page',
              base2: 'project-list',
            },
          ],
        },
      ],
    },
    {
      tittle: 'HRM',
      icon: 'layers',
      showAsTab: false,
      separateRoute: false,
      claim: ['EMP_VIEW'],
      menu: [
        {
          menuValue: 'Employees',
          route: 'admin/employees',
          claim: ['EMP_ADD', 'EMP_VIEW', 'EMP_UPDATE', 'EMP_DEL'],
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'user',
          base: 'employees',
          materialicons: 'people',
          subMenus: [
            {
              claim: ['EMP_ADD', 'EMP_UPDATE', 'EMP_DEL'],
              menuValue: 'Employee Lists',
              route: 'employees/employee-list',
              base: 'employee-page',
              base2: 'employee-list',
            },
            {
              menuValue: 'Holidays',
              route: routes.holidays,
              base: 'holidays',
              claim: [
                'EMP_HOLI_VIEW',
                'EMP_HOLI_DEL',
                'EMP_HOLI_ADD',
                'EMP_HOLI_EDIT',
              ],
            },
            {
              menuValue: 'Calendar Master',
              route: routes.calendarMaster,
              base: 'calendar-master',
              claim: [
                'CALNDER_ADD',
                'CALENDER_VIEW',
                'CALENDER_DEL',
                'CALENDER_EDIT',
                'CALENDER_EXPO',
              ],
            },
            {
              menuValue: 'Policies',
              route: routes.policy,
              base: 'policies',
              claim: [
                'CALNDER_ADD',
                'CALENDER_VIEW',
                'CALENDER_DEL',
                'CALENDER_EDIT',
                'CALENDER_EXPO',
              ],
            },
          ],
        },
        {
          claim: [
            'TICKET_HSTRY',
            'TICKET_VIEW',
            'TICKET_ADD',
            'TICKET_EXPO',
            'TICKET_DEL',
            'TICKET_EDIT',
            'TICKET_ATTACHMENT',
          ],
          menuValue: 'Tickets',
          route: routes.ticketpage,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'ticket',
          base: 'tickets',
          materialicons: 'leaderboard',
          subMenus: [
            {
              claim: [
                'TICKET_HSTRY',
                'TICKET_VIEW',
                'TICKET_ADD',
                'TICKET_EXPO',
                'TICKET_DEL',
                'TICKET_EDIT',
                'TICKET_ATTACHMENT',
              ],
              menuValue: 'Tickets',
              route: routes.ticketpage,
              base: 'ticket-page',
            },
            {
              claim: [
                'TICKET_HSTRY',
                'TICKET_VIEW',
                'TICKET_EDIT',
                'TICKET_ATTACHMENT',
              ],
              menuValue: 'Tickets Detail',
              route: routes.ticketDetails,
              base: 'ticket-details',
            },
          ],
        },
        {
          claim: ['ATTEN_VIEW'],
          menuValue: 'Attendance',
          route: routes.leaves,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'user-check',
          base: 'Leaves',
          materialicons: 'leaderboard',
          subMenus: [
            {
              menuValue: 'Leave Dashboard',
              route: routes.leaveDashboard,
              base: 'leave-dashboard',
              claim: ['LEAVE_DASH_EMP'],
            },
            {
              menuValue: 'Leave Approval',
              route: routes.leaveApproval,
              base: 'leave-approval',
              claim: [
                'LEAVE_APPRO_VIEW',
                'LEAVE_APPRO_EXPO',
                'LEAVE_APPRO_UPDATE',
                'LEAVE_APPR_HR',
              ],
            },
            {
              menuValue: 'Leaves (Admin)',
              route: routes.leaveadmin,
              base: 'leave-admin',
              claim: [
                'EMP_LEAVE_ADM_VIEW',
                'EMP_LEAV_ADM_EDIT',
                'EMP_LEAVE_ADM_ADD',
                'EMP_LEAVE_ADM_DEL',
              ],
            },
            {
              menuValue: 'Leaves (Employee)',
              route: routes.leaveemployee,
              base: 'leave-employee',
              claim: [
                'EMP_LEAVE_ADD',
                'EMP_LEAVE_VIEW',
                'EMP_LEAVE_EDIT',
                'EMP_LEAVE_EDIT',
              ],
            },
            {
              menuValue: 'Leave Settings',
              route: routes.leavesettings,
              base: 'leave-settings',
              claim: ['EMP_LEAVE_SET_EDIT'],
            },
            {
              menuValue: 'Attendance (Admin)',
              route: routes.attendanceadmin,
              base: 'attendance-admin',
              claim: [
                'EMP_ATD_ADM_VIEW',
                'EMP_ATD_ADM_ADD',
                'EMP_ATD_ADM_EDIT',
                'EMP_ATD_ADM_DELETE',
              ],
            },
            {
              menuValue: 'Attendance (Employee)',
              route: routes.attendanceemployee,
              base: 'attendance-employee',
              claim: [
                'EMP_ATD_ADD',
                'EMP_ATD_EMP_VIEW',
                'EMP_ATD_EDIT',
                'EMP_ATD_EMP_DEL',
              ],
            },
            // {
            //   menuValue: 'Leave Balance',
            //   route: routes.leaveBalance,
            //   base: 'leave-balance',
            //   claim: ['EMP_LEAV_BAL_VIEW', 'EMP_LEAV_DEL'],
            // },
            // {
            //   menuValue: 'Attendance Track',
            //   route: routes.attenTrack,
            //   base: 'attendance-track',
            //   claim: ['ATTENDANCE_TRACK_VIEW'],
            // },
            // {
            //   menuValue: 'Attendance Report',
            //   route: routes.attenReport,
            //   base: 'attendance-report',
            //   claim: ['ATTEN_REPO_VIEW'],
            // },
            {
              menuValue: 'Employee Daychart',
              route: routes.empDaychart,
              base: 'empDaychart',
              claim: ['EMP_CHART_VIEW'],
            },
            {
              menuValue: 'Timesheet',
              route: routes.timesheet,
              base: 'timesheet',
              claim: ['EMP_TS_EDIT', 'EMP_TS_ADD', 'EMP_TS_VIEW'],
            },
            {
              menuValue: 'Outstation Duty',
              route: routes.outStationTimesheet,
              base: 'outStationTimesheet',
              claim: ['OUTSTA_ADD', 'OUTSTA_DUTY_EDIT', 'OUTSTATION_VIEW'],
            },
            {
              menuValue: 'Out Of Duty',
              route: routes.OdTimesheet,
              base: 'out-of-duty',
              claim: ['OUTDUTY_EDIT', 'OUT_DUTY_ADD', 'OUTDUTY_VIEW'],
            },
            {
              menuValue: 'Expense',
              route: routes.Expense,
              base: 'expense',
              claim: [
                'EMP_EXPENSE_VIEW',
                'EMP_EXPENSE_EDIT',
                'EMP_EXPENSE_ADD',
              ],
            },
            {
              menuValue: 'Employee Roaster',
              route: routes.shiftschedule,
              base: 'employee-roaster',
              claim: [
                'EMP_Roaster_View',
                'EMP_Roaster_Add',
                'EMP_Roaster_Edit',
              ],
            },
            {
              menuValue: 'Overtime',
              route: routes.overtime,
              base: 'overtime',
              claim: ['OVERTIME_EDIT', 'OVERTIME_ADD', 'OVERTIME_VIEW'],
            },
          ],
        },
      ],
    },
    {
      tittle: 'crm',
      icon: 'file',
      showAsTab: false,
      separateRoute: false,
      claim: ['CRMVIEW'],
      menu: [
        {
          claim: ['ASSET_VIEW'],
          menuValue: 'Asset',
          route: routes.assets,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'chalkboard',
          base: 'asset',
          materialicons: 'chalkboard',
          subMenus: [
            {
              claim: ['DASH_ASSET'],
              menuValue: 'Dashboard',
              route: routes.assetDashboard,
              base: 'assets-dashboard',
            },
            {
              claim: ['ASSET_ADD', 'ASSET_EDIT'],
              menuValue: 'Assets List',
              route: routes.assetRegistration,
              base: 'Add-assets',
            },
            {
              claim: ['ASSET_VIEW'],
              menuValue: 'Asset Tracking',
              route: routes.assetTrack,
              base: 'assets-track',
            },
            {
              claim: ['ASSETS_REPO'],
              menuValue: 'Assets Product',
              base: 'master',
              route: '/admin/master/product',
            },
            {
              claim: [
                'ASSETS_REPORT_DELETE',
                'ASSET_REPO_EDIT',
                'ASSETS_REPO',
                'ASSET_REPO_VIEW',
                'ASSET_REPO_EXPO',
              ],
              menuValue: 'Report & Approval',
              route: routes.assetWokflow,
              base: 'assets-workflow',
            },
            {
              claim: [
                'Assets_View',
                'Assets_Add',
                'Assets_Edit',
                'Assets_Delete',
              ],
              menuValue: 'Cost Management',
              route: routes.assetCost,
              base: 'assets-cost',
            },
          ],
        },
        {
          claim: ['CNT_EXPO', 'CNT_VIEW', 'CNT_ADD', 'CNT_DEL', 'CNT_EDIT'],
          menuValue: 'Contacts',
          route: routes.contactList,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'user-shield',
          last1: 'contact-details',
          last2: 'contact-grid',
          materialicons: 'confirmation_number',
          subMenus: [],
        },
        {
          claim: [
            'DEAL_VIEW',
            'DEALS_EDIT',
            'DEAL_ADD',
            'DEAL_DEL',
            'DEAL_EXPO',
          ],
          menuValue: 'Deals',
          route: routes.dealsList,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'cubes',
          last1: 'deals-details',
          last2: 'deals-kanban',
          materialicons: 'account_balance_wallet',
          subMenus: [],
        },
        {
          claim: [
            'CMP_LEDS',
            'LEAD_EDIT',
            'LED_VIEW',
            'LEAD_DEL',
            'LED_EXPO',
            'LED_BULK',
            'LEAD_BULK_HIST',
          ],
          menuValue: 'Leads',
          route: routes.leadsList,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'chart-area',
          last1: 'leads-kanban',
          last2: 'leads-details',
          materialicons: 'request_quote',
          subMenus: [],
        },
        {
          menuValue: 'Pipeline',
          route: routes.pipeline,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'exchange-alt',
          materialicons: 'verified_user',
          subMenus: [],
        },
        {
          menuValue: 'Analytics',
          route: routes.analytics,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'user-secret',
          materialicons: 'report_gmailerrorred',
          subMenus: [],
        },
        {
          menuValue: 'Activities',
          route: routes.activities,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'directions',
          materialicons: 'shutter_speed',
          subMenus: [],
        },
        {
          claim: [
            'CMP_EDIT',
            'CMP_BULK',
            'COMP_VIEW',
            'CMP_BULK_NOTI',
            'CMP_DEL',
            'CMP_ADD',
          ],
          menuValue: 'Companies',
          route: 'crm/company-list',
          hasSubRoute: false,
          showSubRoute: false,
          base: 'crm',
          icon: 'directions',
          materialicons: 'shutter_speed',
          subMenus: [],
        },
      ],
    },
    {
      tittle: 'HR',
      icon: 'file',
      showAsTab: false,
      separateRoute: false,
      claim: ['HR_VIEW'],
      menu: [
        {
          claim: ['MNTH_CHART_VIEW'],
          menuValue: 'Monthly Chart',
          route: routes.chat,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'building',
          base: 'chart',
          materialicons: 'shopping_bag',
          subMenus: [],
        },
        {
          claim: ['ON_BOARDING_VIEW'],
          menuValue: 'Onboarding',
          route: routes.onboarding,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'user-plus',
          base: 'onboarding',
          materialicons: 'assignment_ind',
          subMenus: [
            {
              claim: ['OFF_LETTER_VIEW', 'OFFLTR_ADD'],
              menuValue: 'Offer Letter Generation',
              route: routes.offerLetterGeneration,
              base: 'offer-letter',
            },
            {
              claim: [
                'OB_DOCUMENT_VIEW',
                'OB_DOC_ADD',
                'OB_DOC_EDIT',
                'OB_DOCUMENT_DELETE',
              ],
              menuValue: 'Document',
              route: routes.document,
              base: 'onboarding',
            },
            {
              claim: [
                'APT_SCH_VIEW',
                'APT_SCH_ADD',
                'APT_SCH_EDIT',
                'APT_SCH_DEL',
              ],
              menuValue: 'Appointment-Schedule',
              route: routes.appointment,
              base: 'appointment',
            },
            {
              claim: [
                'APT_SCH_View',
                'APT_SCH_Add',
                'APT_SCH_Edit',
                'APT_SCH_Delete',
              ],
              menuValue: 'Confirmation-Process',
              route: routes.confirmation,
              base: 'confirmation',
            },
            {
              claim: [
                'INTER_FDBK_VIEW',
                'INTERVIEW_FDK_ADD',
                'INTER_FDBK_EDIT',
                'INTER_FEEDBK_DEL',
              ],
              menuValue: 'Interview-Feedback',
              route: routes.interviewFeedback,
              base: 'interview-feedback',
            },
            {
              claim: [
                'MULTIPLE_PAYROLL_DELETE',
                'MULTI_PAYROLL_EDIT',
                'MUL_PAYROLL_VIEW',
                'MULTI_PAYROLL_ADD',
              ],
              menuValue: 'Multi-Payroll',
              route: routes.multiPayroll,
              base: 'multi-payroll',
            },
            {
              claim: [
                'PAYROLL_CONFIG_DEL',
                'PAYROLL_CONFIG_EDIT',
                'PAYROLL_CONFIG_ADD',
                'PAYROL_CONFIG_VIEW',
              ],
              menuValue: 'Payroll-Confirguration',
              route: routes.payrollConfirguration,
              base: 'payroll-confirguration',
            },
            {
              claim: ['On_Boarding_View'],
              menuValue: 'Onboarding-Management',
              route: routes.checklistManagement,
              base: 'onboarding-checklist',
            },
            {
              claim: [
                'NEW_HIRE_VIEW',
                'NEW_HIRE_ADD',
                'NEW_HIRE_EDIT',
                'NEW_HIRE_DEL',
              ],
              menuValue: 'New Hire Portal',
              route: routes.hirePortal,
              base: 'hire-portal',
            },
            {
              claim: [
                'New_Hire_View',
                'New_Hire_Add',
                'New_Hire_Edit',
                'New_Hire_Delete',
              ],
              menuValue: 'Reporting & Analytics',
              route: routes.reporting,
              base: 'reporting-analytics',
            },
            {
              claim: [
                'New_Hire_View',
                'New_Hire_Add',
                'New_Hire_Edit',
                'New_Hire_Delete',
              ],
              menuValue: 'Task Automation',
              route: routes.taskAutomation,
              base: 'task-automation',
            },
          ],
        },
        // {
        //   claim: ['Vender_View', 'Vender_Add', 'Vender_Edit', 'Vender_Delete'],
        //   menuValue: 'Vender',
        //   route: routes.vender,
        //   hasSubRoute: false,
        //   showSubRoute: false,
        //   icon: 'chalkboard',
        //   base: 'onboarding',
        //   materialicons: 'chalkboard',
        //   subMenus: [],
        // },
        {
          claim: ['Deals_View', 'Contacts_View', 'Lead_View', 'Company_View'],
          menuValue: 'Employee Management',
          route: routes.employeeManagement,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'chalkboard',
          base: 'employee-management',
          materialicons: 'chalkboard',
          subMenus: [
            {
              claim: [
                'Deals_View',
                'Contacts_View',
                'Lead_View',
                'Company_View',
              ],
              menuValue: 'Employee Management',
              route: routes.management,
              base: 'management',
            },
            {
              claim: [
                'Deals_View',
                'Contacts_View',
                'Lead_View',
                'Company_View',
              ],
              menuValue: 'Employee Record Management',
              route: routes.employeerecord,
              base: 'emp-record',
            },
            {
              claim: [
                'Deals_View',
                'Contacts_View',
                'Lead_View',
                'Company_View',
              ],
              menuValue: 'Employee Directory',
              route: routes.employeedirectory,
              base: 'emp-directory',
            },
            {
              claim: [
                'Deals_View',
                'Contacts_View',
                'Lead_View',
                'Company_View',
              ],
              menuValue: 'Employee Document Management',
              route: routes.employeesdocument,
              base: 'emp-document',
            },
          ],
        },
        {
          claim: ['Deals_View', 'Contacts_View', 'Lead_View', 'Company_View'],
          menuValue: 'Accounting',
          route: routes.accounting,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'file-alt',
          base: 'accounting',
          materialicons: 'checklist_rtl',
          subMenus: [
            {
              menuValue: 'Categories',
              route: routes.category,
              base: 'category',
            },
            { menuValue: 'Budgets', route: routes.budgets, base: 'budgets' },
            {
              menuValue: 'Budget Expenses',
              route: routes.budgetexpenses,
              base: 'budget-expenses',
            },
            {
              menuValue: 'Budget Revenues',
              route: routes.budgetrevenues,
              base: 'budget-revenues',
            },
          ],
        },
        {
          claim: ['EMP_PAYROLL_VIEW'],
          menuValue: 'Payroll',
          route: routes.payroll,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'money',
          base: 'payroll',
          materialicons: 'auto_graph',
          subMenus: [
            {
              claim: [
                'EMP_SALARY_VIEW',
                'Contacts_View',
                'Lead_View',
                'Company_View',
              ],
              menuValue: 'Employee Salary',
              route: routes.employeesalary,
              base: 'employee-salary',
            },
            {
              claim: ['EMP_PAYSLIP_VIEW'],

              menuValue: 'Payslip',
              route: routes.salaryview,
              base: 'salary-view',
            },
            {
              claim: ['EMP_PAYSLIP_VIEW'],
              menuValue: 'Payroll Items',
              route: routes.payrollitems,
              base: 'payroll-items',
            },
          ],
        },
        {
          claim: ['Deals_View', 'Contacts_View', 'Lead_View', 'Company_View'],
          menuValue: 'Policies',
          route: routes.policies,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'file-pdf-o',
          base: 'policies',
          page1: 'main',
          materialicons: 'do_not_disturb_alt',
          subMenus: [],
        },
      ],
    },
    {
      tittle: 'RECRUITMENT',
      icon: 'file',
      showAsTab: false,
      separateRoute: false,
      claim: ['OSC_VIEW', 'REC_VIEW'],
      menu: [
        {
          claim: ['OSC_DEL', 'OSC_EDIT', 'OSC_ADD', 'OSC_VIEW', 'OSC_EXPO'],
          menuValue: 'Outsource Client',
          route: '/admin/outsource-client',
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'building',
          base: 'Hr',
          materialicons: 'handshake',
          subMenus: [],
        },
        {
          claim: [
            'CANDID_VIEW',
            'CANDID_EXPO',
            'CANDID_EDIT',
            'CANDID_DEL',
            'CANDID_ADD',
          ],
          menuValue: 'Candidates',
          route: '/admin/candidates',
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'users',
          base: 'chart',
          materialicons: 'person_search',
          subMenus: [],
        },
        {
          claim: [
            'CONSULT_DEL',
            'CONSULT_EXPORT',
            'CONSULT_UPDATE',
            'CONSULT_ADD',
            'CONSULT_VIEW',
          ],
          menuValue: 'Consultant',
          route: '/admin/consultant',
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'user-tie',
          base: 'Hr',
          materialicons: 'support_agent',
          subMenus: [],
        },
        {
          claim: ['SR_ADD', 'SR_UPDATE', 'SR_DEL', 'SR_VIEW', 'SR_EXPO'],
          menuValue: 'Service Request',
          route: '/admin/service-request',
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'tasks',
          base: 'Hr',
          materialicons: 'help_outline',
          subMenus: [],
        },
      ],
    },
    {
      claim: ['Deals_View', 'Contacts_View', 'Lead_View', 'Company_View'],
      tittle: 'Communication',
      icon: 'airplay',
      showAsTab: true,
      separateRoute: false,
      menu: [
        {
          claim: ['Deals_View', 'Contacts_View', 'Lead_View', 'Company_View'],
          menuValue: 'Email',
          route: routes.communication,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'dashcube',
          base: 'email-template',
          materialicons: 'home',
          subMenus: [
            {
              claim: [
                'Deals_View',
                'Contacts_View',
                'Lead_View',
                'Company_View',
              ],
              menuValue: 'IMap/Pop 3 Setting',
              route: routes.IMapPop,
              base: 'IMapPop-email',
            },
            {
              claim: [
                'Deals_View',
                'Contacts_View',
                'Lead_View',
                'Company_View',
              ],
              menuValue: 'SMTP Settings',
              route: routes.smtpEmail,
              base: 'SMPTemail',
            },
            {
              claim: [
                'Deals_View',
                'Contacts_View',
                'Lead_View',
                'Company_View',
              ],
              menuValue: 'Email Template',
              route: routes.emailTemplate,
              base: 'email-template',
            },
            {
              claim: [
                'Deals_View',
                'Contacts_View',
                'Lead_View',
                'Company_View',
              ],
              menuValue: 'Send Email',
              route: routes.sendEmail,
              base: 'send-email',
            },
          ],
        },

        {
          claim: ['Deals_View', 'Contacts_View', 'Lead_View', 'Company_View'],
          menuValue: 'SMS',
          route: routes.communication,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'dashcube',
          base: 'SMS-template',
          materialicons: 'home',
          subMenus: [
            {
              menuValue: 'SMS Settings',
              route: routes.smsSetting,
              base: 'SMS-setting',
            },
            {
              menuValue: 'SMS Template',
              route: routes.smsTemplate,
              base: 'SMS-template',
            },
            {
              menuValue: 'SMS Send',
              route: routes.smsSend,
              base: 'SMS-send',
            },
          ],
        },
        {
          claim: ['Deals_View', 'Contacts_View', 'Lead_View', 'Company_View'],
          menuValue: 'Whats App',
          route: routes.communication,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'dashcube',
          base: 'whatsapp-template',
          materialicons: 'home',
          subMenus: [
            {
              menuValue: 'Whats App Settings',
              route: routes.whatsappSetting,
              base: 'whatsapp-setting',
            },
            {
              menuValue: 'Whats App Template',
              route: routes.whatsappTemplate,
              base: 'whatsapp-template',
            },
            {
              menuValue: 'Whats App Send',
              route: routes.whatsappSend,
              base: 'whatsapp-send',
            },
          ],
        },
        {
          claim: ['Deals_View', 'Contacts_View', 'Lead_View', 'Company_View'],
          menuValue: 'Reminder',
          route: routes.communication,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'dashcube',
          base: 'reminder',
          materialicons: 'home',
          subMenus: [
            {
              menuValue: 'Reminder List',
              route: routes.reminderList,
              base: 'reminder-list',
            },
          ],
        },
      ],
    },
    {
      claim: ['Deals_View', 'Contacts_View', 'Lead_View', 'Company_View'],
      tittle: 'Performance',
      icon: 'file',
      showAsTab: false,
      separateRoute: false,
      menu: [
        {
          menuValue: 'Performance',
          route: routes.performance,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'graduation-cap',
          base: 'performance',
          materialicons: 'work_outline',
          subMenus: [
            {
              menuValue: 'Performance Indicator',
              route: routes.indicator,
              base: 'indicator',
            },
            {
              menuValue: 'Performance Review',
              route: routes.review,
              base: 'review',
            },
            {
              menuValue: 'Performance Appraisal',
              route: routes.appraisal,
              base: 'appraisal',
            },
          ],
        },
        {
          claim: ['Deals_View', 'Contacts_View', 'Lead_View', 'Company_View'],
          menuValue: 'Goals',
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'crosshairs',
          base: 'goals',
          materialicons: 'school',
          subMenus: [
            {
              menuValue: 'Goal List',
              route: routes.goalTracking,
              base: 'goal-tracking',
            },
            {
              menuValue: 'Goal Type',
              route: routes.goalType,
              base: 'goal-type',
            },
          ],
        },
        {
          claim: ['Deals_View', 'Contacts_View', 'Lead_View', 'Company_View'],
          menuValue: 'Training',
          route: routes.training,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'edit',
          base: 'training',
          materialicons: 'toggle_off',
          subMenus: [
            { menuValue: 'Training List', route: routes.lists, base: 'lists' },
            { menuValue: 'Trainers', route: routes.trainer, base: 'trainer' },
            { menuValue: 'Training Type', route: routes.types, base: 'types' },
          ],
        },
        {
          claim: ['Deals_View', 'Contacts_View', 'Lead_View', 'Company_View'],
          menuValue: 'Promotion',
          route: routes.promotion,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'bullhorn',
          base: 'promotion',
          materialicons: 'group_add',
          subMenus: [],
        },
        {
          claim: ['Deals_View', 'Contacts_View', 'Lead_View', 'Company_View'],
          menuValue: 'Resignation',
          route: routes.resignation,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'external-link-square',
          base: 'resignation',
          materialicons: 'settings',
          subMenus: [],
        },
        {
          claim: ['Deals_View', 'Contacts_View', 'Lead_View', 'Company_View'],
          menuValue: 'Termination',
          route: routes.termination,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'user-times',
          base: 'termination',
          materialicons: 'manage_accounts',
          subMenus: [],
        },
      ],
    },
    {
      tittle: 'Administration',
      icon: 'file',
      showAsTab: false,
      separateRoute: false,
      claim: ['ADT_VIEW'],
      menu: [
        // {
        //   claim: ['TEMP_VIEW'],
        //   menuValue: 'Templates',
        //   route: routes.templates,
        //   hasSubRoute: true,
        //   showSubRoute: false,
        //   icon: 'shapes',
        //   base: 'templates',
        //   materialicons: 'shapes',
        //   subMenus: [
        //     {
        //       claim: [
        //         'EML_TEMP_ADD',
        //         'Email_Template_Edit',
        //         'EML_TEMP_VIEW',
        //         'EMAIL_TEMPLATE_DELETE',
        //       ],
        //       menuValue: 'Custom Email Template',
        //       route: routes.customTemplate,
        //       base: 'custom-template',
        //     },
        //   ],
        // },
        {
          claim: ['TBL_VIEW'],
          menuValue: 'Table View',
          route: '/admin/table/table-view',
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'object-ungroup',
          base: 'tableView',
          materialicons: 'perm_contact_calendar',
          subMenus: [],
        },
        {
          claim: ['TBL_CLM_VIEW'],
          menuValue: 'Table Column',
          route: '/admin/table/table-column',
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'object-ungroup',
          base: 'tableColumn',
          materialicons: 'perm_contact_calendar',
          subMenus: [],
        },
        // {
        //   claim: ['Table_Column', 'Layout_View'],
        //   menuValue: 'Jobs',
        //   route: routes.jobs,
        //   hasSubRoute: true,
        //   showSubRoute: false,
        //   icon: 'briefcase',
        //   base: 'jobs',
        //   materialicons: 'announcement',
        //   subMenus: [
        //     {
        //       claim: ['Table_Column', 'Layout_View'],
        //       menuValue: 'User Dashboard',
        //       route: routes.userDashboard,
        //       base: 'user-dashboard',
        //       base2: 'user-all-jobs',
        //       base3: 'saved-jobs',
        //       base4: 'applied-jobs',
        //       base5: 'interview-jobs',
        //       base6: 'offered-jobs',
        //       base7: 'visited-jobs',
        //       base8: 'archived-jobs',
        //     },
        //     {
        //       claim: ['Table_Column', 'Layout_View'],
        //       menuValue: 'Jobs Dashboard',
        //       route: routes.jobsdashboard,
        //       base: 'jobs-dashboard',
        //     },
        //     {
        //       claim: ['Table_Column', 'Layout_View'],
        //       menuValue: 'Manage Jobs',
        //       route: routes.managejobs,
        //       base: 'manage-jobs',
        //     },
        //     {
        //       claim: ['Table_Column', 'Layout_View'],
        //       menuValue: 'Manage Resumes',
        //       route: routes.manageresumes,
        //       base: 'manage-resumes',
        //     },
        //     {
        //       claim: ['Table_Column', 'Layout_View'],
        //       menuValue: 'Shortlist Candidates',
        //       route: routes.shortlist,
        //       base: 'shortlist',
        //     },
        //     {
        //       claim: ['Table_Column', 'Layout_View'],
        //       menuValue: 'Interview Questions',
        //       route: routes.interviewquestions,
        //       base: 'interview-questions',
        //     },
        //     {
        //       claim: ['Table_Column', 'Layout_View'],
        //       menuValue: 'Offer Approvals',
        //       route: routes.offerapproval,
        //       base: 'offer-approval',
        //     },
        //     {
        //       menuValue: 'Experience Level',
        //       route: routes.experiencelevel,
        //       base: 'experience-level',
        //     },
        //     {
        //       menuValue: 'Candidates List',
        //       route: routes.candidateslist,
        //       base: 'candidates-list',
        //     },
        //     {
        //       menuValue: 'Schedule Timing',
        //       route: routes.scheduletiming,
        //       base: 'schedule-timing',
        //     },
        //     {
        //       menuValue: 'Aptitude Results',
        //       route: routes.aptituderesult,
        //       base: 'aptitude-result',
        //     },
        //   ],
        // },
        {
          claim: ['KNB_VIEW'],
          menuValue: 'Knowledgebase',
          route: routes.knowledgebasemain,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'question',
          base: 'knowledgebase',
          materialicons: 'loyalty',
          subMenus: [],
        },
        // {
        //   claim: ['Table_Column', 'Layout_View'],
        //   menuValue: 'Users',
        //   route: routes.users,
        //   hasSubRoute: false,
        //   showSubRoute: false,
        //   icon: 'users-cog',
        //   base: 'users',
        //   materialicons: 'layers',
        //   subMenus: [],
        // },

        // {
        //   claim: ['Table_Column', 'Layout_View'],
        //   menuValue: 'Settings',
        //   route: routes.companysettings,
        //   hasSubRoute: false,
        //   showSubRoute: false,
        //   icon: 'cog',
        //   base: 'company-settings',
        //   materialicons: 'foundation',
        //   subMenus: [],
        // },
      ],
    },
    {
      tittle: 'Master',
      icon: 'layers',
      showAsTab: false,
      separateRoute: false,
      claim: ['MST_ADD', 'MST_VIEW', 'MST_DEL', 'MASTER_EDIT'],
      menu: [
        {
          claim: [
            'PAGE_ADD',
            'PAGE_UPDATE',
            'PAGE_VIEW',
            'PAGE_EDIT',
            'PAGE_DEL',
          ],
          menuValue: 'Pages',
          route: routes.pages,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'object-ungroup',
          base: 'pages',
          materialicons: 'perm_contact_calendar',
          subMenus: [],
        },
        {
          claim: ['MST_ADD', 'MST_VIEW', 'MST_DEL', 'MASTER_EDIT'],
          menuValue: 'Team',
          route: '/admin/master/team',
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'users',
          base: 'master',
          materialicons: 'group',
          subMenus: [],
        },
        {
          claim: ['MST_ADD', 'MST_VIEW', 'MST_DEL', 'MASTER_EDIT'],
          menuValue: 'Role',
          route: '/admin/master/role',
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'shapes',
          base: 'master',
          materialicons: 'shapes', // Updated Material Icon for Role
          subMenus: [],
        },
        {
          claim: ['MST_ADD', 'MST_VIEW', 'MST_DEL', 'MASTER_EDIT'],
          menuValue: 'Department',
          route: '/admin/master/department',
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'building',
          base: 'master',
          materialicons: 'business',
          subMenus: [],
        },
        {
          claim: ['MST_ADD', 'MST_VIEW', 'MST_DEL', 'MASTER_EDIT'],
          menuValue: 'Designation',
          route: '/admin/master/designation',
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'user-tag',
          base: 'master',
          materialicons: 'badge',
          subMenus: [],
        },
        {
          claim: ['MST_ADD', 'MST_VIEW', 'MST_DEL', 'MASTER_EDIT'],
          menuValue: 'Lookup',
          route: '/admin/master/lookup',
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'search',
          base: 'master',
          materialicons: 'search',
          subMenus: [],
        },
        {
          claim: ['MST_ADD', 'MST_VIEW', 'MST_DEL', 'MASTER_EDIT'],
          menuValue: 'Category',
          route: '/admin/master/category',
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'tags',
          base: 'master',
          materialicons: 'category',
          subMenus: [],
        },
        {
          claim: ['MST_ADD', 'MST_VIEW', 'MST_DEL', 'MASTER_EDIT'],
          menuValue: 'Status',
          route: '/admin/master/status',
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'hourglass', // Alternative Icon
          base: 'master',
          materialicons: 'hourglass_empty', // Alternative Material Icon for error status
          subMenus: [],
        },
      ],
    },
    {
      tittle: 'Settings',
      icon: 'file',
      showAsTab: false,
      separateRoute: false,
      claim: ['SETT_VIEW'],
      menu: [
        {
          claim: ['GNRL_SETT_VIEW'],
          menuValue: 'General Settings',
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'cog',
          materialicons: 'settings',
          subMenus: [
            {
              claim: ['GNRL_SETT_VIEW'],
              menuValue: 'Profile',
              route: routes.profileSettings,
              base: 'profile-settings',
            },
            {
              claim: ['GNRL_SETT_VIEW'],
              menuValue: 'Security',
              route: routes.securitySettings,
              base: 'security-settings',
            },
            {
              claim: ['GNRL_SETT_VIEW'],
              menuValue: 'Notification',
              route: routes.notificationSettings,
              base: 'notifications-settings',
            },
            {
              claim: ['GNRL_SETT_VIEW'],
              menuValue: 'Connected Apps',
              route: routes.connectedAppsSettings,
              base: 'connected-apps',
            },
          ],
        },
        {
          claim: ['APP_SETT_VIEW'],
          menuValue: 'App Settings',
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'wallet',
          materialicons: 'monetization_on',
          subMenus: [
            {
              claim: ['APP_SETT_VIEW'],
              menuValue: 'Salary Settings',
              route: routes.salarySettings,
              base: 'salary-settings',
            },
            {
              claim: ['APP_SETT_VIEW'],
              menuValue: 'Approval Settings',
              route: routes.approvalSettings,
              base: 'approval-settings',
            },
            {
              claim: ['APP_SETT_VIEW'],
              menuValue: 'Invoice Settings',
              route: routes.invoiceSettings,
              base: 'invoice-settings',
            },
            {
              claim: ['APP_SETT_VIEW'],
              menuValue: 'Leave Type',
              route: routes.leaveSettings,
              base: 'leave-settings',
            },
            {
              claim: ['APP_SETT_VIEW'],
              menuValue: 'Custom Fields',
              route: routes.customSettings,
              base: 'custom-settings',
            },
          ],
        },
        {
          claim: ['FNC_SETT_VIEW'],
          menuValue: 'Financial Settings',
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'chart-line',
          materialicons: 'account_balance',
          subMenus: [
            {
              claim: ['FNC_SETT_VIEW'],
              menuValue: 'Payment Gateway',
              route: routes.paymentSettings,
              base: 'payment-settings',
            },
            {
              claim: ['FNC_SETT_VIEW'],
              menuValue: 'Tax Rates',
              route: routes.taxSettings,
              base: 'tax-settings',
            },
            {
              claim: ['FNC_SETT_VIEW'],
              menuValue: 'Currencies',
              route: routes.currenciesSettings,
              base: 'currencies-settings',
            },
          ],
        },

        {
          claim: ['SYS_SETT_VIEW'],
          menuValue: 'System Settings',
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'server',
          materialicons: 'settings_applications',
          subMenus: [
            {
              claim: ['SYS_SETT_VIEW'],
              menuValue: 'Email Settings',
              route: routes.emailSettings,
              base: 'email-settings',
            },
            {
              claim: ['SYS_SETT_VIEW'],
              menuValue: 'SMS Settings',
              route: routes.smsSettings,
              base: 'sms-settings',
            },
            {
              claim: ['SYS_SETT_VIEW'],
              menuValue: 'SMS Templates',
              route: routes.smsTemplateSettings,
              base: 'sms-templates',
            },
            {
              claim: ['SYS_SETT_VIEW'],
              menuValue: 'OTP',
              route: routes.otpSettings,
              base: 'otp',
            },
          ],
        },
        {
          claim: ['OTR_SETT_VIEW'],
          menuValue: 'Other Settings',
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'sliders-h',
          materialicons: 'tune',
          subMenus: [
            {
              claim: ['OTR_SETT_VIEW'],
              menuValue: 'Cronjob',
              route: routes.cronjobSettings,
              base: 'cron-settings',
            },
            {
              claim: ['OTR_SETT_VIEW'],
              menuValue: 'Ban IP Address',
              route: routes.banSettings,
              base: 'ban-ip-address',
            },
          ],
        },
      ],
    },
  ];
  public userSideBar: SideBar[] = [
    {
      tittle: 'Employees',
      icon: 'layers',
      showAsTab: false,
      separateRoute: false,
      menu: [
        {
          menuValue: 'Dashboard',
          route: routes.employee,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'dashcube',
          base: 'dashboard',
          materialicons: 'home',
          subMenus: [],
        },
        {
          menuValue: 'Employees',
          route: routes.employees,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'user',
          base: 'employees',
          materialicons: 'people',
          subMenus: [
            { menuValue: 'Holidays', route: routes.holidays, base: 'holidays' },

            {
              menuValue: 'Leaves (Employee)',
              route: routes.leaveemployee,
              base: 'leave-employee',
            },

            {
              menuValue: 'Attendance (Employee)',
              route: routes.attendanceemployee,
              base: 'attendance-employee',
            },

            {
              menuValue: 'Timesheet',
              route: routes.timesheet,
              base: 'timesheet',
            },
          ],
        },
        {
          menuValue: 'Projects',
          route: routes.projects,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'rocket',
          base: 'projects',
          materialicons: 'topic',
          subMenus: [],
        },
        {
          menuValue: 'Tickets',
          route: routes.ticketpage,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'ticket',
          base: 'tickets',
          materialicons: 'leaderboard',
          subMenus: [
            {
              menuValue: 'Tickets',
              route: routes.ticketpage,
              base: 'ticket-page',
            },
            {
              menuValue: 'Tickets Detail',
              route: routes.ticketDetails,
              base: 'ticket-details',
            },
          ],
        },
        {
          menuValue: 'Permissions',
          route: routes.permissions,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'key',
          base: 'role',
          materialicons: 'Key',
          subMenus: [],
        },
        {
          menuValue: 'Settings',
          route: routes.employees,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'cog',
          base: 'employees',
          materialicons: 'foundation',
          subMenus: [
            {
              menuValue: 'General Settings',
              route: routes.generalSetting,
              base: 'general-setting',
            },
            {
              menuValue: 'Integration Settings',
              route: routes.integartionSetting,
              base: 'integration-setting',
            },
            {
              menuValue: 'Notification Setttings',
              route: routes.notificationSetting,
              base: 'notification-setting',
            },
            {
              menuValue: 'Profile Setttings',
              route: routes.profileSetting,
              base: 'profile-setting',
            },
          ],
        },
        {
          menuValue: 'Feedback',
          route: routes.feedback,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'comment',
          base: 'feedback',
          materialicons: 'comment',
          subMenus: [],
        },
        {
          menuValue: 'Administration Settings',
          route: routes.employees,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'users-cog',
          base: 'administration',
          materialicons: 'foundation',
          subMenus: [
            {
              menuValue: 'User Management',
              route: routes.users,
              base: 'user-view',
            },
            {
              menuValue: 'Role Management',
              route: routes.permissions,
              base: 'permissions',
            },
          ],
        },
        {
          menuValue: 'Report',
          route: routes.reports,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'pie-chart',
          base: 'reports',
          materialicons: 'web_asset',
          subMenus: [
            {
              menuValue: 'Project Report',
              route: routes.projectreport,
              base: 'project-report',
            },
            {
              menuValue: 'Task Report',
              route: routes.taskreport,
              base: 'task-report',
            },
            {
              menuValue: 'Team Report',
              route: routes.employeereport,
              base: 'employee-report',
            },
          ],
        },
      ],
    },
  ];
  public sideBar2: HorizontalSideBar[] = [
    {
      tittle: 'Main',
      icon: 'airplay',
      showAsTab: true,
      separateRoute: false,
      menu: [
        {
          menuValue: 'Dashboard',
          route: routes.dashboard,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'dashcube',
          base: 'dashboard',
          materialicons: 'home',
          subMenus: [
            {
              menuValue: 'Admin Dashboard',
              route: routes.admin,
              base: 'admin',
            },
            {
              menuValue: 'Employee Dashboard',
              route: routes.employee,
              base: 'employee',
            },
            {
              menuValue: 'Deals Dashboard',
              route: routes.dealsDashboard,
              base: 'deals',
            },
            {
              menuValue: 'Leads Dashboard',
              route: routes.leadDashboard,
              base: 'leads',
            },
          ],
        },
        {
          menuValue: 'Apps',
          route: routes.apps,
          hasSubRouteTwo: true,
          showSubRoute: false,
          icon: 'cube',
          base: 'apps',
          materialicons: 'dashboard',
          subMenus: [
            {
              menuValue: 'Chat',
              route: routes.chat,
              base: 'apps',
              customSubmenuTwo: false,
            },
            {
              menuValue: 'Calls',
              customSubmenuTwo: true,
              hasSubRoute: true,
              showSubRoute: false,
              route: routes.calendar,
              page1: 'voice-call',
              page2: 'videocall',
              subMenusTwo: [
                {
                  menuValue: 'Voice Call',
                  route: routes.voicecall,
                  hasSubRoute: false,
                  showSubRoute: false,
                  page: 'call',
                },
                {
                  menuValue: 'Video Call',
                  route: routes.videocall,
                  hasSubRoute: false,
                  showSubRoute: false,
                },
                {
                  menuValue: 'Outgoing Call',
                  route: routes.outgoingcall,
                  hasSubRoute: false,
                  showSubRoute: false,
                },
                {
                  menuValue: 'Incoming Call',
                  route: routes.incomingcall,
                  hasSubRoute: false,
                  showSubRoute: false,
                },
              ],
            },
            {
              menuValue: 'Calendar',
              hasSubRoute: true,
              showSubRoute: false,
              route: routes.calendar,
              customSubmenuTwo: false,
            },
            {
              menuValue: 'Contacts',
              hasSubRoute: true,
              showSubRoute: false,
              route: routes.contacts,
              customSubmenuTwo: false,
            },
            {
              menuValue: 'Email',
              hasSubRoute: true,
              showSubRoute: false,
              route: routes.email,
              customSubmenuTwo: false,
            },
            {
              menuValue: 'File Manager',
              hasSubRoute: true,
              showSubRoute: false,
              route: routes.filemanager,
              customSubmenuTwo: false,
            },
          ],
        },
      ],
    },
    {
      tittle: 'Employees',
      icon: 'file',
      showAsTab: false,
      separateRoute: false,
      menu: [
        {
          menuValue: 'Employees',
          route: routes.employees,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'user',
          base: 'employees',
          materialicons: 'people',
          subMenus: [
            {
              menuValue: 'All Employees',
              route: routes.employee_page,
              base: 'employee-page',
              base2: 'employee-list',
            },

            {
              menuValue: 'Leaves (Admin)',
              route: routes.leaveadmin,
              base: 'leave-admin',
            },
            {
              menuValue: 'Leaves (Employee)',
              route: routes.leaveemployee,
              base: 'leave-employee',
            },
            {
              menuValue: 'Leave Settings',
              route: routes.leavesettings,
              base: 'leave-settings',
            },
            {
              menuValue: 'Attendance (Admin)',
              route: routes.attendanceadmin,
              base: 'attendance-admin',
            },
            {
              menuValue: 'Attendance (Employee)',
              route: routes.attendanceemployee,
              base: 'attendance-employee',
            },
            {
              menuValue: 'Departments',
              route: routes.departments,
              base: 'departments',
            },
            {
              menuValue: 'Designations',
              route: routes.designations,
              base: 'designations',
            },
          ],
        },
        {
          menuValue: 'Clients',
          route: routes.clientPage,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'users',
          base: 'clients',
          materialicons: 'person',
          subMenus: [],
        },
        {
          menuValue: 'Projects',
          route: routes.projects,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'rocket',
          base: 'projects',
          materialicons: 'topic',
          subMenus: [],
        },
        {
          menuValue: 'Tickets',
          route: routes.ticketpage,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'ticket',
          base: 'tickets',
          materialicons: 'leaderboard',
          subMenus: [
            {
              menuValue: 'Tickets',
              route: routes.ticketpage,
              base: 'ticket-page',
            },
            {
              menuValue: 'Tickets Detail',
              route: routes.ticketDetails,
              base: 'ticket-details',
            },
          ],
        },
        {
          menuValue: 'Attendance',
          route: routes.leaves,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'user-check',
          base: 'Leaves',
          materialicons: 'leaderboard',
          subMenus: [
            {
              menuValue: 'Leave Dashboard',
              route: routes.leaveDashboard,
              base: 'leave-dashboard',
            },
            {
              menuValue: 'Leave Approval',
              route: routes.leaveApproval,
              base: 'leave-approval',
            },
            {
              menuValue: 'Leave Balance',
              route: routes.leaveBalance,
              base: 'leave-balance',
            },
            {
              menuValue: 'Attendance Track',
              route: routes.attenTrack,
              base: 'attendance-track',
            },
            {
              menuValue: 'Attendance Report',
              route: routes.attenReport,
              base: 'attendance-report',
            },

            {
              menuValue: 'Employee Daychart',
              route: routes.empDaychart,
              base: 'empDaychart',
            },
            {
              menuValue: 'Timesheet',
              route: routes.timesheet,
              base: 'timesheet',
            },
            {
              menuValue: 'Outstation Duty',
              route: routes.outStationTimesheet,
              base: 'outStationTimesheet',
            },
            {
              menuValue: 'Out Of Duty',
              route: routes.OdTimesheet,
              base: 'out-of-duty',
            },
            {
              menuValue: 'Expense',
              route: routes.Expense,
              base: 'expense',
            },
            {
              menuValue: 'Employee Roaster',
              route: routes.shiftschedule,
              base: 'employee-roaster',
            },
            { menuValue: 'Overtime', route: routes.overtime, base: 'overtime' },
          ],
        },
      ],
    },
    {
      tittle: 'HR',
      icon: 'file',
      showAsTab: false,
      separateRoute: false,
      menu: [
        {
          menuValue: 'Sales',
          route: routes.sales,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'files-o',
          base: 'sales',
          materialicons: 'track_changes',
          subMenus: [
            {
              menuValue: 'Estimates',
              route: routes.estimatepage,
              base: 'estimate-page',
              base2: 'estimate-view',
              base3: 'create-estimate',
              base4: 'edit-estimate',
            },
            {
              menuValue: 'Invoices',
              route: routes.invoicepage,
              base: 'invoice-page',
              base2: 'invoice-view',
              base3: 'create-invoice',
              base4: 'edit-invoice',
            },
            { menuValue: 'Payments', route: routes.payments, base: 'payments' },
            { menuValue: 'Expenses', route: routes.expenses, base: 'expenses' },
            {
              menuValue: 'Provident Fund',
              route: routes.providentfund,
              base: 'provident-fund',
            },
            { menuValue: 'Taxes', route: routes.taxes, base: 'taxes' },
          ],
        },

        {
          menuValue: 'Accounting',
          route: routes.accounting,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'file-alt',
          base: 'accounting',
          materialicons: 'checklist_rtl',
          subMenus: [
            {
              menuValue: 'Categories',
              route: routes.category,
              base: 'category',
            },
            { menuValue: 'Budgets', route: routes.budgets, base: 'budgets' },
            {
              menuValue: 'Budget Expenses',
              route: routes.budgetexpenses,
              base: 'budget-expenses',
            },
            {
              menuValue: 'Budget Revenues',
              route: routes.budgetrevenues,
              base: 'budget-revenues',
            },
          ],
        },
        {
          menuValue: 'Payroll',
          route: routes.payroll,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'money',
          base: 'payroll',
          materialicons: 'auto_graph',
          subMenus: [
            {
              menuValue: 'Employee Salary',
              route: routes.employeesalary,
              base: 'employee-salary',
            },
            {
              menuValue: 'Payslip',
              route: routes.salaryview,
              base: 'salary-view',
            },
            {
              menuValue: 'Payroll Items',
              route: routes.payrollitems,
              base: 'payroll-items',
            },
          ],
        },
        {
          menuValue: 'Policies',
          route: routes.policies,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'file-pdf-o',
          base: 'policies',
          materialicons: 'do_not_disturb_alt',
          subMenus: [],
        },
        {
          menuValue: 'Reports',
          route: routes.reports,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'pie-chart',
          base: 'reports',
          materialicons: 'web_asset',
          subMenus: [
            {
              menuValue: 'Expense Report',
              route: routes.expensereport,
              base: 'expense-report',
            },
            {
              menuValue: 'Invoice Report',
              route: routes.invoicereport,
              base: 'invoice-report',
            },
            {
              menuValue: 'Payments Report',
              route: routes.paymentsreport,
              base: 'payments-report',
            },
            {
              menuValue: 'Project Report',
              route: routes.projectreport,
              base: 'project-report',
            },
            {
              menuValue: 'Task Report',
              route: routes.taskreport,
              base: 'task-report',
            },
            {
              menuValue: 'User Report',
              route: routes.userreport,
              base: 'user-report',
            },
            {
              menuValue: 'Employee Report',
              route: routes.employeereport,
              base: 'employee-report',
            },
            {
              menuValue: 'Payslip Report',
              route: routes.payslipreport,
              base: 'payslip-report',
            },
            {
              menuValue: 'Attendance Report',
              route: routes.attendancereport,
              base: 'attendance-report',
            },
            {
              menuValue: 'Leave Report',
              route: routes.leavereport,
              base: 'leave-report',
            },
            {
              menuValue: 'Daily Report',
              route: routes.dailyreport,
              base: 'daily-report',
            },
          ],
        },
      ],
    },
    {
      tittle: 'Performance',
      icon: 'file',
      showAsTab: false,
      separateRoute: false,
      menu: [
        {
          menuValue: 'Performance',
          route: routes.performance,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'graduation-cap',
          base: 'performance',
          materialicons: 'work_outline',
          subMenus: [
            {
              menuValue: 'Performance Indicator',
              route: routes.indicator,
              base: 'indicator',
            },
            {
              menuValue: 'Performance Review',
              route: routes.review,
              base: 'review',
            },
            {
              menuValue: 'Performance Appraisal',
              route: routes.appraisal,
              base: 'appraisal',
            },
          ],
        },
        {
          menuValue: 'Goals',
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'crosshairs',
          base: 'goals',
          materialicons: 'school',
          subMenus: [
            {
              menuValue: 'Goal List',
              route: routes.goalTracking,
              base: 'goal-tracking',
            },
            {
              menuValue: 'Goal Type',
              route: routes.goalType,
              base: 'goal-type',
            },
          ],
        },
        {
          menuValue: 'Training',
          route: routes.training,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'edit',
          base: 'training',
          materialicons: 'toggle_off',
          subMenus: [
            { menuValue: 'Training List', route: routes.lists, base: 'lists' },
            { menuValue: 'Trainers', route: routes.trainer, base: 'trainer' },
            { menuValue: 'Training Type', route: routes.types, base: 'types' },
          ],
        },
        {
          menuValue: 'Promotion',
          route: routes.promotion,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'bullhorn',
          base: 'promotion',
          materialicons: 'group_add',
          subMenus: [],
        },
        {
          menuValue: 'Resignation',
          route: routes.resignation,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'external-link-square',
          base: 'resignation',
          materialicons: 'settings',
          subMenus: [],
        },
        {
          menuValue: 'Termination',
          route: routes.termination,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'user-times',
          base: 'termination',
          materialicons: 'manage_accounts',
          subMenus: [],
        },
      ],
    },
    {
      tittle: 'Administration',
      icon: 'file',
      showAsTab: false,
      separateRoute: false,
      menu: [
        {
          menuValue: 'Page',
          route: routes.pages,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'object-ungroup',
          base: 'pages',
          materialicons: 'perm_contact_calendar',
          subMenus: [],
        },
        {
          menuValue: 'Jobs',
          route: routes.jobs,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'briefcase',
          base: 'jobs',
          materialicons: 'announcement',
          subMenus: [
            {
              menuValue: 'User Dashboard',
              route: routes.userDashboard,
              base: 'user-dashboard',
              base2: 'user-all-jobs',
              base3: 'saved-jobs',
              base4: 'applied-jobs',
              base5: 'interview-jobs',
              base6: 'offered-jobs',
              base7: 'visited-jobs',
              base8: 'archived-jobs',
            },
            {
              menuValue: 'Jobs Dashboard',
              route: routes.jobsdashboard,
              base: 'jobs-dashboard',
            },
            {
              menuValue: 'Manage Jobs',
              route: routes.managejobs,
              base: 'manage-jobs',
            },
            {
              menuValue: 'Manage Resumes',
              route: routes.manageresumes,
              base: 'manage-resumes',
            },
            {
              menuValue: 'Shortlist Candidates',
              route: routes.shortlist,
              base: 'shortlist',
            },
            {
              menuValue: 'Interview Questions',
              route: routes.interviewquestions,
              base: 'interview-questions',
            },
            {
              menuValue: 'Offer Approvals',
              route: routes.offerapproval,
              base: 'offer-approval',
            },
            {
              menuValue: 'Experience Level',
              route: routes.experiencelevel,
              base: 'experience-level',
            },
            {
              menuValue: 'Candidates List',
              route: routes.candidateslist,
              base: 'candidates-list',
            },
            {
              menuValue: 'Schedule Timing',
              route: routes.scheduletiming,
              base: 'schedule-timing',
            },
            {
              menuValue: 'Aptitude Results',
              route: routes.aptituderesult,
              base: 'aptitude-result',
            },
          ],
        },
        {
          menuValue: 'Knowledgebase',
          route: routes.knowledgebasemain,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'question',
          base: 'knowledgebase',
          materialicons: 'loyalty',
          subMenus: [],
        },
        {
          menuValue: 'Users',
          route: routes.users,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'users-cog',
          base: 'users',
          materialicons: 'layers',
          subMenus: [],
        },
        {
          menuValue: 'Settings',
          route: routes.companysettings,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'cog',
          base: 'company-settings',
          materialicons: 'foundation',
          subMenus: [],
        },
      ],
    },
    {
      tittle: 'Pages',
      icon: 'file',
      showAsTab: false,
      separateRoute: false,
      menu: [
        {
          menuValue: 'Profile',
          route: routes.profile,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'user-tag',
          base: 'profile',
          materialicons: 'bento',
          subMenus: [
            {
              menuValue: 'Employee Details',
              route: routes.employeeProfile,
              base: 'employee-details',
            },
            {
              menuValue: 'Client Details',
              route: routes.clientProfile,
              base: 'client-details',
            },
          ],
        },
        {
          menuValue: 'Authentication',
          route: routes.loginpro,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'key',
          base: 'login',
          materialicons: 'bar_chart',
          subMenus: [
            { menuValue: 'Login', route: routes.loginpro, base: 'login' },
            {
              menuValue: 'Register',
              route: routes.registers,
              base: 'register',
            },
            {
              menuValue: 'Forgot Password',
              route: routes.forgotpassword,
              base: 'forgot-password',
            },
            { menuValue: 'OTP', route: routes.otp, base: 'otp' },
            {
              menuValue: 'Lock Screen',
              route: routes.lockscreen,
              base: 'lock-screen',
            },
          ],
        },
        {
          menuValue: 'Error Page',
          route: routes.error,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'exclamation-triangle',
          base: '404',
          materialicons: 'grading',
          subMenus: [
            { menuValue: '404 Error', route: routes.error, base: '404' },
            { menuValue: '500 Error', route: routes.errors, base: '500' },
          ],
        },
        {
          menuValue: 'Subscriptions',
          route: routes.subscriptions,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'history',
          base: 'subscriptions',
          materialicons: 'view_day',
          subMenus: [
            {
              menuValue: 'Subscriptions (Admin)',
              route: routes.subadmin,
              base: 'admins',
            },
            {
              menuValue: 'Subscriptions (Company)',
              route: routes.companySubscriptions,
              base: 'company',
            },
            {
              menuValue: 'Subscribed Companies',
              route: routes.subscribedcompanies,
              base: 'subscribed-companies',
            },
          ],
        },
        {
          menuValue: 'Pages',
          route: routes.pages,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'columns',
          base: 'pages',
          materialicons: 'table_rows',
          subMenus: [
            { menuValue: 'Search', route: routes.search, base: 'search' },
            { menuValue: 'FAQ', route: routes.faq, base: 'faq' },
            { menuValue: 'Terms', route: routes.terms, base: 'terms' },
            {
              menuValue: 'Privacy Policy',
              route: routes.privacy,
              base: 'privacy-policy',
            },
            {
              menuValue: 'Blank Page',
              route: routes.blankpage,
              base: 'blank-page',
            },
            {
              menuValue: 'Coming Soon',
              route: routes.comingSoon,
              base: 'coming-soon',
            },
            {
              menuValue: 'Under Maintanance',
              route: routes.underMaintanance,
              base: 'under-maintanance',
            },
          ],
        },
      ],
    },
    {
      tittle: 'UI Interface',
      icon: 'file',
      showAsTab: false,
      separateRoute: false,
      menu: [
        {
          menuValue: 'Base UI',
          route: routes.dashboard,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'get-pocket',
          base: 'base-ui',
          materialicons: 'description',
          subMenus: [
            {
              menuValue: 'Alerts',
              route: routes.alert,
              base: 'ui-alerts',
            },
            {
              menuValue: 'Accordions',
              route: routes.accordions,
              base: 'ui-accordion',
            },
            { menuValue: 'Avatar', route: routes.avatar, base: 'ui-avatar' },
            { menuValue: 'Badges', route: routes.badges, base: 'ui-badges' },
            {
              menuValue: 'Buttons',
              route: routes.buttons,
              base: 'ui-buttons',
            },
            {
              menuValue: 'Button Group',
              route: routes.buttonGroup,
              base: 'ui-buttons-group',
            },
            {
              menuValue: 'Breadcrumb',
              route: routes.breadcrumb,
              base: 'ui-breadcrumb',
            },
            { menuValue: 'Cards', route: routes.cards, base: 'ui-cards' },
            {
              menuValue: 'Carousel',
              route: routes.carousel,
              base: 'ui-carousel',
            },
            {
              menuValue: 'Dropdowns',
              route: routes.dropDown,
              base: 'ui-dropdowns',
            },
            { menuValue: 'Grid', route: routes.grid, base: 'ui-grid' },
            { menuValue: 'Images', route: routes.images, base: 'ui-images' },
            {
              menuValue: 'Lightbox',
              route: routes.lightBox,
              base: 'ui-lightbox',
            },
            { menuValue: 'Media', route: routes.media, base: 'ui-media' },
            { menuValue: 'Modals', route: routes.modal, base: 'ui-modals' },
            {
              menuValue: 'Offcanvas',
              route: routes.offcanvas,
              base: 'ui-offcanvas',
            },
            {
              menuValue: 'Pagination',
              route: routes.pagination,
              base: 'ui-pagination',
            },

            {
              menuValue: 'Progress Bars',
              route: routes.progressBars,
              base: 'ui-progress',
            },
            {
              menuValue: 'Placeholders',
              route: routes.placeholder,
              base: 'ui-placeholders',
            },

            {
              menuValue: 'Spinner',
              route: routes.spinner,
              base: 'ui-spinner',
            },
            {
              menuValue: 'Range Slider',
              route: routes.rangeSlider,
              base: 'ui-rangeslider',
            },

            { menuValue: 'Toasts', route: routes.toasts, base: 'ui-toasts' },
            {
              menuValue: 'Tooltip',
              route: routes.tooltip,
              base: 'ui-tooltips',
            },
            {
              menuValue: 'Typography',
              route: routes.typography,
              base: 'ui-typography',
            },
            { menuValue: 'Videos', route: routes.video, base: 'ui-video' },
          ],
        },
        {
          menuValue: 'Advanced Ui',
          hasSubRoute: true,
          showSubRoute: false,
          base: 'advancedUi',
          icon: 'eject',
          materialicons: 'sync_alt',
          subMenus: [
            { menuValue: 'Ribbon', route: routes.ribbon, base: 'ui-ribbon' },
            {
              menuValue: 'Clipboard',
              route: routes.clipboards,
              base: 'ui-clipboard',
            },
            {
              menuValue: 'Drag & Drop',
              route: routes.dragDrop,
              base: 'ui-drag-drop',
            },
            {
              menuValue: 'Rating',
              route: routes.rating,
              base: 'ui-rating',
            },
            {
              menuValue: 'Text Editor',
              route: routes.textEditor,
              base: 'ui-text-editor',
            },
            {
              menuValue: 'Counter',
              route: routes.counter,
              base: 'ui-counter',
            },
            {
              menuValue: 'Scrollbar',
              route: routes.scrollbar,
              base: 'ui-scrollbar',
            },
            {
              menuValue: 'Timeline',
              route: routes.timeline,
              base: 'ui-timeline',
            },
          ],
        },
        {
          menuValue: 'Charts',
          hasSubRoute: true,
          showSubRoute: false,
          base: 'charts',
          icon: 'chart-line',
          materialicons: 'library_add_check',
          subMenus: [
            {
              menuValue: 'Apex Charts',
              route: routes.apexChart,
              base: 'apex-charts',
            },
            {
              menuValue: 'Ng2 Charts',
              route: routes.ngTwoCharts,
              base: 'ng2-charts',
            },
            {
              menuValue: 'Prime NG Charts',
              route: routes.chartPrime,
              base: 'prime-ng',
            },
          ],
        },
        {
          menuValue: 'Icons',
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'icons',
          base: 'icon',
          materialicons: 'people',
          subMenus: [
            {
              menuValue: 'Fontawesome Icons',
              route: routes.fontawesome,
              base: 'fontawesome',
            },
            {
              menuValue: 'Feather Icons',
              route: routes.feather,
              base: 'feather',
            },
            {
              menuValue: 'Ionic Icons',
              route: routes.ionic,
              base: 'ionic',
            },
            {
              menuValue: 'Material Icons',
              route: routes.material,
              base: 'material',
            },
            { menuValue: 'pe7 Icons', route: routes.pe7, base: 'pe7' },
            {
              menuValue: 'Simpleline Icons',
              route: routes.simpleLine,
              base: 'simple-line',
            },
            {
              menuValue: 'Themify Icons',
              route: routes.themify,
              base: 'themify',
            },
            {
              menuValue: 'Weather Icons',
              route: routes.weather,
              base: 'weather',
            },
            {
              menuValue: 'Typicon Icons',
              route: routes.typicon,
              base: 'typicon',
            },
            { menuValue: 'Flag Icons', route: routes.flag, base: 'flag' },
          ],
        },
        {
          menuValue: 'Forms',
          route: routes.forms,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'wpforms',
          base: 'forms',
          materialicons: 'view_day',

          subMenus: [
            {
              menuValue: 'Basic Inputs',
              route: routes.basicinput,
              base: 'form-basic-inputs',
            },
            {
              menuValue: 'Inputs Groups',
              route: routes.inputgroups,
              base: 'form-input-groups',
            },
            {
              menuValue: 'Horizontal Form',
              route: routes.horizontalform,
              base: 'form-horizontal',
            },
            {
              menuValue: 'Vertical Form',
              route: routes.verticalform,
              base: 'form-vertical',
            },
            {
              menuValue: 'Form Mask',
              route: routes.formmask,
              base: 'form-mask',
            },
            {
              menuValue: 'Form Validation',
              route: routes.formvalidation,
              base: 'form-validation',
            },
            {
              menuValue: 'Form Select2',
              route: routes.formSelect2,
              base: 'form-select-2',
            },
            {
              menuValue: 'File Upload',
              route: routes.fileUpload,
              base: 'form-fileupload',
            },
            {
              menuValue: 'Horizontal Timeline',
              route: routes.horizontalTimeline,
              base: 'horizontal-timeline',
            },
            {
              menuValue: 'Form Wizard',
              route: routes.formWizard,
              base: 'form-wizard',
            },
          ],
        },
        {
          menuValue: 'Tables',
          route: routes.tables,
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'table',
          base: 'tables',
          materialicons: 'table_rows',
          subMenus: [
            {
              menuValue: 'Basic Tables',
              route: routes.basictables,
              base: 'tables-basic',
            },
            {
              menuValue: 'Data Tables',
              route: routes.datatables,
              base: 'data-basic',
            },
          ],
        },
      ],
    },
    {
      tittle: 'Extras',
      icon: 'file',
      showAsTab: false,
      separateRoute: false,
      menu: [
        {
          menuValue: 'Documentation',
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'file-text',
          base: '1',
          materialicons: 'description',
          subMenus: [],
        },
        {
          menuValue: 'Change Log',
          changeLogVersion: true,
          hasSubRoute: false,
          showSubRoute: false,
          icon: 'info',
          base: '1',
          materialicons: 'sync_alt',
          subMenus: [],
        },
      ],
    },
    {
      tittle: 'Crm',
      icon: 'ticket',
      showAsTab: true,
      separateRoute: false,
      menu: [
        {
          menuValue: 'Crm',
          hasSubRoute: true,
          showSubRoute: false,
          icon: 'ticket',
          base: 'crm',
          materialicons: 'description',
          subMenus: [
            {
              menuValue: 'Companies',
              route: routes.companies,
              hasSubRoute: false,
              showSubRoute: false,
              base: 'crm',
            },
            {
              menuValue: 'Deals',
              route: routes.dealsList,
              hasSubRoute: false,
              showSubRoute: false,
              base: 'crm',
            },
            {
              menuValue: 'Leads',
              route: routes.leadsList,
              hasSubRoute: false,
              showSubRoute: false,
              base: 'leads',
            },
            {
              menuValue: 'Pipeline',
              route: routes.pipeline,
              hasSubRoute: false,
              showSubRoute: false,
              base: 'crm',
            },
            {
              menuValue: 'Analytics',
              route: routes.analytics,
              hasSubRoute: false,
              showSubRoute: false,
              base: 'analytics',
            },
            {
              menuValue: 'Activities',
              route: routes.activities,
              hasSubRoute: false,
              showSubRoute: false,
              base: 'activites',
            },
          ],
        },
      ],
    },
  ];

  public getSideBarData: BehaviorSubject<Array<SideBar>> = new BehaviorSubject<
    Array<SideBar>
  >(this.sideBar);
  public resetData(): void {
    this.sideBar.map((res: SideBar) => {
      res.showAsTab = false;
      res.menu.map((menus: SideBarMenu) => {
        menus.showSubRoute = false;
      });
    });
  }

  public getUserSideBarData: BehaviorSubject<Array<SideBar>> =
    new BehaviorSubject<Array<SideBar>>(this.userSideBar);
  public resetUserData(): void {
    this.userSideBar.map((res: SideBar) => {
      res.showAsTab = false;
      res.menu.map((menus: SideBarMenu) => {
        menus.showSubRoute = false;
      });
    });
  }

  public getSideBarData2: BehaviorSubject<Array<HorizontalSideBar>> =
    new BehaviorSubject<Array<HorizontalSideBar>>(this.sideBar2);
  public resetData2(): void {
    this.sideBar.map((res: SideBar) => {
      res.showAsTab = false;
      res.menu.map((menus: SideBarMenu) => {
        menus.showSubRoute = false;
      });
    });
  }
  allCustomPolicy = [
    {
      id: 1,
      name: 'John deo',
      days: 5,
    },
  ];

  companiesList = [
    {
      id: 1,
      company: 'Delta Infotech',
    },
    {
      id: 1,
      company: 'Delta Infotech',
    },
    {
      id: 1,
      company: 'Delta Infotech',
    },
    {
      id: 1,
      company: 'Delta Infotech',
    },
    {
      id: 1,
      company: 'Delta Infotech',
    },
  ];

  clientsDatas = [
    {
      name: 'Barry Cuda',
      role: 'CEO',
      company: 'Global Technologies',
      image: 'avatar-19',
      clientId: 'CLT-0008',
      email: 'barrycuda@example.com',
      phone: '9876543210',
      status: 'Active',
      id: 1,
      img: 'assets/img/profiles/avatar-19.jpg',
    },
    {
      name: 'Tressa Wexler',
      role: 'Manager',
      company: 'Delta Infotech',
      image: 'avatar-29',
      clientId: 'CLT-0003',
      email: 'tressawexler@example.com',
      phone: '9876543211',
      status: 'Inactive',
      id: 2,
      img: 'assets/img/profiles/avatar-29.jpg',
    },
    {
      name: 'Ruby Bartlett ',
      role: 'CEO',
      company: 'Cream Inc',
      image: 'avatar-07',
      clientId: 'CLT-0002',
      email: 'rubybartlett@example.com',
      phone: '9876543212',
      status: 'Inactive',
      id: 3,
      img: 'assets/img/profiles/avatar-07.jpg',
    },
    {
      name: 'Misty Tison',
      role: 'CEO',
      company: 'Wellware Company',
      image: 'avatar-06',
      clientId: 'CLT-0001',
      email: 'tisonmisty@example.com',
      phone: '9876543213',
      status: 'Inactive',
      id: 4,
      img: 'assets/img/profiles/avatar-06.jpg',
    },
    {
      name: 'Daniel Deacon',
      role: 'CEO',
      company: 'Mustang Technologies',
      image: 'avatar-14',
      clientId: 'CLT-0006',
      email: 'danieldeacon@example.com',
      phone: '9876543214',
      status: 'Active',
      id: 5,
      img: 'assets/img/profiles/avatar-14.jpg',
    },
    {
      name: 'Walter  Weaver',
      role: 'CEO',
      company: 'International Software',
      image: 'avatar-18',
      clientId: 'CLT-0007',
      email: 'walterweaver@example.com',
      phone: '9876543215',
      status: 'Active',
      id: 6,
      img: 'assets/img/profiles/avatar-18.jpg',
    },
    {
      name: 'Amanda Warren',
      role: 'CEO',
      company: 'Mercury Software Inc',
      image: 'avatar-28',
      clientId: 'CLT-0005',
      email: 'amandawarren@example.com',
      phone: '9876543216',
      status: 'Active',
      id: 7,
      img: 'assets/img/profiles/avatar-28.jpg',
    },
    {
      name: 'Bretty Carlson',
      role: 'CEO',
      company: 'Carlson Technologies',
      image: 'avatar-13',
      clientId: 'CLT-0004',
      email: 'bettycarlson@example.com',
      phone: '9876543217',
      status: 'Inactive',
      id: 8,
      img: 'assets/img/profiles/avatar-13.jpg',
    },
  ];

  companyData = [
    {
      name: 'Barry Cuda',
      role: 'CEO',
      company: 'YellowStone Xperiences',
      image: 'avatar-19',
      clientId: 'CLT-0008',
      email: 'barrycuda@example.com',
      phone: '9876543210',
      status: 'Active',
      id: 1,
      img: 'assets/img/logos/image.png',
    },
  ];
  projects = [
    {
      name: 'Office Management',
      description:
        'Lorem Ipsum is simply dummy text of the printing and typesetting industry. When an unknown printer took a galley of type and scrambled it...',
      endDate: '17-04-2023',
      startDate: '17-04-2023',
      priority: 'High',
      projectleader: 'Aravind',
      teamMember: 'Prakash',
      projectId: 'PRO-001',
      id: 1,
    },
    {
      name: 'Hospital Administration',
      description:
        'Lorem Ipsum is simply dummy text of the printing and typesetting industry. When an unknown printer took a galley of type and scrambled it...',
      endDate: '17-04-2023',
      startDate: '17-04-2023',
      priority: 'High',
      projectleader: 'Ashok',
      teamMember: 'Aravind',
      projectId: 'PRO-001',
      id: 2,
    },
    {
      name: 'Project Management',
      description:
        'Lorem Ipsum is simply dummy text of the printing and typesetting industry. When an unknown printer took a galley of type and scrambled it...',
      endDate: '17-08-2023',
      startDate: '17-07-2023',
      priority: 'High',
      projectleader: 'vijay',
      teamMember: 'prakash',
      projectId: 'PRO-001',
      id: 3,
    },
    {
      name: 'Video Calling App',
      description:
        'Lorem Ipsum is simply dummy text of the printing and typesetting industry. When an unknown printer took a galley of type and scrambled it...',
      endDate: '17-04-2023',
      startDate: '17-03-2023',
      priority: 'High',
      projectleader: 'Ashok',
      teamMember: 'Aravind',
      projectId: 'PRO-001',
      id: 4,
    },
    {
      name: 'Project Management',
      description:
        'Lorem Ipsum is simply dummy text of the printing and typesetting industry. When an unknown printer took a galley of type and scrambled it...',
      endDate: '17-08-2023',
      startDate: '17-07-2023',
      priority: 'High',
      projectleader: 'vijay',
      teamMember: 'prakash',
      projectId: 'PRO-001',
      id: 5,
    },
    {
      name: 'Office Management',
      description:
        'Lorem Ipsum is simply dummy text of the printing and typesetting industry. When an unknown printer took a galley of type and scrambled it...',
      endDate: '17-04-2023',
      startDate: '17-04-2023',
      priority: 'High',
      projectleader: 'Aravind',
      teamMember: 'Prakash',
      projectId: 'PRO-001',
      id: 6,
    },
  ];

  allKnowledgeBase = [
    {
      title: 'Installation & Activation',
      list1: 'Sed ut perspiciatis unde omnis?',
      list2: 'Sed ut perspiciatis unde omnis?',
      list3: 'Sed ut perspiciatis unde omnis?',
      list4: 'Sed ut perspiciatis unde omnis?',
      list5: 'Sed ut perspiciatis unde omnis?',
      id: 1,
    },
    {
      title: 'Premium Members Features',
      list1: 'Sed ut perspiciatis unde omnis?',
      list2: 'Sed ut perspiciatis unde omnis?',
      list3: 'Sed ut perspiciatis unde omnis?',
      list4: 'Sed ut perspiciatis unde omnis?',
      list5: 'Sed ut perspiciatis unde omnis?',
      id: 2,
    },
    {
      title: 'API Usage & Guide lines',
      list1: 'Sed ut perspiciatis unde omnis?',
      list2: 'Sed ut perspiciatis unde omnis?',
      list3: 'Sed ut perspiciatis unde omnis?',
      list4: 'Sed ut perspiciatis unde omnis?',
      list5: 'Sed ut perspiciatis unde omnis?',
      id: 3,
    },
    {
      title: 'Getting Started',
      list1: 'Sed ut perspiciatis unde omnis?',
      list2: 'Sed ut perspiciatis unde omnis?',
      list3: 'Sed ut perspiciatis unde omnis?',
      list4: 'Sed ut perspiciatis unde omnis?',
      list5: 'Sed ut perspiciatis unde omnis?',
      id: 4,
    },
    {
      title: 'Lorem ipsum dolor',
      list1: 'Sed ut perspiciatis unde omnis?',
      list2: 'Sed ut perspiciatis unde omnis?',
      list3: 'Sed ut perspiciatis unde omnis?',
      list4: 'Sed ut perspiciatis unde omnis?',
      list5: 'Sed ut perspiciatis unde omnis?',
      id: 5,
    },
    {
      title: 'Lorem ipsum dolor',
      list1: 'Sed ut perspiciatis unde omnis?',
      list2: 'Sed ut perspiciatis unde omnis?',
      list3: 'Sed ut perspiciatis unde omnis?',
      list4: 'Sed ut perspiciatis unde omnis?',
      list5: 'Sed ut perspiciatis unde omnis?',
      id: 6,
    },
    {
      title: 'Lorem ipsum dolor',
      list1: 'Sed ut perspiciatis unde omnis?',
      list2: 'Sed ut perspiciatis unde omnis?',
      list3: 'Sed ut perspiciatis unde omnis?',
      list4: 'Sed ut perspiciatis unde omnis?',
      list5: 'Sed ut perspiciatis unde omnis?',
      id: 7,
    },
    {
      title: 'Lorem ipsum dolor',
      list1: 'Sed ut perspiciatis unde omnis?',
      list2: 'Sed ut perspiciatis unde omnis?',
      list3: 'Sed ut perspiciatis unde omnis?',
      list4: 'Sed ut perspiciatis unde omnis?',
      list5: 'Sed ut perspiciatis unde omnis?',
      id: 8,
    },
    {
      title: 'Lorem ipsum dolor',
      list1: 'Sed ut perspiciatis unde omnis?',
      list2: 'Sed ut perspiciatis unde omnis?',
      list3: 'Sed ut perspiciatis unde omnis?',
      list4: 'Sed ut perspiciatis unde omnis?',
      list5: 'Sed ut perspiciatis unde omnis?',
      id: 9,
    },
  ];

  allroles = [
    {
      roleName: 'Administrator',
      id: 1,
    },
    {
      roleName: 'CEO',
      id: 2,
    },
    {
      roleName: 'Manager',
      id: 3,
    },
    {
      roleName: 'Team Leader',
      id: 4,
    },
    {
      roleName: 'Accountant',
      id: 5,
    },
    {
      roleName: 'Web Developer',
      id: 6,
    },
    {
      roleName: 'Web Designer',
      id: 7,
    },
    {
      roleName: 'HR',
      id: 8,
    },
    {
      roleName: 'UI/UX Developer',
      id: 9,
    },
    {
      roleName: 'SEO Analyst',
      id: 10,
    },
  ];

  allLeaveType = [
    {
      leaveType: 'Casual Leave',
      leaveDays: '12 Days',
      id: 1,
      status: 'Active',
    },
    {
      leaveType: 'Medical Leave',
      leaveDays: '12 Days',
      id: 2,
      status: 'Inactive',
    },
    {
      leaveType: 'Loss of Pay',
      leaveDays: '10 Days',
      id: 3,
      status: 'Active',
    },
  ];

  allIntegrations = [
    {
      name: 'Slack',
      key: 'fqhr9i3h4th9hqrfh3qf9jworfw89troqr',
      id: 1,
      status: 'Active',
    },
    {
      name: 'Stripe',
      key: '3ry9w3eihfiwer9hgwiher94tfewwer9g9herwig',
      id: 2,
      status: 'Inactive',
    },
    {
      name: 'Google',
      key: 'asdcgqu3ertq23r8iwhefhq87wehiwadf8',
      id: 3,
      status: 'Active',
    },
  ];
  lstEmployee = [
    {
      firstname: 'John Doe',
      lastname: 'Manseau',
      username: 'Manseau',
      password: '123445',
      confirmpassword: '123456',
      department: 'software',
      designation: 'Web Designer',
      phone: '9842354254',
      email: 'catherine@example.com',
      mobile: '9876543210',
      joindate: '18-04-2013',
      role: 'Web Developer',
      employeeId: 'FT-0001',
      company: 'FT-0001',
      id: 1,
      img: 'assets/img/profiles/avatar-02.jpg',
    },
    {
      firstname: 'Richard Miles',
      lastname: 'Manseau',
      username: 'Manseau',
      password: '123445',
      confirmpassword: '123456',
      department: 'software',
      designation: 'Web Developer',
      phone: '9842354254',
      email: 'catherine@example.com',
      mobile: '9876543210',
      joindate: '18-04-2013',
      role: 'Web Developer',
      employeeId: 'FT-0001',
      company: 'FT-0001',
      id: 2,
      img: 'assets/img/profiles/avatar-09.jpg',
    },
    {
      firstname: 'John Smith',
      lastname: 'Manseau',
      username: 'Manseau',
      password: '123445',
      confirmpassword: '123456',
      department: 'software',
      designation: 'Android Developer',
      phone: '9842354254',
      email: 'catherine@example.com',
      mobile: '9876543210',
      joindate: '18-05-2013',
      role: 'Web Developer',
      employeeId: 'FT-0001',
      company: 'FT-0001',
      id: 3,
      img: 'assets/img/profiles/avatar-10.jpg',
    },
    {
      firstname: 'Mike Litorus',
      lastname: 'Manseau',
      username: 'Manseau',
      password: '123445',
      confirmpassword: '123456',
      department: 'software',
      designation: 'IOS Developer',
      phone: '9842354254',
      email: 'catherine@example.com',
      mobile: '9876543210',
      joindate: '18-04-2013',
      role: 'Web Developer',
      employeeId: 'FT-0001',
      company: 'FT-0001',
      id: 4,
      img: 'assets/img/profiles/avatar-05.jpg',
    },
    {
      firstname: 'Wilmer Deluna',
      lastname: 'Manseau',
      username: 'Manseau',
      password: '123445',
      confirmpassword: '123456',
      department: 'software',
      designation: 'Team Leader',
      phone: '9842354254',
      email: 'catherine@example.com',
      mobile: '9876543210',
      joindate: '18-04-2013',
      role: 'Web Developer',
      employeeId: 'FT-0001',
      company: 'FT-0001',
      id: 5,
      img: 'assets/img/profiles/avatar-01.jpg',
    },
    {
      firstname: 'Jeffrey Warden',
      lastname: 'Manseau',
      username: 'Manseau',
      password: '123445',
      confirmpassword: '123456',
      department: 'software',
      designation: 'Web  Developer',
      phone: '9842354254',
      email: 'catherine@example.com',
      mobile: '9876543210',
      joindate: '18-04-2013',
      role: 'Web Developer',
      employeeId: 'FT-0001',
      company: 'FT-0001',
      id: 6,
      img: 'assets/img/profiles/avatar-12.jpg',
    },
    {
      firstname: 'Bernardo Galaviz',
      lastname: 'Manseau',
      username: 'Manseau',
      password: '123445',
      confirmpassword: '123456',
      department: 'software',
      designation: 'Web  Developer',
      phone: '9842354254',
      email: 'catherine@example.com',
      mobile: '9876543210',
      joindate: '18-04-2013',
      role: 'Web Developer',
      employeeId: 'FT-0001',
      company: 'FT-0001',
      id: 7,
      img: 'assets/img/profiles/avatar-13.jpg',
    },
    {
      firstname: 'Lesley Grauer',
      lastname: 'Manseau',
      username: 'Manseau',
      password: '123445',
      confirmpassword: '123456',
      department: 'software',
      designation: 'Team Leader',
      phone: '9842354254',
      email: 'catherine@example.com',
      mobile: '9876543210',
      joindate: '18-04-2013',
      role: 'Web Developer',
      employeeId: 'FT-0001',
      company: 'FT-0001',
      id: 8,
      img: 'assets/img/profiles/avatar-16.jpg',
    },
    {
      firstname: 'Jeffery Lalor',
      lastname: 'Manseau',
      username: 'Manseau',
      password: '123445',
      confirmpassword: '123456',
      department: 'software',
      designation: 'Team Leader',
      phone: '9842354254',
      email: 'catherine@example.com',
      mobile: '9876543210',
      joindate: '18-04-2013',
      role: 'Web Developer',
      employeeId: 'FT-0001',
      company: 'FT-0001',
      id: 9,
      img: 'assets/img/profiles/avatar-16.jpg',
    },
    {
      firstname: 'Loren Gatlin',
      lastname: 'Manseau',
      username: 'Manseau',
      password: '123445',
      confirmpassword: '123456',
      department: 'software',
      designation: 'Android Developer',
      phone: '9842354254',
      email: 'catherine@example.com',
      mobile: '9876543210',
      joindate: '18-04-2013',
      role: 'Web Developer',
      employeeId: 'FT-0001',
      company: 'FT-0001',
      id: 10,
      img: 'assets/img/profiles/avatar-04.jpg',
    },
    {
      firstname: 'Tarah Shropshire',
      lastname: 'Manseau',
      username: 'Manseau',
      password: '123445',
      confirmpassword: '123456',
      department: 'software',
      designation: 'Android Developer',
      phone: '9842354254',
      email: 'catherine@example.com',
      mobile: '9876543210',
      joindate: '18-04-2013',
      role: 'Web Developer',
      employeeId: 'FT-0001',
      company: 'FT-0001',
      id: 11,
      img: 'assets/img/profiles/avatar-03.jpg',
    },
    {
      firstname: 'Catherine Manseau',
      lastname: 'Manseau',
      username: 'Manseau',
      password: '123445',
      confirmpassword: '123456',
      department: 'software',
      designation: 'Android Developer',
      phone: '9842354254',
      email: 'catherine@example.com',
      mobile: '9876543210',
      joindate: '18-04-2013',
      role: 'Web Developer',
      employeeId: 'FT-0001',
      company: 'FT-0001',
      id: 12,
      img: 'assets/img/profiles/avatar-08.jpg',
    },
  ];
  public getTicketsListCount(accountId: string, locationId: string) {
    const url = `/api/Ticket/GetTicketCount?accountId=${accountId}&locationId=${locationId}`;
    return this.http.get(url);
  }
}
