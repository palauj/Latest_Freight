import { inject, Injectable } from '@angular/core';
import { HttpService } from '../http/http.service';
import { HttpHeaders } from '@angular/common/http';
import { BaseResponse } from '../../helpers/models/common.model';
import { Observable } from 'rxjs';
import { TaskTimeTrackData } from '../../helpers/models/project.model';

@Injectable({
  providedIn: 'root',
})
export class TaskService {
  private httpService = inject(HttpService);

  headers = new HttpHeaders({
    clientId: 'DigiHRMS',
    clientSecret: 'DigiHRMSSecret',
  });
  options = { headers: this.headers };

  saveTaskTimeTrackingRecord(
    data: TaskTimeTrackData
  ): Observable<BaseResponse> {
    return this.httpService.post(
      `/api/Task/SaveTaskTimeTrackingRecord`,
      data,
      this.options
    );
  }

  updateTaskTimeTrackingRecord(
    data: TaskTimeTrackData
  ): Observable<BaseResponse> {
    return this.httpService.put(
      `/api/Task/UpdateTaskTimeTrackingRecord`,
      data,
      this.options
    );
  }

  getTaskTimeTrackingRecordById(id: string): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Task/GetTaskTimeTrackingRecordById?id=${id}`,
      this.options
    );
  }
}
