import { inject, Injectable } from '@angular/core';
import { HttpService } from '../http/http.service';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BaseResponse } from '../../helpers/models/common.model';
import { AddDesignation } from '../../helpers/models/designation.model';

@Injectable({
  providedIn: 'root',
})
export class DesignationsService {
  private httpService = inject(HttpService);

  headers = new HttpHeaders({
    clientId: 'DigiHRMS',
    clientSecret: 'DigiHRMSSecret',
  });
  options = { headers: this.headers };

  addDesignation(data: AddDesignation): Observable<BaseResponse> {
    return this.httpService.post(
      `/api/Designation/SaveAndUpdateDesignation`,
      data,
      this.options
    );
  }

  editDesignation(id: string): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Designation/GetDesignationDataById?designationId=${id}`,
      this.options
    );
  }

  getAllDesignation(params: { search: string; pageNo: number; pageSize: number; totalCount: number; }): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Designation/GetDesignationList??SearchQuery=&PageNumber=1&PageSize=500`,
      this.options
    );
  }

  deleteDesignation(id: string): Observable<BaseResponse> {
    return this.httpService.delete(
      `/api/Designation/DeleteDesignationRecordById?designationId=${id}`,
      this.options
    );
  }
}
