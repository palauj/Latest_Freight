import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BaseResponse } from '../../helpers/models/common.model';
import { HttpService } from '../http/http.service';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class CompanyPolicyService {
  private httpService = inject(HttpService);

  headers = new HttpHeaders({
    clientId: 'DigiHRMS',
    clientSecret: 'DigiHRMSSecret',
  });
  options = { headers: this.headers };

  upsertCompanyPolicyDocumentRecord(data: FormData): Observable<BaseResponse> {
    return this.httpService.post(
      `/api/CompanyPolicyDocument/UpsertCompanyPolicyDocumentRecord`,
      data,
      this.options
    );
  }

  getCompanyPolicyDocumentRecordList(
    pageNumber: number,
    pageSize: number,
    accountId: string,
    locationId: string
  ): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/CompanyPolicyDocument/GetCompanyPolicyDocumentRecordList?PageNumber=${pageNumber}&PageSize=${pageSize}&AccountId=${accountId}&LocationId=${locationId}`,
      this.options
    );
  }

  getCompanyPolicyDocumentDataByDocumentId(
    documentId: string
  ): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/CompanyPolicyDocument/GetCompanyPolicyDocumentDataByDocumentId?documentId=${documentId}`,
      this.options
    );
  }

  getDownloadViewCompanyPolicyDocumentByDocId(
    documentId: string,
    mode: string
  ): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/CompanyPolicyDocument/GetDownloadViewCompanyPolicyDocumentByDocId?documentId=${documentId}&mode=${mode}`,
      this.options
    );
  }

  deleteCompanyPolicyDocumentRecordByDocumentId(
    documentId: string,
    userId: string
  ): Observable<BaseResponse> {
    return this.httpService.delete(
      `/api/CompanyPolicyDocument/DeleteCompanyPolicyDocumentRecordByDocumentId?documentId=${documentId}&userId=${userId}`,
      this.options
    );
  }
}
