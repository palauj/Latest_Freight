import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';
import { environment } from 'src/environments/environment';
import { CommonService } from '../common/common.service';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class EncryptionService {
  secretKey = environment.secretKey;

  constructor(private commonService: CommonService) {}

  encrypt(data: any): Observable<string> {
    let newData = data;
    if (typeof data !== 'string') {
      newData = JSON.stringify(data);
    }
    const encryptedData = CryptoJS.AES.encrypt(
      newData,
      this.secretKey
    ).toString();
    return of(encryptedData);
  }

  decrypt(data: string): Observable<any> {
    const decryptData = CryptoJS.AES.decrypt(data, this.secretKey).toString(
      CryptoJS.enc.Utf8
    );
    if (this.commonService.isValidJson(decryptData)) {
      return of(JSON.parse(decryptData));
    }
    return of(decryptData);
  }
}
