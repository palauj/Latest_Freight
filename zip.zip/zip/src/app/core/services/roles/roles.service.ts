import { inject, Injectable } from '@angular/core';
import { HttpService } from '../http/http.service';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AddRole } from '../../helpers/models/role.model';
import { BaseResponse } from '../../helpers/models/common.model';

@Injectable({
  providedIn: 'root',
})
export class RolesService {
  private httpService = inject(HttpService);

  headers = new HttpHeaders({
    clientId: 'DigiHRMS',
    clientSecret: 'DigiHRMSSecret',
  });
  options = { headers: this.headers };

  addRole(data: AddRole): Observable<BaseResponse> {
    return this.httpService.post(
      `/api/Role/SaveAndUpdateRole`,
      data,
      this.options
    );
  }

  editRole(id: string): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Role/GetRoleDataById?id=${id}`,
      this.options
    );
  }

  getAllRoles(): Observable<BaseResponse> {
    return this.httpService.get(`/api/Role/GetRoleList`, this.options);
  }

  deleteRole(id: string): Observable<BaseResponse> {
    return this.httpService.delete(
      `/api/Role/DeleteRoleDataById?id=${id}`,
      this.options
    );
  }
}
