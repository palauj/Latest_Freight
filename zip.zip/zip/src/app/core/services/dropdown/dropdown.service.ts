import { inject, Injectable } from '@angular/core';
import { HttpService } from '../http/http.service';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BaseResponse } from '../../helpers/models/common.model';

@Injectable({
  providedIn: 'root',
})
export class DropdownService {
  private httpService = inject(HttpService);

  headers = new HttpHeaders({
    clientId: 'DigiHRMS',
    clientSecret: 'DigiHRMSSecret',
  });
  options = { headers: this.headers };

  getEmployeeList(
    accountId: string,
    locationId: string
  ): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Dropdown/GetEmployeeDropdownList?accountId=${accountId}&locationId=${locationId}`,
      this.options
    );
  }

  getDepartmentList(
    accountId: string,
    locationId: string
  ): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Dropdown/GetDepartmentDropdownList?accountId=${accountId}&locationId=${locationId}`,
      this.options
    );
  }

  getAccountList(): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Dropdown/GetAccountDropdownList`,
      this.options
    );
  }

  getLocationList(id: string): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Dropdown/GetAccountLocationDropdownList?accountId=${id}`,
      this.options
    );
  }

  getTeamList(): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Dropdown/GetTeamDropdownList`,
      this.options
    );
  }

  getDropdownForAccountTeamList(
    accountId: string,
    locationId: string
  ): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Dropdown/GetDropdownForAccountTeamList?accountId=${accountId}&locationId=${locationId}`,
      this.options
    );
  }

  getDropdownListForAccountTeamMember(
    accountTeamId: string
  ): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Dropdown/GetDropdownListForAccountTeamMember?accountTeamId=${accountTeamId}`,
      this.options
    );
  }

  getMasterDesignationDropdownList(): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Dropdown/GetDropdownListForDesignation`,
      this.options
    );
  }

  getMasterDepartmentDropdownList(): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Dropdown/GetDropdownListForDepartment`,
      this.options
    );
  }

  getMasterRolesDropdownList(): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Dropdown/GetDropdownListForRoles`,
      this.options
    );
  }
  getDropdownListForStatusMaster(parentId: string): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Dropdown/GetDropdownListForStatusMaster?parentId=${parentId}`,
      this.options
    );
  }

  getSocialLinksDropdownList(): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Dropdown/GetDropdownListForSocialLinks`,
      this.options
    );
  }

  getCountriesDropdownList(): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Dropdown/GetDropdownListForCountry`,
      this.options
    );
  }

  getStatesDropdownList(countryId: number): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Dropdown/GetDropdownListForState?countryId=${countryId}`,
      this.options
    );
  }

  getCitiesDropdownList(state: number): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Dropdown/GetDropdownListForCity?state=${state}`,
      this.options
    );
  }

  getDropdownForClientList(
    accountId: string,
    locationId: string
  ): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Dropdown/GetDropdownForClientList?accountId=${accountId}&locationId=${locationId}`,
      this.options
    );
  }

  public getSubLookupList(id: string): Observable<any> {
    const url = `/api/LookUp/GetSubLookUpListRecord?lookupId=${id}`;
    return this.httpService.get(url);
  }

  public getVenderDropDownList(data: any): Observable<any> {
    const url = `/api/Dropdown/GetDropdownVenderList?accountId=${data?.accountId}&locationId=${data?.locationId}`;
    return this.httpService.get(url);
  }

  public getClientDropDownList(data: any): Observable<any> {
    const url = `/api/Dropdown/GetDropdownForOutSourceClientList?accountId=${data?.accountId}&locationId=${data?.locationId}`;
    return this.httpService.get(url);
  }

  public getClientDropDownListForProject(data: any): Observable<any> {
    const url = `/api/Dropdown/GetDropdownForClientList?accountId=${data?.accountId}&locationId=${data?.locationId}`;
    return this.httpService.get(url);
  }

  public getCategoryMasterList(data: any): Observable<any> {
    const url = `/api/Category/GetCategoryMasterList?parentId=${data?.parentId}&categoryType=${data?.categoryType}&PageNumber=1&PageSize=100`;
    return this.httpService.get(url);
  }

  public addCategoryDownList(data: any): Observable<any> {
    const url = '/api/Category/SaveAndUpdateCategory';
    return this.httpService.post(url, data);
  }
  public addCommonCategoryDownList(data: any): Observable<any> {
    const url = '/api/CommonMasterCategory/SaveMasterCategoryRecord';
    return this.httpService.post(url, data);
  }

  public getDropdownForCategoryMasterList() {
    const url = '/api/Dropdown/GetDropdownForCategoryMasterList';
    return this.httpService.get(url);
  }

 public  getDropdownForSubCategoryMasterListById( parentId: any){
    const url = `/api/Dropdown/GetDropdownForSubCategoryMasterListById?parentId=${parentId}`
    return this.httpService.get(url)
  }

 public  getTablesRecordList(){
    const url = '/api/Common/GetTablesRecordList';
    return this.httpService.get(url)
  }
  
  
  
  public getSUbLookUpDropDownList(id:string){
    const url = `/api/Dropdown/GetSubLookUpDropdownList?lookUpId=${id}`;
    return this.httpService.get(url)
  }
}
