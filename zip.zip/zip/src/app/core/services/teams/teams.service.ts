import { inject, Injectable } from '@angular/core';
import { HttpService } from '../http/http.service';
import { HttpHeaders } from '@angular/common/http';
import { BaseResponse } from '../../helpers/models/common.model';
import { Observable } from 'rxjs';
import { AddTeam } from '../../helpers/models/team.model';

@Injectable({
  providedIn: 'root',
})
export class TeamsService {
  private httpService = inject(HttpService);

  headers = new HttpHeaders({
    clientId: 'DigiHRMS',
    clientSecret: 'DigiHRMSSecret',
  });
  options = { headers: this.headers };

  addTeam(data: AddTeam): Observable<BaseResponse> {
    return this.httpService.post(
      `/api/Team/SaveAndUpdateTeam`,
      data,
      this.options
    );
  }

  editTeam(id: string): Observable<BaseResponse> {
    return this.httpService.get(
      `/api/Team/GetTeamDataById?teamId=${id}`,
      this.options
    );
  }

  getAllTeams(): Observable<BaseResponse> {
    return this.httpService.get(`/api/Team/GetTeamList`, this.options);
  }

  deleteTeam(id: string): Observable<BaseResponse> {
    return this.httpService.delete(
      `/api/Team/DeleteTeamRecordById?teamId=${id}`,
      this.options
    );
  }
}
