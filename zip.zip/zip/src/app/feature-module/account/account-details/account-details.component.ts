import { Location } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { catchError, EMPTY, take } from 'rxjs';
import {
  AccessList,
  AccountDetails,
  AddressInfoList,
  BasicInfoList,
  LicensePlanList,
  LocationModel,
  SocialProfiles,
} from 'src/app/core/helpers/models/account.model';
import { LoginUserData } from 'src/app/core/helpers/models/auth.model';
import {
  NoteList,
  ProjectDocuments,
} from 'src/app/core/helpers/models/project.model';
import { routes } from 'src/app/core/helpers/routes/routes';
import { AccountService } from 'src/app/core/services/account/account.service';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { environment } from 'src/environments/environment';
import { NotesDialogComponent } from '../../employee/projects/notes-dialog/notes-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { NotesService } from 'src/app/core/services/notes/notes.service';
import { ConfirmationDialogComponent } from 'src/app/shared/dialogs/confirmation-dialog/confirmation-dialog.component';
import { DocumentsService } from 'src/app/core/services/documents/documents.service';
import { AccountConstant } from 'src/app/core/helpers/constants/common.constant';
import { DepartmentContent } from 'src/app/core/helpers/constants/modals.constants';
import { PreviewDialogComponent } from 'src/app/shared/dialogs/preview-dialog/preview-dialog.component';
import { LocationDialogComponent } from '../account-content-page/create-account/location-dialog/location-dialog.component';
import { BasicInfoDialogComponent } from '../account-content-page/create-account/basic-info-dialog/basic-info-dialog.component';
import { LicenseDialogComponent } from '../account-content-page/create-account/license-dialog/license-dialog.component';
import { Activities } from 'src/app/core/helpers/models/common.model';
import { ActivityService } from 'src/app/core/services/activity/activity.service';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrl: './account-details.component.scss',
})
export class AccountDetailsComponent implements OnInit {
  public routes = routes;
  accountId!: string;
  id!: string;
  base64Image!: string | ArrayBuffer | null;
  accountDetails!: AccountDetails;
  isImageChanged = false;
  authUser!: LoginUserData;
  notesList: NoteList[] = [];
  multipleFiles: File[] = [];
  isSuccess = false;
  projectDocuments: ProjectDocuments[] = [];
  accountActivities: Activities[] = [];
  fileSrc: string[] = [];
  totalRecords!: number;
  isfile: boolean = false;
  activeTab = 'activities';

  accessList!: AccessList;
  basicInfoList!: BasicInfoList;
  addressInfoList!: AddressInfoList;
  licenseList!: LicensePlanList;
  socialList!: SocialProfiles;
  locationList!: LocationModel[];
  apiUrl = environment.apiUrl;

  private activateRoute = inject(ActivatedRoute);
  public router = inject(Router);
  private toaster = inject(ToasterService);
  private accountService = inject(AccountService);
  private location = inject(Location);
  private notesService = inject(NotesService);
  private documentService = inject(DocumentsService);
  private activityService = inject(ActivityService);
  readonly dialog = inject(MatDialog);

  ngOnInit(): void {
    this.activateRoute.params.subscribe((params) => {
      const accountId = params['id'];
      this.accountId = accountId;
      if (this.accountId) {
        localStorage.setItem('accountId', this.accountId);
        this.getAccountDetails(this.accountId);
        this.fetchActivities();
      }
    });
    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);
  }

  fetchActivities(): void {
    this.activityService
      .getActivityList(this.accountId, AccountConstant.relatedTo, 1, 50)
      .subscribe({
        next: (response) => {
          if (response.statusCode === 200) {
            this.accountActivities = response.data.activityHistoryList;
          } else {
            console.error('Failed to fetch lead activities:', response.message);
          }
        },
        error: (error) => {
          console.error('Error fetching lead activities:', error);
        },
      });
  }

  getNotesList(): void {
    this.notesList = [];
    this.notesService
      .getAllNotes(
        this.accountId,
        this.authUser.accountId,
        this.authUser.employeeLocation[0].locationId,
        1,
        50
      )
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.notesList = response.data.notesList.map((note: any) => ({
              ...note,
              backgroundColor: this.generateRandomColor(), // Add a random background color
            }));
            this.totalRecords = response.data.totalRecords;
          }
        }
      });
  }

  generateRandomColor(): string {
    const r = Math.floor(Math.random() * 156) + 100; // Red: Range 100-255
    const g = Math.floor(Math.random() * 156) + 100; // Green: Range 100-255
    const b = Math.floor(Math.random() * 156) + 100; // Blue: Range 100-255
    return `rgba(${r}, ${g}, ${b}, 0.2)`; // Add opacity (0.8 for a subtle effect)
  }

  openDeleteNoteDialog(id: string): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '500px',
      data: {
        title: `Delete Note`,
        submitBtn: 'Delete',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.deleteNote(id);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  deleteNote(id: string): void {
    this.notesService
      .deleteNote(id, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.createActivity('deleted', 'DELETE', 'Note');
            this.getNotesList();
            this.fetchActivities();
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }

  private getAccountDetails(id: string): void {
    this.accountService
      .getAccountDetailById(id)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.accountDetails = response.data;

            this.basicInfoList = this.accountDetails.accountBasicInfoList[0];
            if (this.basicInfoList?.fileData) {
              this.base64Image = `data:image/jpeg;base64,${this.basicInfoList?.fileData}`;
            } else {
              this.base64Image = 'assets/img/profiles/avatar-2.jpg';
            }

            this.addressInfoList =
              this.accountDetails.accountAddressInfoList[0];
            this.locationList = this.accountDetails.accountLocationList;
            this.accessList = this.accountDetails.accountAccessList[0];
            this.licenseList = this.accountDetails.accountLicensePlanList[0];
            this.socialList = this.accountDetails.accountSocialInfoList[0];
          } else {
            this.toaster.typeError(response.message, 'Error');
            return;
          }
        }
      });
  }

  goBack(): void {
    this.location.back();
  }

  onFileChange(event: any): void {
    const file = event.target.files[0];
    if (file) {
      const maxSize = 2 * 1024 * 1024;
      if (file.size > maxSize) {
        this.toaster.typeError(
          'File size exceeds the maximum limit of 2MB',
          'Error'
        );
        return;
      }

      const allowedFormats = ['image/jpeg', 'image/png', 'image/jpg'];
      if (!allowedFormats.includes(file.type)) {
        this.toaster.typeError(
          'Invalid file format. Please upload a JPG, JPEG, or PNG file.',
          'Error'
        );
        return;
      }

      const reader = new FileReader();
      reader.onload = () => {
        const base64Data = reader.result;
        this.base64Image = base64Data;
        this.isImageChanged = true;
      };
      reader.readAsDataURL(file);
      this.updateProfileImage(file);
    }
  }

  updateProfileImage(file: File): void {
    const formData = new FormData();
    formData.append('AccountId', this.accountId);
    formData.append('ProfilePicture', file);
    formData.append('UserId', this.authUser.employeeId);
    formData.append('IsImageUpdate', 'true');
    formData.append('FileData', file);

    // API call to update the profile data
    this.accountService
      .UpdateAccountProfile(formData)
      .pipe(take(1))
      .subscribe((res: any) => {
        if (res && res.message) {
          if (res.statusCode === 200) {
            this.toaster.typeSuccess(res?.message, 'Success');
            this.getAccountDetails(this.accountId);
          } else {
            this.toaster.typeError(res.message, 'Error');
            return;
          }
        }
      });
  }

  createNote(): void {
    const dialogRef = this.dialog.open(NotesDialogComponent, {
      width: '500px',
      data: {
        title: 'Add Note',
        submitBtn: 'Create',
        closeBtn: 'Close',
        relatedToId: this.accountId,
        accountName: this.authUser.accountName,
        accountId: this.authUser.accountId,
        locationId: this.authUser.employeeLocation[0].locationId,
        locationName: this.authUser.employeeLocation[0].locationName,
        activityRelatedToId: this.accountId,
        activityRelatedTo: AccountConstant.relatedTo,
        activityRelatedToName: this.basicInfoList.accountTransactionNumber,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.createActivity('Added', 'ADD', 'Note');
        this.getNotesList();
        this.fetchActivities();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  onMultipleSelect(files: File[]): void {
    this.multipleFiles = files;

    // Clear previous file sources before adding new ones
    this.fileSrc = [];
    let filesRead = 0;

    // Loop through the selected files and read them
    this.multipleFiles.forEach((file, index) => {
      const reader = new FileReader();

      reader.onload = () => {
        this.fileSrc[index] = reader.result as string;
        filesRead++;

        // Once all files are read, proceed with further processing
        if (filesRead === this.multipleFiles.length) {
          this.isfile = this.fileSrc.length > 0;

          if (this.fileSrc.length > 0) {
            const formData = new FormData();

            // Append files to formData
            this.multipleFiles.forEach((file) => {
              formData.append('Documents', file, file.name);
            });

            formData.append('Id', this.id ? this.id : '');
            formData.append('RelatedToId', this.accountId);
            formData.append('UserId', this.authUser.employeeId);
            formData.append('RelatedTo', AccountConstant.relatedTo);
            formData.append('RelatedToName', AccountConstant.relatedToName);
            formData.append('AccountId', this.authUser.accountId);
            formData.append(
              'LocationId',
              this.authUser.employeeLocation[0].locationId
            );

            this.documentService
              .saveAndUpdateDocument(formData)
              .pipe(
                catchError((error: any) => {
                  console.error('Error saving documents:', error);
                  return EMPTY; // Gracefully handle error
                }),
                take(1)
              )
              .subscribe((response: any) => {
                if (response && response.message) {
                  if (
                    response.statusCode === 200 ||
                    response.statusCode === 201
                  ) {
                    this.isSuccess = response.data.success;
                    this.createActivity('added', 'ADD', 'Document');
                    this.getDocumentList(); // Update document list
                    this.fetchActivities();
                    this.toaster.typeSuccess(
                      response.data ? response.data.message : response.message,
                      'Success'
                    );
                  } else {
                    this.toaster.typeError(
                      response.data ? response.data.message : response.message,
                      'Error'
                    );
                  }
                }
              });
          }
        }
      };

      reader.onerror = (error) => {
        console.error('Error reading file:', error);
      };

      reader.readAsDataURL(file); // Read the file as data URL
    });
  }

  private getDocumentList(): void {
    this.documentService
      .getDocumentList(
        1,
        50,
        this.accountId,
        this.authUser.accountId,
        this.authUser.employeeLocation[0].locationId
      )
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.projectDocuments = response.data.documentList;
          }
        }
      });
  }

  previewDoc(event: { file: ProjectDocuments; flag: string }): any {
    const { file, flag } = event;
    if (flag === 'download') {
      this.documentService
        .getDownloadViewDocumentById(file?.id, flag)
        .pipe(
          catchError((error: any) => {
            return EMPTY;
          }),
          take(1)
        )
        .subscribe((pdfBlob: any) => {
          let receivedData = new Blob([pdfBlob], {
            type: file?.documentExtension,
          });
          const url = window.URL.createObjectURL(receivedData);
          const link = document.createElement('a');

          link.href = url;
          link.download = file?.documentFileName;
          link.click();
          URL.revokeObjectURL(url);
        });
    } else {
      const dialogRef = this.dialog.open(PreviewDialogComponent, {
        width: '90vw',
        height: '90vh',

        data: {
          title: 'Preview',
          file: file,
          submitBtn: DepartmentContent.SUBMIT,
          closeBtn: DepartmentContent.CLOSE,
        },
      });

      dialogRef.afterClosed().subscribe((result) => {
        if (result) {
          // console.log('Department added:', result);
        } else {
          // console.log('Dialog was closed without adding a department.');
        }
      });
    }
  }

  openDeleteDialog(id: string): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '500px',
      data: {
        title: `Delete Document`,
        submitBtn: 'Delete',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.onRemoveMultiple(id);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  onRemoveMultiple(id: string): void {
    this.documentService
      .deleteDocumentById(id, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.createActivity('deleted', 'DELETE', 'Document');
            this.getDocumentList();
            this.fetchActivities();
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
          }
        }
      });
  }

  addLocation(): void {
    const dialogRef = this.dialog.open(LocationDialogComponent, {
      width: '600px',
      data: {
        title: 'Add Location',
        accountId: this.accountId,
        accountName: this.basicInfoList.companyName,
        submitBtn: 'Submit',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.createActivity('added', 'ADD', 'Location');
        this.getAccountDetails(this.accountId);
        this.fetchActivities();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  editLocation(id: string): void {
    const dialogRef = this.dialog.open(LocationDialogComponent, {
      width: '600px',
      data: {
        title: 'Edit Location',
        accountId: this.accountId,
        accountName: this.basicInfoList.companyName,
        submitBtn: 'Update',
        closeBtn: 'Close',
        id: id,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.createActivity('updated', 'UPDATE', 'Location');
        this.getAccountDetails(this.accountId);
        this.fetchActivities();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  openDeleteLocationDialog(id: string): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '500px',
      data: {
        title: 'Delete Location',
        submitBtn: 'Delete',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.deleteLocation(id);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  deleteLocation(id: string): void {
    this.accountService
      .deleteAccountLocationById(id, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.createActivity('deleted', 'DELETE', 'Location');
            this.getAccountDetails(this.accountId);
            this.fetchActivities();
            this.toaster.typeSuccess(response.message, 'Success');
          } else {
            this.toaster.typeError(response.message, 'Error');
            return;
          }
        }
      });
  }

  editAccount(id: string): void {
    const dialogRef = this.dialog.open(BasicInfoDialogComponent, {
      width: '600px',
      data: {
        title: 'Edit Basic Details',
        submitBtn: 'Update',
        closeBtn: 'Close',
        id: id,
        basicData: this.basicInfoList,
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.createActivity('updated', 'UPDATE', 'Basic-details');
        this.getAccountDetails(this.accountId);
        this.fetchActivities();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  editLicense(id: string, licenseId: string): void {
    const dialogRef = this.dialog.open(LicenseDialogComponent, {
      width: '600px',
      data: {
        title: 'Edit License Details',
        submitBtn: 'Update',
        closeBtn: 'Close',
        accountId: id,
        licenseId: licenseId,
        licenseData: this.licenseList,
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.createActivity('updated', 'UPDATE', 'License-details');
        this.getAccountDetails(this.accountId);
        this.fetchActivities();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  tabChange(data: string): void {
    this.activeTab = data;
    switch (this.activeTab) {
      case 'notes':
        this.getNotesList();
        break;
      case 'documents':
        this.getDocumentList();
        break;
    }
  }

  createActivity(status: string, action: string, type: string): void {
    let description = `${type} ${status} by ${this.authUser?.employeeName}`;
    let data = {
      activityActionName: action,
      activityStatus: action === 'ADD' ? 'S' : action.charAt(0),
      activityDescription: description,
      activityRelatedToId: this.accountId,
      activityRelatedTo: AccountConstant.relatedTo,
      activityRelatedToName: this.basicInfoList.accountTransactionNumber,
      accountId: this.authUser.accountId,
      accountName: this.authUser.accountName,
      locationId: this.authUser.employeeLocation[0].locationId,
      locationName: this.authUser.employeeLocation[0].locationName,
      userId: this.authUser?.employeeId,
    };
    this.activityService
      .addActivity(data)
      .pipe(
        catchError((error: any) => {
          console.error('Error saving documents:', error);
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((res) => {
        if (res?.statusCode < 399) {
          this.toaster.typeSuccess(res?.message);
        } else {
          this.toaster.typeError(res?.message);
        }
      });
  }
}
