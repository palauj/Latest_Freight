import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccountComponent } from './account.component';
import { AccountListComponent } from './account-list/account-list.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { CreateAccountComponent } from './account-content-page/create-account/create-account.component';
import { LocationDetailsComponent } from './account-content-page/create-account/location-details/location-details.component';
import { TeamsComponent } from './account-content-page/create-account/location-details/teams/teams.component';
import { PermissionsComponent } from './account-content-page/create-account/location-details/permissions/permissions.component';
import { TeamMemberComponent } from './account-content-page/create-account/location-details/team-member/team-member.component';
import { AuthGuard } from 'src/app/core/guards/auth.guard';

const routes: Routes = [
  {
    path: '',
    component: AccountComponent,
    children: [
      { path: '', redirectTo: 'account-list', pathMatch: 'full' },
      {
        path: 'account-list',
        canActivate: [AuthGuard],
        data: { claimType: ['ACC_VIEW', 'ACC_ADD', 'ACC_EDIT','ACC_UPDATE', 'ACC_DEL', 'ACC_EXPO', 'ACC_HIST', 'ACC_LOC_VIEW'] },
        component: AccountListComponent
      },
      {
        path: 'account-details/:id',
        canActivate: [AuthGuard],
        data: { claimType: ['ACC_VIEW', 'ACC_ADD', 'ACC_EDIT','ACC_UPDATE', 'ACC_DEL', 'ACC_EXPO', 'ACC_HIST', 'ACC_LOC_VIEW']},
        component: AccountDetailsComponent
      },
      {
        path: 'create-account',
        canActivate: [AuthGuard],
        data: { claimType: ['ACC_ADD'] },
        component: CreateAccountComponent
      },
      {
        path: 'edit-account/:id',
        canActivate: [AuthGuard],
        data: { claimType: ['ACC_EDIT'] },
        component: CreateAccountComponent
      },
      {
        path: 'location-details/:id',
        canActivate: [AuthGuard],
        data: { claimType: ['ACC_ADD_LOC','ACC_EDIT_LOC','ACC_UPDATE_LOC','ACC_LOC_VIEW'] },
        component: LocationDetailsComponent
      },
      { path: 'permissions/:id', component: PermissionsComponent },
      { path: 'team-members/:id', component: TeamMemberComponent },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AccountModuleRoutingModule { }
