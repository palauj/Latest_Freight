import {
  AfterViewInit,
  Component,
  inject,
  OnInit,
  ViewChild,
} from '@angular/core';
import { MatChipInputEvent, MatChipEditedEvent } from '@angular/material/chips';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { DataService, companies, routes } from 'src/app/core/core.index';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AccountService } from 'src/app/core/services/account/account.service';
import { environment } from 'src/environments/environment';
import { MatPaginator } from '@angular/material/paginator';
import { catchError, debounceTime, distinctUntilChanged, EMPTY, merge, Subject, take, tap } from 'rxjs';
import { pageSelection } from 'src/app/core/helpers/models/common.model';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmationDialogComponent } from 'src/app/shared/dialogs/confirmation-dialog/confirmation-dialog.component';
import {
  CountsDetail,
  DataCount,
} from 'src/app/core/helpers/models/attendance.model';
import { HeaderCountName } from 'src/app/core/helpers/constants/common.constant';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { LoginUserData } from 'src/app/core/helpers/models/auth.model';
export interface datasModel {
  name: string;
}

@Component({
  selector: 'app-account-list',
  templateUrl: './account-list.component.html',
  styleUrl: './account-list.component.scss',
})
export class AccountListComponent implements OnInit, AfterViewInit {
  cardData: CountsDetail[] = [
    {
      name: HeaderCountName.Total,
      count: 0,
      icon: 'fa-solid fa-user-plus',
      class: 'bg-info-transparent border border-info',
    },
    {
      name: HeaderCountName.Active,
      count: 0,
      icon: 'fa-solid fa-user-check',
      class: 'bg-success-transparent border border-success',
    },
    {
      name: HeaderCountName.InActive,
      count: 0,
      icon: 'fa-solid fa-user-clock',
      class: 'bg-danger-transparent border border-danger',
    },
    {
      name: HeaderCountName.Location,
      count: 0,
      icon: 'fa-solid fa-location-dot',
      class: 'bg-info-transparent border border-info',
    },
  ];
  accountData!: DataCount;
  pageSize: number = 10;
  totalCount: number = 0;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  columnsToDisplay: string[] = [
    'action',
    'status',
    'companyName',
    'phone1',
    'email',
    'tags',
    // 'ownerName',
    'contact',
  ];
  accountList: companies[] = [];
  displayColumns: string[] = ['footer'];
  apiUrl = environment.apiUrl;
  public routes = routes;
  basicInfoForm!: FormGroup;
  companyAddressForm!: FormGroup;
  socialDetailsForm!: FormGroup;
  accessForm!: FormGroup;
  exportForm!: FormGroup;
  authUser!: LoginUserData;

  activeTab = 'activities';
  activeStep = 0;
  public selectedFieldSet = [0];
  bsValue = new Date();
  bsRangeValue: Date[];
  maxDate = new Date();

  // pagination variables
  public companies = new MatTableDataSource<companies>();
  public lastIndex = 0;
  public totalData = 0;
  public skip = 0;
  public limit: number = this.pageSize;
  public pageIndex = 0;
  public serialNumberArray: Array<number> = [];
  public currentPage = 1;
  public pageNumberArray: Array<number> = [];
  public pageSelection: Array<pageSelection> = [];
  public totalPages = 0;
  public searchDataValue = '';
  //** / pagination variables
  public searchFilter$: Subject<string> = new Subject<string>();
  addOnBlur = true;
  readonly separatorKeysCodes = [ENTER, COMMA] as const;
  data1: datasModel[] = [{ name: 'Promotion' }, { name: 'Rated' }];
  data2: datasModel[] = [{ name: 'Promotion' }, { name: 'Rated' }];

  private accountService = inject(AccountService);
  readonly dialog = inject(MatDialog);

  constructor(private toast: ToasterService) {
    this.maxDate.setDate(this.maxDate.getDate() + 7);
    this.bsRangeValue = [this.bsValue, this.maxDate];
  }

  ngOnInit(): void {
    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);
    this.getTableData();
    this.basicFormInit();
    this.addressFormInit();
    this.socialFormInit();
    this.accessFormInit();
    this.exportFormInit();
    this.fetchAccountCount();
  }

  ngAfterViewInit() {
    this.companies.paginator = this.paginator;
    this.companies.sort = this.sort;
    this.searchFilter$.pipe(debounceTime(1000), distinctUntilChanged()).subscribe((c) => {
          this.searchDataValue = c;
          this.getTableData();
        });
  }

  private basicFormInit(): void {
    this.basicInfoForm = new FormGroup({
      profilePic: new FormControl(''),
      companyName: new FormControl('', Validators.required),
      email: new FormControl('', Validators.required),
      phone1: new FormControl('', Validators.required),
      phone2: new FormControl('', Validators.required),
      fax: new FormControl('', Validators.required),
      website: new FormControl(''),
      reviews: new FormControl('', Validators.required),
      owner: new FormControl('', Validators.required),
      tags: new FormControl('', Validators.required),
      deals: new FormControl('', Validators.required),
      industry: new FormControl('', Validators.required),
      source: new FormControl('', Validators.required),
      contact: new FormControl('', Validators.required),
      currency: new FormControl('', Validators.required),
      language: new FormControl('', Validators.required),
      aboutCompany: new FormControl('', Validators.required),
    });
  }

  private addressFormInit(): void {
    this.companyAddressForm = new FormGroup({
      address: new FormControl('', Validators.required),
      city: new FormControl('', Validators.required),
      state: new FormControl('', Validators.required),
      country: new FormControl('', Validators.required),
      zip: new FormControl('', Validators.required),
    });
  }

  private socialFormInit(): void {
    this.socialDetailsForm = new FormGroup({
      facebook: new FormControl(''),
      twitter: new FormControl(''),
      linkedin: new FormControl(''),
      skype: new FormControl(''),
      whatsapp: new FormControl(''),
      instagram: new FormControl(''),
    });
  }

  private accessFormInit(): void {
    this.accessForm = new FormGroup({
      visibility: new FormControl(''),
      status: new FormControl(''),
    });
  }

  private exportFormInit(): void {
    this.accessForm = new FormGroup({
      fields: new FormControl(''),
      startDate: new FormControl(''),

      endDate: new FormControl(''),
    });
  }

  activateTab(tabName: string) {
    this.activeTab = tabName;
  }
  setActiveStep(step: number) {
    this.activeStep = step;
  }
  currentStep = 0;
  nextStep() {
    this.currentStep++;
  }

  private getTableData(): void {
    const payload = {
      searchQuery:this.searchDataValue,
      pageNumber: 1,
      pageSize: 10,
    };

    this.accountService
      .getAccountList(payload)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((res: any) => {
        if (res && res.message) {
          if (res.statusCode === 200) {
            this.companies.data = res.data.accountList;
            this.totalData = res.data.totalRecords;
          }
        }
      });
  }

  public searchData(value: string): void {
    this.searchFilter$.next(value);
  }

  trackByFn(index: number, item: datasModel) {
    return item.name;
  }

  add(event: MatChipInputEvent, val: datasModel[]): void {
    const value = (event.value || '').trim();
    if (value) {
      val.push({ name: value });
    }
    event.chipInput?.clear();
  }

  remove(values: datasModel[], val: number): void {
    if (val >= 0) {
      values.splice(val, 1);
    }
  }

  edit(val: datasModel[], index: number, event: MatChipEditedEvent) {
    const value = event.value.trim();
    if (!value) {
      this.remove(val, index);
      return;
    }
    if (index >= 0) {
      val[index].name = value;
    }
  }

  public filter = false;
  public rating = false;

  openFilter() {
    this.filter = !this.filter;
  }

  openRating() {
    this.rating = !this.rating;
  }

  elem = document.documentElement;

  fullscreen() {
    if (!document.fullscreenElement) {
      this.elem.requestFullscreen();
    } else {
      document.exitFullscreen();
    }
  }

  openConfirmationDialog(
    status: boolean,
    accountId: string,
    flag: string
  ): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '500px',
      data: {
        title: `${flag} Account`,
        submitBtn: `${flag}`,
        closeBtn: 'Close',
        isDeleted: false,
        flag: 'account',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.updateStatus(status, accountId);
      } else {
        // console.log('Dialog was closed without deleting the department.');
      }
    });
  }

  updateStatus(status: boolean, accountId: string): void {
    this.accountService
      .updateAccountStatus(accountId, status, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((res: any) => {
        if (res && res.message) {
          if (res.statusCode === 200) {
            this.getTableData();
          }
        }
      });
  }

  fetchAccountCount(): void {
    this.accountService
      .accountCount()
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        this.accountData = response?.data;
        if (response?.statusCode < 399) {
          this.cardData.forEach((e: any) => {
            e.count =
              e.name == 'Total'
                ? this.accountData?.total
                : e.name == 'Active'
                ? this.accountData?.active
                : e.name == 'In-Active'
                ? this.accountData?.inActive
                : this.accountData?.location;
          });
        } else {
          this.toast.typeError(response?.message);
        }
      });
  }
}
