import { Component, inject, Input, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { catchError, EMPTY, take } from 'rxjs';
import { routes } from 'src/app/core/core.index';
import { AccountService } from 'src/app/core/services/account/account.service';
import { ConfirmationDialogComponent } from 'src/app/shared/dialogs/confirmation-dialog/confirmation-dialog.component';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { AddTeam, AddTeamMember } from 'src/app/core/helpers/models/team.model';
import { TeamMemberDialogComponent } from '../team-member-dialog/team-member-dialog.component';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { DropdownService } from 'src/app/core/services/dropdown/dropdown.service';
import { Department } from 'src/app/core/helpers/models/department.model';
import { MatPaginator } from '@angular/material/paginator';
import { pageSelection } from 'src/app/core/helpers/models/common.model';
import { LoginUserData } from 'src/app/core/helpers/models/auth.model';

@Component({
  selector: 'app-team-member',
  templateUrl: './team-member.component.html',
  styleUrl: './team-member.component.scss',
})
export class TeamMemberComponent {
  locationId!: string;
  accountId!: string;
  public searchDataValue!: string;
  dataSource!: MatTableDataSource<AddTeamMember>;
  public routes = routes;
  // pagination variables
  public lastIndex = 0;
  public pageSize = 10;
  public totalData = 0;
  public skip = 0;
  public limit: number = this.pageSize;
  public pageIndex = 0;
  public serialNumberArray: Array<number> = [];
  public currentPage = 1;
  public pageNumberArray: Array<number> = [];
  public pageSelection: Array<pageSelection> = [];
  public totalPages = 0;
  departmentList: Department[] = [];
  accountTeams: AddTeam[] = [];
  authUser!: LoginUserData;
  teamId!: string;
  id!: string;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  columnsToDisplay: string[] = [
    'action',
    'teamName',
    'departmentName',
    'totalEmployeeCount',
    'status',
  ];
  teams = new MatTableDataSource<AddTeamMember>();
  displayColumns: string[] = ['footer'];

  private accountService = inject(AccountService);
  readonly dialog = inject(MatDialog);
  private toaster = inject(ToasterService);
  private location = inject(Location);
  private activateRoute = inject(ActivatedRoute);
  private dropdownService = inject(DropdownService);

  constructor() {}

  ngOnInit(): void {
    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);
    this.activateRoute.queryParams.subscribe((params) => {
      const teamId = params['teamId'];
      const accountId = params['accountId'];
      const locationId = params['locationId'];
      if (teamId) {
        this.teamId = teamId;
        this.accountId = accountId;
        this.locationId = locationId;
      }
    });
    this.activateRoute.params.subscribe((params) => {
      const id = params['id'];
      this.id = id;
      this.getAllTeamMembers(this.id);
    });
  }

  private getAllTeamMembers(id: string): void {
    this.accountService
      .getAccountTeamMemberList(id, this.currentPage, this.pageSize)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.teams.data = response.data.accountTeamMemberList;
            this.totalData = response.data.totalRecords;
          }
        }
      });
  }

  // dialog
  addTeam(): void {
    const dialogRef = this.dialog.open(TeamMemberDialogComponent, {
      width: '400px',
      data: {
        title: 'Add Team Members',
        accountId: this.accountId,
        locationId: this.locationId,
        teamId: this.teamId,
        id: this.id,
        submitBtn: 'Submit',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllTeamMembers(this.id);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  editTeam(id: string): void {
    const dialogRef = this.dialog.open(TeamMemberDialogComponent, {
      width: '400px',
      data: {
        title: 'Edit Team Members',
        accountId: this.accountId,
        locationId: this.locationId,
        teamId: this.teamId,
        submitBtn: 'Update',
        closeBtn: 'Close',
        id: id,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllTeamMembers(this.id);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  openDeleteDialog(id: string): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '500px',
      data: {
        title: 'Delete Team Member',
        submitBtn: 'Delete',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.deleteTeam(id);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  deleteTeam(id: string): void {
    this.accountService
      .deleteAccountTeamMemberById(id, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.getAllTeamMembers(this.id);
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }

  goBack(): void {
    this.location.back();
  }

  ngAfterViewInit() {
    this.teams.paginator = this.paginator;
    this.teams.sort = this.sort;
  }
}
