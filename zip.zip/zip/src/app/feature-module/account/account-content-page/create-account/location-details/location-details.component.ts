import { Location } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { catchError, EMPTY, take } from 'rxjs';
import { routes } from 'src/app/core/core.index';
import { AccountConstant } from 'src/app/core/helpers/constants/common.constant';
import { DepartmentContent } from 'src/app/core/helpers/constants/modals.constants';
import {
  AccountDetails,
  LocationModel,
} from 'src/app/core/helpers/models/account.model';
import { LoginUserData } from 'src/app/core/helpers/models/auth.model';
import { Activities } from 'src/app/core/helpers/models/common.model';
import {
  NoteList,
  ProjectDocuments,
} from 'src/app/core/helpers/models/project.model';
import { AccountService } from 'src/app/core/services/account/account.service';
import { ActivityService } from 'src/app/core/services/activity/activity.service';
import { DocumentsService } from 'src/app/core/services/documents/documents.service';
import { NotesService } from 'src/app/core/services/notes/notes.service';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { NotesDialogComponent } from 'src/app/feature-module/employee/projects/notes-dialog/notes-dialog.component';
import { ConfirmationDialogComponent } from 'src/app/shared/dialogs/confirmation-dialog/confirmation-dialog.component';
import { PreviewDialogComponent } from 'src/app/shared/dialogs/preview-dialog/preview-dialog.component';
import { environment } from 'src/environments/environment';
import { AddTeam, AddTeamMember } from 'src/app/core/helpers/models/team.model';
import { TeamDialogComponent } from './team-dialog/team-dialog.component';
import { TeamMemberDialogComponent } from './team-member-dialog/team-member-dialog.component';
import {
  AddDepartment,
  Employee,
} from 'src/app/core/helpers/models/department.model';
import { DepartmentDialogComponent } from './department-dialog/department-dialog.component';
import { AddDesignation } from 'src/app/core/helpers/models/designation.model';
import { DesignationDialogComponent } from './designation-dialog/designation-dialog.component';
import { RoleDialogComponent } from './role-dialog/role-dialog.component';
import { AddRole, Category } from 'src/app/core/helpers/models/role.model';
import { AddCategoryComponent } from './category/add-category/add-category.component';
import { EmployeeService } from 'src/app/feature-module/employee/employees/employee.service';
import { OwlOptions } from 'ngx-owl-carousel-o';
import { DropdownService } from 'src/app/core/services/dropdown/dropdown.service';
import { ClientService } from 'src/app/feature-module/employee/clients/client.service';
import { ClientData } from 'src/app/core/helpers/models/client.model';

@Component({
  selector: 'app-location-details',
  templateUrl: './location-details.component.html',
  styleUrl: './location-details.component.scss',
})
export class LocationDetailsComponent implements OnInit {
  public routes = routes;
  baseImg = 'data:image/jpeg;base64,';
  locationId!: string;
  locationDetails!: LocationModel;
  private location = inject(Location);
  private activateRoute = inject(ActivatedRoute);
  private accountService = inject(AccountService);
  accountId!: string;
  activeTab = 'overview';
  activeIndex: number = 0;

  id!: string;
  base64Image!: string | ArrayBuffer | null;
  accountDetails!: AccountDetails;
  isImageChanged = false;
  authUser!: LoginUserData;
  notesList: NoteList[] = [];
  multipleFiles: File[] = [];
  isSuccess = false;
  projectDocuments: ProjectDocuments[] = [];
  accountActivities: Activities[] = [];
  fileSrc: string[] = [];
  totalRecords!: number;
  isfile: boolean = false;
  teams: AddTeam[] = [];
  teamMembers: AddTeamMember[] = [];
  departments: AddDepartment[] = [];
  designations: AddDesignation[] = [];
  roles: AddRole[] = [];
  category: Category[] = [];
  employeeList: Employee[] = [];
  clientList: ClientData[] = [];

  apiUrl = environment.apiUrl;

  public router = inject(Router);
  private toaster = inject(ToasterService);
  private notesService = inject(NotesService);
  private documentService = inject(DocumentsService);
  private activityService = inject(ActivityService);
  private empService = inject(EmployeeService);
  private clientService = inject(ClientService);
  readonly dialog = inject(MatDialog);

  public companySliderOptions: OwlOptions = {
    loop: true,
    margin: 20,
    nav: true,
    dots: false,
    smartSpeed: 2000,
    autoplay: false,
    navText: [
      '<i class="fa-solid fa-chevron-left"></i>',
      '<i class="fa-solid fa-chevron-right"></i>',
    ],
    responsive: {
      0: {
        items: 1,
      },
      600: {
        items: 1,
      },
      992: {
        items: 1,
      },
      1200: {
        items: 1,
      },
      1400: {
        items: 1,
      },
    },
  };

  constructor() {
    this.activateRoute.params.subscribe((params) => {
      const locationId = params['id'];
      if (locationId) {
        this.locationId = locationId;
        this.getLocationById(this.locationId);
      }
    });
  }
  ngOnInit(): void {
    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);
    this.getAllTeams();
    this.fetchActivities();
  }

  getAllDepartments(): void {
    this.accountService
      .getAccountDepartmentList(this.locationId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.departments = response.data;
          }
        }
      });
  }

  getAllDesignations(): void {
    this.accountService
      .getAccountDesignationList(this.locationId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.designations = response.data;
          }
        }
      });
  }

  getAllTeamMembers(id: string): void {
    this.accountService
      .getAccountTeamMemberList(id, 1, 100)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.teamMembers = response.data.accountTeamMemberList;
          }
        }
      });
  }

  setActiveIndex(index: number): void {
    this.activeIndex = index;
  }

  private getAllTeams(): void {
    this.accountService
      .getAccountTeamList(this.locationId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.teams = response.data;
            this.getAllTeamMembers(this.teams[0].id);
          }
        }
      });
  }

  getAllRoles(): void {
    this.accountService
      .getAccountRoleList(this.locationId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.roles = response.data;
          }
        }
      });
  }

  getAllCategory(): void {
    let param = {
      pageNo: 1,
      pageSize: 100,
      categoryType: 'Parent',
      parentId: '',
    };
    this.accountService
      .getAccountCategoryList(param)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.category = response.data?.masterCategoryList;
          }
        }
      });
  }

  getEmployeeMangerList(locationId: string): void {
    this.empService
      .getEmployeeMangerList(this.accountId, locationId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.employeeList = response.data.map((note: any) => ({
              ...note,
              backgroundColor: this.generateRandomColor(), // Add a random background color
            }));
          }
        }
      });
  }
  private getLocationById(id: string): void {
    this.accountService
      .getAccountLocationById(id)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.locationDetails = response.data;
            this.accountId = this.locationDetails.accountId;
            this.getEmployeeMangerList(this.locationId);
            this.getClientList(this.accountId, this.locationId);
          }
        }
      });
  }

  private getClientList(accountId: string, locationId: string): void {
    this.clientService
      .getClientList('', 1, 50, accountId, locationId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.clientList = response.data.clientList;
          }
        }
      });
  }

  back(): void {
    this.location.back();
  }

  fetchActivities(): void {
    this.activityService
      .getActivityList(this.locationId, AccountConstant.relatedTo, 1, 50)
      .subscribe({
        next: (response) => {
          if (response.statusCode === 200) {
            this.accountActivities = response?.data?.activityHistoryList;
          } else {
            console.error('Failed to fetch lead activities:', response.message);
          }
        },
        error: (error) => {
          console.error('Error fetching lead activities:', error);
        },
      });
  }

  getNotesList(): void {
    this.notesList = [];
    this.notesService
      .getAllNotes(
        this.locationId,
        this.authUser.accountId,
        this.locationDetails.locationId,
        1,
        50
      )
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.notesList = response.data.notesList.map((note: any) => ({
              ...note,
              backgroundColor: this.generateRandomColor(), // Add a random background color
            }));
            this.totalRecords = response.data.totalRecords;
          }
        }
      });
  }

  generateRandomColor(): string {
    const r = Math.floor(Math.random() * 156) + 100;
    const g = Math.floor(Math.random() * 156) + 100;
    const b = Math.floor(Math.random() * 156) + 100;
    return `rgba(${r}, ${g}, ${b})`;
  }

  goBack(): void {
    this.location.back();
  }

  openDeleteNoteDialog(id: string): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '500px',
      data: {
        title: `Delete Note`,
        submitBtn: 'Delete',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.deleteNote(id);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  deleteNote(id: string): void {
    this.notesService
      .deleteNote(id, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.createActivity('deleted', 'DELETE', 'note');
            this.getNotesList();
            this.fetchActivities();
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }

  onFileChange(event: any): void {
    const file = event.target.files[0];
    if (file) {
      const maxSize = 2 * 1024 * 1024;
      if (file.size > maxSize) {
        this.toaster.typeError(
          'File size exceeds the maximum limit of 2MB',
          'Error'
        );
        return;
      }

      const allowedFormats = ['image/jpeg', 'image/png', 'image/jpg'];
      if (!allowedFormats.includes(file.type)) {
        this.toaster.typeError(
          'Invalid file format. Please upload a JPG, JPEG, or PNG file.',
          'Error'
        );
        return;
      }

      const reader = new FileReader();
      reader.onload = () => {
        const base64Data = reader.result;
        this.base64Image = base64Data;
        this.isImageChanged = true;
      };
      reader.readAsDataURL(file);
      this.updateProfileImage(file);
    }
  }

  updateProfileImage(file: File): void {
    const formData = new FormData();
    formData.append('AccountId', this.accountId);
    formData.append('ProfilePicture', file);
    formData.append('UserId', this.authUser.employeeId);
    formData.append('IsImageUpdate', 'true');
    formData.append('FileData', file);

    // API call to update the profile data
    this.accountService
      .UpdateAccountProfile(formData)
      .pipe(take(1))
      .subscribe((res: any) => {
        if (res && res.message) {
          if (res.statusCode === 200) {
            this.toaster.typeSuccess(res?.message, 'Success');
            this.getLocationById(this.locationId);
          } else {
            this.toaster.typeError(res.message, 'Error');
            return;
          }
        }
      });
  }

  createNote(): void {
    const dialogRef = this.dialog.open(NotesDialogComponent, {
      width: '500px',
      disableClose: true,
      data: {
        title: 'Add Note',
        submitBtn: 'Create',
        closeBtn: 'Close',
        relatedToId: this.locationDetails.locationId,
        accountName: this.authUser.accountName,
        accountId: this.accountId,
        locationId: this.locationDetails.locationId,
        locationName: this.locationDetails.locationName,
        activityRelatedToId: this.locationDetails.locationId,
        activityRelatedTo: AccountConstant.relatedTo,
        activityRelatedToName: this.locationDetails.locationName,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.createActivity('Added', 'ADD', 'note');
        this.getNotesList();
        this.fetchActivities();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  onMultipleSelect(files: File[]): void {
    this.multipleFiles = files;

    // Clear previous file sources before adding new ones
    this.fileSrc = [];
    let filesRead = 0;

    // Loop through the selected files and read them
    this.multipleFiles.forEach((file, index) => {
      const reader = new FileReader();

      reader.onload = () => {
        this.fileSrc[index] = reader.result as string;
        filesRead++;

        // Once all files are read, proceed with further processing
        if (filesRead === this.multipleFiles.length) {
          this.isfile = this.fileSrc.length > 0;

          if (this.fileSrc.length > 0) {
            const formData = new FormData();

            // Append files to formData
            this.multipleFiles.forEach((file) => {
              formData.append('Documents', file, file.name);
            });

            formData.append('Id', this.id ? this.id : '');
            formData.append('RelatedToId', this.accountId);
            formData.append('UserId', this.authUser.employeeId);
            formData.append('RelatedTo', AccountConstant.relatedTo);
            formData.append('RelatedToName', AccountConstant.relatedToName);
            formData.append('AccountId', this.authUser.accountId);
            formData.append('LocationId', this.locationDetails.locationId);

            this.documentService
              .saveAndUpdateDocument(formData)
              .pipe(
                catchError((error: any) => {
                  console.error('Error saving documents:', error);
                  return EMPTY; // Gracefully handle error
                }),
                take(1)
              )
              .subscribe((response: any) => {
                if (response && response.message) {
                  if (
                    response.statusCode === 200 ||
                    response.statusCode === 201
                  ) {
                    this.isSuccess = response.data.success;
                    this.createActivity('added', 'ADD', 'Document');
                    this.getDocumentList(); // Update document list
                    this.fetchActivities();
                    this.toaster.typeSuccess(
                      response.data ? response.data.message : response.message,
                      'Success'
                    );
                  } else {
                    this.toaster.typeError(
                      response.data ? response.data.message : response.message,
                      'Error'
                    );
                  }
                }
              });
          }
        }
      };

      reader.onerror = (error) => {
        console.error('Error reading file:', error);
      };

      reader.readAsDataURL(file); // Read the file as data URL
    });
  }

  private getDocumentList(): void {
    this.documentService
      .getDocumentList(
        1,
        50,
        this.accountId,
        this.authUser.accountId,
        this.locationDetails.locationId
      )
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.projectDocuments = response.data.documentList;
          }
        }
      });
  }

  previewDoc(event: { file: ProjectDocuments; flag: string }): any {
    const { file, flag } = event;
    if (flag === 'download') {
      this.documentService
        .getDownloadViewDocumentById(file?.id, flag)
        .pipe(
          catchError((error: any) => {
            return EMPTY;
          }),
          take(1)
        )
        .subscribe((pdfBlob: any) => {
          let receivedData = new Blob([pdfBlob], {
            type: file?.documentExtension,
          });
          const url = window.URL.createObjectURL(receivedData);
          const link = document.createElement('a');

          link.href = url;
          link.download = file?.documentFileName;
          link.click();
          URL.revokeObjectURL(url);
        });
    } else {
      const dialogRef = this.dialog.open(PreviewDialogComponent, {
        width: '90vw',
        height: '90vh',
        disableClose: true,
        data: {
          title: 'Preview',
          file: file,
          submitBtn: DepartmentContent.SUBMIT,
          closeBtn: DepartmentContent.CLOSE,
        },
      });

      dialogRef.afterClosed().subscribe((result) => {
        if (result) {
          // console.log('Department added:', result);
        } else {
          // console.log('Dialog was closed without adding a department.');
        }
      });
    }
  }

  openDeleteDialog(id: string): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '500px',
      disableClose: true,
      data: {
        title: `Delete Document`,
        submitBtn: 'Delete',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.onRemoveMultiple(id);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  onRemoveMultiple(id: string): void {
    this.documentService
      .deleteDocumentById(id, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.createActivity('deleted', 'DELETE', 'Document');
            this.getDocumentList();
            this.fetchActivities();
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
          }
        }
      });
  }

  tabChange(data: string): void {
    this.activeTab = data;
    switch (this.activeTab) {
      case 'notes':
        this.getNotesList();
        break;
      case 'documents':
        this.getDocumentList();
        break;
    }
  }

  createActivity(status: string, action: string, type: string): void {
    let description = `${type} ${status} by ${this.authUser?.employeeName}`;
    let data = {
      activityActionName: action,
      activityStatus: action === 'ADD' ? 'S' : action.charAt(0),
      activityDescription: description,
      activityRelatedToId: this.locationDetails.locationId,
      activityRelatedTo: AccountConstant.relatedTo,
      activityRelatedToName: this.locationDetails.accountName,
      accountId: this.authUser.accountId,
      accountName: this.authUser.accountName,
      locationId: this.locationDetails.locationId,
      locationName: this.locationDetails.locationName,
      userId: this.authUser?.employeeId,
    };
    this.activityService
      .addActivity(data)
      .pipe(
        catchError((error: any) => {
          console.error('Error saving documents:', error);
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((res) => {
        if (res?.statusCode < 399) {
          this.toaster.typeSuccess(res?.message);
        } else {
          this.toaster.typeError(res?.message);
        }
      });
  }

  addTeam(): void {
    const dialogRef = this.dialog.open(TeamDialogComponent, {
      width: '400px',
      disableClose: true,
      data: {
        title: 'Add Team',
        accountId: this.accountId,
        locationId: this.locationId,
        submitBtn: 'Submit',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllTeams();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  editTeam(id: string): void {
    const dialogRef = this.dialog.open(TeamDialogComponent, {
      width: '400px',
      disableClose: true,
      data: {
        title: 'Edit Team',
        accountId: this.accountId,
        locationId: this.locationId,
        submitBtn: 'Update',
        closeBtn: 'Close',
        id: id,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllTeams();
        this.activeIndex = 0;
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  openTeamDeleteDialog(id: string, name: string): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '500px',
      disableClose: true,
      data: {
        title: `Delete ${name} Team`,
        submitBtn: 'Delete',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.deleteTeam(id);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  deleteTeam(id: string): void {
    this.accountService
      .deleteAccountTeamById(id, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.getAllTeams();
            this.activeIndex = 0;
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }

  editTeamMember(data: AddTeamMember, teamId: string): void {
    const dialogRef = this.dialog.open(TeamMemberDialogComponent, {
      width: '400px',
      disableClose: true,
      data: {
        title: 'Edit Team Members',
        accountId: data.accountId,
        locationId: data.locationId,
        teamId: data.teamId,
        submitBtn: 'Update',
        closeBtn: 'Close',
        id: data.teamMemberId,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllTeamMembers(teamId);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  openMemberDeleteDialog(id: string, teamId: string): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '500px',
      disableClose: true,
      data: {
        title: 'Delete Team Member',
        submitBtn: 'Delete',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.deleteTeamMember(id, teamId);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  deleteTeamMember(id: string, teamId: string): void {
    this.accountService
      .deleteAccountTeamMemberById(id, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.getAllTeamMembers(teamId);
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }

  addTeamMember(data: AddTeam): void {
    const dialogRef = this.dialog.open(TeamMemberDialogComponent, {
      width: '400px',
      disableClose: true,
      data: {
        title: 'Add Team Members',
        accountId: this.accountId,
        locationId: this.locationId,
        teamId: data.teamId,
        id: data.id,
        submitBtn: 'Submit',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllTeamMembers(data.id);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  addDepartment(): void {
    const dialogRef = this.dialog.open(DepartmentDialogComponent, {
      width: '400px',
      disableClose: true,
      data: {
        title: 'Add Department',
        accountId: this.accountId,
        locationId: this.locationId,
        submitBtn: 'Submit',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllDepartments();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  editDepartment(id: string): void {
    const dialogRef = this.dialog.open(DepartmentDialogComponent, {
      width: '400px',
      disableClose: true,
      data: {
        title: 'Edit Department',
        accountId: this.accountId,
        locationId: this.locationId,
        submitBtn: 'Update',
        closeBtn: 'Close',
        id: id,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllDepartments();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  openDepartmentDeleteDialog(id: string): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '500px',
      disableClose: true,
      data: {
        title: 'Delete Department',
        submitBtn: 'Delete',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.deleteDepartment(id);
      } else {
        // console.log('Dialog was closed without deleting the department.');
      }
    });
  }

  deleteDepartment(id: string): void {
    this.accountService
      .deleteAccountDepartmentById(id, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.getAllDepartments();
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }

  addDesignation(): void {
    const dialogRef = this.dialog.open(DesignationDialogComponent, {
      width: '400px',
      disableClose: true,
      data: {
        title: 'Add Designation',
        accountId: this.accountId,
        locationId: this.locationId,
        submitBtn: 'Submit',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllDesignations();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  editDesignation(id: string): void {
    const dialogRef = this.dialog.open(DesignationDialogComponent, {
      width: '400px',
      disableClose: true,
      data: {
        title: 'Edit Designation',
        accountId: this.accountId,
        locationId: this.locationId,
        submitBtn: 'Update',
        closeBtn: 'Close',
        id: id,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllDesignations();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  openDesignationDeleteDialog(id: string): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '500px',
      data: {
        title: 'Delete Designation',
        submitBtn: 'Delete',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.deleteDesignation(id);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  deleteDesignation(id: string): void {
    this.accountService
      .deleteAccountDesignationById(id, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.getAllDesignations();
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }
  addRole(): void {
    const dialogRef = this.dialog.open(RoleDialogComponent, {
      width: '400px',
      disableClose: true,
      data: {
        title: 'Add Role',
        accountId: this.accountId,
        locationId: this.locationId,
        submitBtn: 'Submit',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllRoles();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  editRole(id: string): void {
    const dialogRef = this.dialog.open(RoleDialogComponent, {
      width: '400px',
      disableClose: true,
      data: {
        title: 'Edit Role',
        accountId: this.accountId,
        locationId: this.locationId,
        submitBtn: 'Update',
        closeBtn: 'Close',
        id: id,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllRoles();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  openRoleDeleteDialog(id: string): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '500px',
      disableClose: true,
      data: {
        title: 'Delete Role',
        submitBtn: 'Delete',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.deleteRole(id);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  deleteRole(id: string): void {
    this.accountService
      .deleteAccountRoleById(id, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.getAllRoles();
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }

  addCategory(): void {
    const dialogRef = this.dialog.open(AddCategoryComponent, {
      width: '400px',
      disableClose: true,
      data: {
        title: 'Add Category',
        accountId: this.accountId,
        locationId: this.locationId,
        submitBtn: 'Submit',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllCategory();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  editCategory(id: string): void {
    const dialogRef = this.dialog.open(AddCategoryComponent, {
      width: '400px',
      disableClose: true,
      data: {
        title: 'Edit Category',
        accountId: this.accountId,
        locationId: this.locationId,
        submitBtn: 'Update',
        closeBtn: 'Close',
        id: id,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllCategory();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  openCategoryDeleteDialog(id: string): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '500px',
      disableClose: true,
      data: {
        title: 'Delete Category',
        submitBtn: 'Delete',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.deleteCategory(id);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  deleteCategory(id: string): void {
    this.accountService
      .deleteAccountCategoryById(id, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.getAllCategory();
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }

  editLocation(locationId: string): void {}
}
