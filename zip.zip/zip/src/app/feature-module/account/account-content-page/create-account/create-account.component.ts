import { LiveAnnouncer } from '@angular/cdk/a11y';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import {
  AfterViewInit,
  Component,
  EventEmitter,
  inject,
  Input,
  OnInit,
  Output,
  signal,
  ViewChild,
} from '@angular/core';
import {
  AbstractControl,
  FormArray,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatChipInputEvent } from '@angular/material/chips';
import { MatDialog } from '@angular/material/dialog';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { EMPTY, map, Observable, startWith, take } from 'rxjs';
import { catchError } from 'rxjs/internal/operators/catchError';
import { routes } from 'src/app/core/core.index';
import {
  AccountDropDown,
  LocationModel,
  SocialDropdown,
  SocialProfiles,
} from 'src/app/core/helpers/models/account.model';
import {
  CityModel,
  CountryModel,
  pageSelection,
  StateModel,
} from 'src/app/core/helpers/models/common.model';
import { AccountService } from 'src/app/core/services/account/account.service';
import { CommonService } from 'src/app/core/services/common/common.service';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { environment } from 'src/environments/environment';
import { LocationDialogComponent } from './location-dialog/location-dialog.component';
import { ConfirmationDialogComponent } from 'src/app/shared/dialogs/confirmation-dialog/confirmation-dialog.component';
import { MatPaginator } from '@angular/material/paginator';
import { DropdownService } from 'src/app/core/services/dropdown/dropdown.service';
import { UrlValidator } from 'src/app/core/helpers/constants/pattern.constant';
import { Location } from '@angular/common';
import { LoginUserData } from 'src/app/core/helpers/models/auth.model';

export interface DatasModel {
  name: string;
}

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.scss'],
})
export class CreateAccountComponent implements OnInit, AfterViewInit {
  @Input() adressType!: string;
  @Output() setAddress: EventEmitter<any> = new EventEmitter();
  accounts: AccountDropDown[] = [];
  authUser!: LoginUserData;
  queryWait!: boolean;
  public routes = routes;
  apiUrl = environment.apiUrl;
  isImageChanged = false;
  isEdit = false;
  currentStep = 0;
  activeStep = 0;
  activeTab = 'activities';
  public selectedFieldSet = [0];
  base64Image!: string | ArrayBuffer | null;
  imgUrl!: string | ArrayBuffer | null;

  basicInfoForm!: FormGroup;
  companyAddressForm!: FormGroup;
  multiLocationForm!: FormGroup;
  socialDetailsForm!: FormGroup;
  accessForm!: FormGroup;
  licenseForm!: FormGroup;
  addOnBlur = true;
  isSubmitted: boolean = false;
  isAddressSubmitted: boolean = false;
  isSocialSubmitted: boolean = false;
  isAccessSubmitted: boolean = false;
  isLicenseSubmitted: boolean = false;

  public lastIndex = 0;
  public pageSize = 10;
  public totalData = 0;
  public skip = 0;
  public limit: number = this.pageSize;
  public pageIndex = 0;
  public currentPage = 1;
  public pageNumberArray: Array<number> = [];
  public serialNumberArray: Array<number> = [];
  public pageSelection: Array<pageSelection> = [];
  public totalPages = 0;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  columnsToDisplay: string[] = [
    'action',
    'locationName',
    'shortName',
    'country',
    'street',
    'state',
    'city',
    'zipCode',
  ];

  socialLinks: SocialDropdown[] = [];
  countries: CountryModel[] = [];

  filteredCountries!: Observable<CountryModel[]>;
  filteredStates!: Observable<StateModel[]>;
  filteredCities!: Observable<CityModel[]>;
  states: StateModel[] = [];
  cities: CityModel[] = [];
  countryId!: number;
  stateId!: number;
  cityId!: number;
  accountLocations = new MatTableDataSource<LocationModel>();
  displayColumns: string[] = ['footer'];

  accountId = '';
  responseImg = '';
  addressId = '';
  accountName = '';
  socialInfo: SocialProfiles[] = [];
  accessId = '';
  licenseId = '';

  readonly separatorKeysCodes: number[] = [ENTER, COMMA];
  readonly keywords = signal<string[]>([]);

  readonly announcer = inject(LiveAnnouncer);
  private accountService = inject(AccountService);
  private toaster = inject(ToasterService);
  public commonService = inject(CommonService);
  public dropdownService = inject(DropdownService);
  private activateRoute = inject(ActivatedRoute);
  private location = inject(Location);
  private router = inject(Router);
  readonly dialog = inject(MatDialog);

  ngOnInit(): void {
    this.activateRoute.params.subscribe((params) => {
      const accountId = params['id'];
      if (accountId) {
        localStorage.setItem('accountId', accountId);
        this.isEdit = true;
        this.accountId = accountId;
      } else {
        localStorage.removeItem('accountId');
        localStorage.removeItem('accountName');
      }
    });

    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);

    const accountId = localStorage.getItem('accountId');
    if (accountId) this.accountId = accountId;

    const accountName = localStorage.getItem('accountName');
    if (accountName) this.accountName = accountName;

    if (this.accountId && this.isEdit) {
      this.getAccountDetails(this.accountId);
      this.getLocationList();
    }

    this.getCountries();
    this.basicFormInit();
    this.addressFormInit();
    this.socialFormInit();
    // this.accessFormInit();
    this.licenseFormInit();
    this.getAccountList();
    this.getSocialList();
    this.onCountryFocus();
    this.onStateFocus();
    this.onCityFocus();
  }

  ngAfterViewInit(): void {
    this.accountLocations.paginator = this.paginator;
    this.accountLocations.sort = this.sort;
  }

  onCountryFocus(): void {
    this.filteredCountries = this.d['country']?.valueChanges.pipe(
      startWith(''),
      map((value) => this._countryFilter(value ? value : ''))
    );
  }

  onStateFocus(): void {
    this.filteredStates = this.d['state']?.valueChanges.pipe(
      startWith(''),
      map((value) => this._stateFilter(value ? value : ''))
    );
  }

  onCityFocus(): void {
    this.filteredCities = this.d['city']?.valueChanges.pipe(
      startWith(''),
      map((value) => this._cityFilter(value ? value : ''))
    );
  }

  private getCountries(): void {
    this.dropdownService
      .getCountriesDropdownList()
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response) {
          this.countries = response.data;
        }
      });
  }

  private _countryFilter(value: string): CountryModel[] {
    const filterValue = value ? value.toLowerCase() : '';
    return this.countries.filter((option) =>
      option.countryName.toLowerCase().includes(filterValue)
    );
  }

  private _stateFilter(value: string): StateModel[] {
    const filterValue = value ? value.toLowerCase() : '';
    return this.states.filter((option) =>
      option.stateName.toLowerCase().includes(filterValue)
    );
  }

  private _cityFilter(value: string): CityModel[] {
    const filterValue = value ? value.toLowerCase() : '';
    return this.cities.filter((option) =>
      option.cityName.toLowerCase().includes(filterValue)
    );
  }

  onCountrySelected(value: string): void {
    const selectedCountry = value;
    const item = this.countries.find(
      (option) => option.countryName === selectedCountry
    );
    if (item) {
      this.countryId = item.countryId;
      this.getStates(this.countryId);
    }
  }

  onStateSelected(value: string): void {
    const selectedState = value;
    const item = this.states.find(
      (option) => option.stateName === selectedState
    );
    if (item) {
      this.stateId = item.stateId;
      this.getCities(this.stateId);
    }
  }

  onCitySelected(value: string): void {
    const selectedCity = value;
    const item = this.cities.find((option) => option.cityName === selectedCity);
    if (item) {
      this.cityId = item.cityId;
    }
  }

  getStates(countryId: number): void {
    this.dropdownService
      .getStatesDropdownList(countryId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response) {
          this.states = response.data;
        }
      });
  }

  getCities(stateId: number): void {
    this.dropdownService
      .getCitiesDropdownList(stateId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response) {
          this.cities = response.data;
        }
      });
  }

  private getSocialList(): void {
    this.socialLinks = [];

    this.dropdownService
      .getSocialLinksDropdownList()
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response) {
          this.socialLinks = response.data;
        }
      });
  }

  private getAccountList(): void {
    this.accounts = [];

    this.dropdownService
      .getAccountList()
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response) {
          this.accounts = response.data;
        }
      });
  }

  private getAccountDetails(id: string): void {
    this.accountService
      .getAccountDetailById(id)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            if (response.data.accountBasicInfoList[0]?.fileData) {
              this.base64Image = `data:image/jpeg;base64,${response.data.accountBasicInfoList[0]?.fileData}`;
            } else {
              this.base64Image = 'assets/img/profiles/avatar-2.jpg';
            }

            this.keywords.update((keywords) => {
              const newTags = response.data.accountBasicInfoList[0]?.tags || '';
              const tagsArray = newTags
                .split(',')
                .map((tag: string) => tag.trim())
                .filter((tag: string) => tag);

              return [...keywords, ...tagsArray];
            });

            if (response.data.accountBasicInfoList.length > 0) {
              this.accountName =
                response.data.accountBasicInfoList[0]?.companyName;

              this.basicInfoForm.patchValue({
                profilePic: '',
                companyName: response.data.accountBasicInfoList[0]?.companyName,
                email: response.data.accountBasicInfoList[0]?.email,
                phone1: response.data.accountBasicInfoList[0]?.phone1,
                phone2: response.data.accountBasicInfoList[0]?.phone2,
                fax: response.data.accountBasicInfoList[0]?.fax,
                website: response.data.accountBasicInfoList[0]?.website,
                owner: response.data.accountBasicInfoList[0]?.ownerName,
                tags: response.data.accountBasicInfoList[0]?.tags,
                aboutCompany:
                  response.data.accountBasicInfoList[0]?.aboutCompany,
              });
            }

            if (response.data.accountAddressInfoList.length > 0) {
              this.addressId = response.data.accountAddressInfoList
                ? response.data.accountAddressInfoList[0].addressId
                : '';

              this.countryId =
                response.data.accountAddressInfoList[0].countryId;
              this.stateId = response.data.accountAddressInfoList[0].stateId;
              this.cityId = response.data.accountAddressInfoList[0].cityId;

              this.companyAddressForm.patchValue({
                address: response.data.accountAddressInfoList[0].streetAddress,
                city: response.data.accountAddressInfoList[0].cityName,
                state: response.data.accountAddressInfoList[0].stateName,
                country: response.data.accountAddressInfoList[0].countryName,
                zip: response.data.accountAddressInfoList[0].zipCode,
              });
              this.getStates(this.countryId);
              this.getCities(this.stateId);
            }

            if (response.data.accountLocationList.length > 0) {
              this.multiLocationForm = new FormGroup({
                locations: new FormArray(
                  response.data.accountLocationList.map((location: any) =>
                    this.initLocationForm(location)
                  )
                ),
              });
            }

            if (response.data.accountSocialInfoList.length > 0) {
              this.socialInfo = response.data.accountSocialInfoList
                ? response.data.accountSocialInfoList
                : [];
              this.socialDetailsForm = new FormGroup({
                socialMediaArray: new FormArray(
                  response.data.accountSocialInfoList.length > 0
                    ? response.data.accountSocialInfoList.map((social: any) =>
                        this.addSocialMedia(social)
                      )
                    : [this.addSocialMedia()]
                ),
              });
            }

            // if (response.data.accountAccessList.length > 0) {
            //   this.accessId = response.data.accountAccessList
            //     ? response.data.accountAccessList[0].accessId
            //     : '';

            //   this.accessForm.patchValue({
            //     visibility: response.data.accountAccessList[0].visibility,
            //     status: response.data.accountAccessList[0].status,
            //     accountId: response.data.accountAccessList[0].accountId,
            //     accessId: response.data.accountAccessList[0].accessId,
            //   });
            // }

            if (response.data.accountLicensePlanList.length > 0) {
              this.licenseId = response.data.accountLicensePlanList
                ? response.data.accountLicensePlanList[0].licenseId
                : '';
              this.licenseForm.patchValue({
                users: response.data.accountLicensePlanList[0].noOfUser,
                startDate: new Date(
                  response.data.accountLicensePlanList[0].licenseStartDate
                ),
                endDate: new Date(
                  response.data.accountLicensePlanList[0].licenseEndDate
                ),
                licenseType:
                  response.data.accountLicensePlanList[0].licenseType,
                projects: response.data.accountLicensePlanList[0].noOfProject,
              });
            }
          } else {
            this.toaster.typeError(response.message, 'Error');
            return;
          }
        }
      });
  }

  private getLocationList(): void {
    this.accountService
      .getAccountLocationList(this.accountId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.accountLocations.data = response.data;
            this.totalData = response.data.length;
          }
        }
      });
  }

  // Initialize the basic info form
  private basicFormInit(): void {
    this.basicInfoForm = new FormGroup({
      profilePic: new FormControl(''),
      companyName: new FormControl('', [
        Validators.required,
        Validators.minLength(5),
      ]),
      email: new FormControl('', [Validators.required, Validators.email]),
      phone1: new FormControl('', [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(15),
      ]),
      phone2: new FormControl('', [
        Validators.minLength(10),
        Validators.maxLength(15),
      ]),
      fax: new FormControl('', Validators.required),
      website: new FormControl(''),
      owner: new FormControl(''),
      tags: new FormControl([], Validators.required),
      aboutCompany: new FormControl('', [
        Validators.required,
        Validators.minLength(50),
        Validators.maxLength(100),
      ]),
    });
  }

  get c(): { [key: string]: AbstractControl } {
    return this.basicInfoForm.controls;
  }

  // Initialize the address form
  private addressFormInit(): void {
    this.companyAddressForm = new FormGroup({
      address: new FormControl('', [
        Validators.required,
        Validators.minLength(25),
      ]),
      city: new FormControl('', Validators.required),
      state: new FormControl('', Validators.required),
      country: new FormControl('', Validators.required),
      zip: new FormControl('', Validators.required),
    });
  }

  get d(): { [key: string]: AbstractControl } {
    return this.companyAddressForm.controls;
  }

  // Initialize the social details form
  addSocialMedia(social?: any): FormGroup {
    return new FormGroup({
      socialInfoName: new FormControl(social ? social.socialInfoName : '', [
        Validators.required,
      ]),
      socialInfoLink: new FormControl(social ? social.socialInfoLink : '', [
        Validators.required,
        UrlValidator.validate(),
      ]),
      accountId: new FormControl(this.accountId),
      socialInfoId: new FormControl(social ? social.socialInfoId : ''),
      userId: new FormControl(this.authUser.employeeId),
    });
  }

  isSocialMediaSelected(value: string): boolean {
    return this.socialMediaArray.controls.some(
      (control) => control.value.socialInfoName === value
    );
  }

  getSocialMediaControl(index: number): { [key: string]: AbstractControl } {
    const socialMediaGroup = this.socialMediaArray.at(index) as FormGroup;
    return socialMediaGroup.controls;
  }

  private socialFormInit(): void {
    this.socialDetailsForm = new FormGroup({
      socialMediaArray: new FormArray([this.addSocialMedia()]),
    });
  }

  addSocial(): void {
    this.socialMediaArray.push(this.addSocialMedia());
  }

  removeSocial(id: string, index: number): void {
    if (id) {
      const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        width: '500px',
        data: {
          title: 'Delete Social Link',
          submitBtn: 'Delete',
          closeBtn: 'Close',
        },
      });

      dialogRef.afterClosed().subscribe((result) => {
        if (result) {
          this.deleteSocial(id);
        } else {
          // console.log('Dialog was closed without adding a department.');
        }
      });
    } else {
      if (index !== -1) {
        this.socialMediaArray.removeAt(index);
      }
    }
  }

  deleteSocial(id: string): void {
    this.accountService
      .deleteAccountSocialInfoById(id, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.getAccountDetails(this.accountId);
            this.toaster.typeSuccess(response.message, 'Success');
          } else {
            this.toaster.typeError(response.message, 'Error');
            return;
          }
        }
      });
  }

  get socialMediaArray(): FormArray {
    return this.socialDetailsForm.get('socialMediaArray') as FormArray;
  }

  // Initialize the access form
  // private accessFormInit(): void {
  //   this.accessForm = new FormGroup({
  //     visibility: new FormControl('public', Validators.required),
  //     status: new FormControl(true, Validators.required),
  //     accountId: new FormControl(this.accountId ? this.accountId : ''),
  //     accessId: new FormControl(this.accessId ? this.accessId : ''),
  //   });
  // }

  // get a(): { [key: string]: AbstractControl } {
  //   return this.accessForm.controls;
  // }

  // Initialize the export form
  private licenseFormInit(): void {
    this.licenseForm = new FormGroup({
      users: new FormControl('', Validators.required),
      startDate: new FormControl('', Validators.required),
      endDate: new FormControl('', Validators.required),
      licenseType: new FormControl('', Validators.required),
      projects: new FormControl('', Validators.required),
    });
  }

  get l(): { [key: string]: AbstractControl } {
    return this.licenseForm.controls;
  }

  // Method to add a new location
  addLocation(): void {
    const dialogRef = this.dialog.open(LocationDialogComponent, {
      width: '600px',
      data: {
        title: 'Add Location',
        accountId: this.accountId,
        accountName: this.accountName,
        submitBtn: 'Submit',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getLocationList();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  editLocation(id: string): void {
    const dialogRef = this.dialog.open(LocationDialogComponent, {
      width: '600px',
      data: {
        title: 'Edit Location',
        accountId: this.accountId,
        accountName: this.accountName,
        submitBtn: 'Update',
        closeBtn: 'Close',
        id: id,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getLocationList();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  initLocationForm(location?: any): FormGroup {
    return new FormGroup({
      country: new FormControl(
        location ? location.country : '',
        Validators.required
      ),
      locationName: new FormControl(
        location ? location.locationName : '',
        Validators.required
      ),
      shortName: new FormControl(
        location ? location.shortName : '',
        Validators.required
      ),
      city: new FormControl(location ? location.city : '', Validators.required),
      state: new FormControl(
        location ? location.state : '',
        Validators.required
      ),
      street: new FormControl(
        location ? location.street : '',
        Validators.required
      ),
      zipCode: new FormControl(
        location ? location.zipCode : '',
        Validators.required
      ),
      locationId: new FormControl(location ? location.locationId : ''),
    });
  }

  openDeleteDialog(id: string): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '500px',
      data: {
        title: 'Delete Location',
        submitBtn: 'Delete',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.deleteLocation(id);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  deleteLocation(id: string): void {
    this.accountService
      .deleteAccountLocationById(id, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.getLocationList();
            this.toaster.typeSuccess(response.message, 'Success');
          } else {
            this.toaster.typeError(response.message, 'Error');
            return;
          }
        }
      });
  }

  activateTab(tabName: string) {
    this.activeTab = tabName;
  }

  setActiveStep(step: number) {
    this.activeStep = step;
  }

  getAccountName(id: string): void {
    const account = this.accounts.find((x) => x.accountId === id);
    this.accountName = account ? account.accountName : '';
  }

  goBack(): void {
    if (this.selectedFieldSet[0] === 0 && this.currentStep === 0) {
      this.location.back();
    } else {
      this.selectedFieldSet[0] = this.currentStep - 1;
      this.currentStep = this.currentStep - 1;
    }
  }

  nextStep(flag: number) {
    switch (flag) {
      case 0:
        this.isSubmitted = true;
        if (this.basicInfoForm.invalid) {
          return;
        }
        const basicPayload = {
          accountId: this.accountId ? this.accountId : '',
          companyName: this.basicInfoForm.value.companyName,
          email: this.basicInfoForm.value.email,
          phone1: this.basicInfoForm.value.phone1,
          phone2: this.basicInfoForm.value.phone2,
          fax: this.basicInfoForm.value.fax,
          website: this.basicInfoForm.value.website,
          ownerName: this.authUser.accountId,
          tags: Array.isArray(this.basicInfoForm.value.tags)
            ? this.basicInfoForm.value.tags.join(', ')
            : this.basicInfoForm.value.tags,
          aboutCompany: this.basicInfoForm.value.aboutCompany,
          userId: this.authUser.employeeId,
        };
        if (this.isEdit) {
          this.accountService
            .updateBasicDetails(basicPayload)
            .pipe(
              catchError((error: any) => {
                return EMPTY;
              }),
              take(1)
            )
            .subscribe((response: any) => {
              if (response && response.message) {
                if (response.statusCode === 200) {
                  this.selectedFieldSet[0] = 1;
                  this.toaster.typeSuccess(response.message, 'Success');
                  this.currentStep++;
                } else {
                  this.toaster.typeError(response.message, 'Error');
                  return;
                }
              }
            });
        } else {
          this.accountService
            .addBasicDetails(basicPayload)
            .pipe(
              catchError((error: any) => {
                return EMPTY;
              }),
              take(1)
            )
            .subscribe((response: any) => {
              if (response && response.message) {
                if (
                  response.statusCode === 200 ||
                  response.statusCode === 201
                ) {
                  this.selectedFieldSet[0] = 1;
                  this.accountId = response.data.accountId;
                  this.accountName = response.data.accountName;
                  localStorage.setItem('accountId', this.accountId);
                  localStorage.setItem('accountName', this.accountName);
                  this.toaster.typeSuccess(response.message, 'Success');
                  this.currentStep++;
                } else {
                  this.toaster.typeError(response.message, 'Error');
                  return;
                }
              }
            });
        }
        break;

      case 1:
        this.isAddressSubmitted = true;
        if (this.companyAddressForm.invalid) {
          return;
        }
        const addressPayload = {
          streetAddress: this.companyAddressForm.value.address,
          cityName: this.companyAddressForm.value.city,
          stateName: this.companyAddressForm.value.state,
          countryName: this.companyAddressForm.value.country,
          zipCode: this.companyAddressForm.value.zip,
          addressId: this.addressId ? this.addressId : '',
          accountId: this.accountId ? this.accountId : '',
          countryId: this.countryId,
          stateId: this.stateId,
          cityId: this.cityId,
          userId: this.authUser.employeeId,
        };

        if (this.isEdit && this.addressId) {
          this.accountService
            .updateAddressDetails(addressPayload)
            .pipe(
              catchError((error: any) => {
                return EMPTY;
              }),
              take(1)
            )
            .subscribe((response: any) => {
              if (response && response.message) {
                if (response.statusCode === 200) {
                  this.selectedFieldSet[0] = 2;
                  const accountId = localStorage.getItem('accountId');
                  if (accountId) this.accountId = accountId;
                  this.toaster.typeSuccess(response?.message, 'Success');
                  this.currentStep++;
                } else {
                  this.toaster.typeError(response.message, 'Error');
                  return;
                }
              }
            });
        } else {
          this.accountService
            .addAddressDetails(addressPayload)
            .pipe(
              catchError((error: any) => {
                return EMPTY;
              }),
              take(1)
            )
            .subscribe((response: any) => {
              if (response && response.message) {
                if (response.statusCode === 200) {
                  this.selectedFieldSet[0] = 2;
                  this.toaster.typeSuccess(response?.message, 'Success');
                  this.currentStep++;
                } else {
                  this.toaster.typeError(response.message, 'Error');
                  return;
                }
              }
            });
        }

        break;

      case 2:
        this.selectedFieldSet[0] = 3;
        this.currentStep++;
        break;

      case 3:
        this.isSocialSubmitted = true;

        if (this.socialDetailsForm.invalid) {
          return;
        }

        if (this.isEdit && this.socialInfo.length > 0) {
          this.accountService
            .updateSocialDetails(this.socialDetailsForm.value.socialMediaArray)
            .pipe(
              catchError((error: any) => {
                return EMPTY;
              }),
              take(1)
            )
            .subscribe((response: any) => {
              if (
                response?.successMessage[0].statusCode === 200 ||
                response?.successMessage[0].statusCode === 201
              ) {
                this.toaster.typeSuccess(response?.message, 'Success');
                this.selectedFieldSet[0] = 4;
                this.currentStep++;
              } else {
                this.toaster.typeError(response.message, 'Error');
                return;
              }
            });
        } else {
          this.accountService
            .addSocialDetails(this.socialDetailsForm.value.socialMediaArray)
            .pipe(
              catchError((error: any) => {
                return EMPTY;
              }),
              take(1)
            )
            .subscribe((response: any) => {
              if (
                response?.successMessage[0].statusCode === 200 ||
                response?.successMessage[0].statusCode === 201
              ) {
                this.toaster.typeSuccess(response?.message, 'Success');
                this.selectedFieldSet[0] = 4;
                this.currentStep++;
              } else {
                this.toaster.typeError(response.message, 'Error');
                return;
              }
            });
        }
        break;

      // case 4:
      //   this.isAccessSubmitted = true;

      //   if (this.accessForm.invalid) {
      //     return;
      //   }

      //   if (this.isEdit && this.accessId) {
      //     this.accountService
      //       .updateAccessDetails(this.accessForm.value)
      //       .pipe(
      //         catchError((error: any) => {
      //           return EMPTY;
      //         }),
      //         take(1)
      //       )
      //       .subscribe((response: any) => {
      //         if (response && response.message) {
      //           if (response.statusCode === 200) {
      //             this.toaster.typeSuccess(response?.message, 'Success');
      //             this.selectedFieldSet[0] = 5;
      //             this.currentStep++;
      //           } else {
      //             this.toaster.typeError(response.message, 'Error');
      //             return;
      //           }
      //         }
      //       });
      //   } else {
      //     this.accountService
      //       .addAccessDetails(this.accessForm.value)
      //       .pipe(
      //         catchError((error: any) => {
      //           return EMPTY;
      //         }),
      //         take(1)
      //       )
      //       .subscribe((response: any) => {
      //         if (response && response.message) {
      //           if (response.statusCode === 200) {
      //             this.toaster.typeSuccess(response?.message, 'Success');
      //             this.selectedFieldSet[0] = 5;
      //             this.currentStep++;
      //           } else {
      //             this.toaster.typeError(response.message, 'Error');
      //             return;
      //           }
      //         }
      //       });
      //   }
      //   break;

      case 4:
        this.isLicenseSubmitted = true;

        if (this.licenseForm.invalid) {
          return;
        }

        const payload = {
          licenseId: this.licenseId ? this.licenseId : '',
          accountId: this.accountId ? this.accountId : '',
          licenseType: this.licenseForm.value.licenseType,
          licenseStartDate: this.licenseForm.value.startDate,
          licenseEndDate: this.licenseForm.value.endDate,
          noOfUser: Number(this.licenseForm.value.users),
          noOfProject: Number(this.licenseForm.value.projects),
          userId: this.authUser.employeeId,
        };

        this.accountService
          .addLicenseDetails(payload)
          .pipe(
            catchError((error: any) => {
              return EMPTY;
            }),
            take(1)
          )
          .subscribe((response: any) => {
            if (response && response.message) {
              if (response.data.success && response.statusCode === 200) {
                localStorage.removeItem('accountId');
                localStorage.removeItem('accountName');
                this.toaster.typeSuccess(
                  response.data ? response.data.message : response.message,
                  'Success'
                );
                this.router.navigate(['/admin/accounts/account-list']);
              } else {
                this.toaster.typeError(
                  response.data ? response.data.message : response.message,
                  'Error'
                );
                return;
              }
            }
          });
        break;
    }
  }

  onFileChange(event: any): void {
    const file = event.target.files[0];
    if (file) {
      const maxSize = 2 * 1024 * 1024;
      if (file.size > maxSize) {
        this.toaster.typeError(
          'File size exceeds the maximum limit of 2MB',
          'Error'
        );
        return;
      }

      const allowedFormats = ['image/jpeg', 'image/png', 'image/jpg'];
      if (!allowedFormats.includes(file.type)) {
        this.toaster.typeError(
          'Invalid file format. Please upload a JPG, JPEG, or PNG file.',
          'Error'
        );
        return;
      }

      const reader = new FileReader();
      reader.onload = () => {
        const base64Data = reader.result;
        this.base64Image = base64Data;
        this.isImageChanged = true;
      };
      reader.readAsDataURL(file);
      this.updateProfileImage(file);
    }
  }

  updateProfileImage(file: File): void {
    const formData = new FormData();
    formData.append('AccountId', this.accountId);
    formData.append('ProfilePicture', file);
    formData.append('UserId', this.authUser.employeeId);
    formData.append('IsImageUpdate', 'true');
    formData.append('FileData', file);

    // API call to update the profile data
    this.accountService
      .UpdateAccountProfile(formData)
      .pipe(take(1))
      .subscribe((res: any) => {
        if (res && res.message) {
          if (res.statusCode === 200) {
            this.toaster.typeSuccess(res?.message, 'Success');
            this.getAccountDetails(this.accountId);
          } else {
            this.toaster.typeError(res.message, 'Error');
            return;
          }
        }
      });
  }

  resetImage(): void {
    this.basicInfoForm.get('profilePic')?.setValue('');
    this.base64Image = null;
  }

  // Methods for managing chips (tags)
  trackByFn(index: number, item: DatasModel) {
    return item.name;
  }

  removeKeyword(keyword: string) {
    this.keywords.update((keywords) => {
      const index = keywords.indexOf(keyword);
      if (index < 0) {
        return keywords;
      }

      keywords.splice(index, 1);
      this.announcer.announce(`removed ${keyword}`);
      return [...keywords];
    });
  }

  add(event: MatChipInputEvent): void {
    const value = (event.value || '').trim();

    // Add our keyword
    if (value) {
      this.keywords.update((keywords) => [...keywords, value]);
    }

    // Clear the input value
    event.chipInput!.clear();
  }
}
