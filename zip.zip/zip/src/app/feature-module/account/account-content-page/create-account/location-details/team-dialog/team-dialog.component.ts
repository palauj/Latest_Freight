import { Component, inject, Inject } from '@angular/core';
import {
  AbstractControl,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { catchError, EMPTY, take } from 'rxjs';
import { LoginUserData } from 'src/app/core/helpers/models/auth.model';
import { AddTeam, Team } from 'src/app/core/helpers/models/team.model';
import { AccountService } from 'src/app/core/services/account/account.service';
import { DropdownService } from 'src/app/core/services/dropdown/dropdown.service';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';

@Component({
  selector: 'app-team-dialog',
  templateUrl: './team-dialog.component.html',
  styleUrl: './team-dialog.component.scss',
})
export class TeamDialogComponent {
  isSubmitted = false;
  teamForm!: FormGroup;
  teamId!: string;
  teamData!: AddTeam;
  authUser!: LoginUserData;
  teamList: Team[] = [];

  private dropdownService = inject(DropdownService);
  private accountService = inject(AccountService);
  private toaster = inject(ToasterService);
  isEdit = false;
  teamName!: string;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<TeamDialogComponent>
  ) {}

  ngOnInit(): void {
    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);
    this.getDropdownTeams();
    if (this.data.id) {
      this.isEdit = true;
      this.getTeamById(this.data.id);
    }
    this.teamFormInit();
  }

  private getTeamById(id: string): void {
    this.accountService
      .getAccountTeamById(id)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.teamData = response.data;
            this.teamForm.patchValue({
              teamName: this.teamData.teamId,
              isActive: this.teamData.isActive,
            });

            if (this.teamData.teamId) {
              this.teamForm.get('teamName')?.disable();
            } else {
              this.teamForm.get('teamName')?.enable();
            }
          }
        }
      });
  }

  private teamFormInit(team?: any): void {
    this.teamForm = new FormGroup({
      teamName: new FormControl('', Validators.required),
      isActive: new FormControl(true, Validators.required),
    });
  }
  get c(): { [key: string]: AbstractControl } {
    return this.teamForm.controls;
  }

  private getDropdownTeams(): void {
    this.dropdownService
      .getTeamList()
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.teamList = response.data;
          }
        }
      });
  }

  getTeamName(id: string): void {
    const team = this.teamList.find((x) => x.teamId === id);
    this.teamName = team ? team.teamName : '';
  }

  close(): void {
    this.dialogRef.close();
  }

  submit(): void {
    this.isSubmitted = true;
    if (this.teamForm.invalid) {
      return;
    }

    this.getTeamName(
      this.teamForm.value.teamName
        ? this.teamForm.value.teamName
        : this.teamData.teamId
    );

    const teamPayload = {
      id: this.data.id ? this.data.id : null,
      teamId: this.teamForm.value.teamName
        ? this.teamForm.value.teamName
        : this.teamData.teamId,
      teamName: this.teamName,
      accountId: this.data.accountId ? this.data.accountId : '',
      locationId: this.data.locationId ? this.data.locationId : '',
      edit: this.data.id ? 1 : 0,
      isActive: this.teamForm.value.isActive,
      userId: this.authUser.employeeId,
    };
    this.accountService
      .addAccountTeam(teamPayload)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.dialogRef.close(response);
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }
}
