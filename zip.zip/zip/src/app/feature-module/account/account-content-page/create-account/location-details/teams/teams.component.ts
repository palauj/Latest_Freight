import { Component, inject, Input, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { catchError, EMPTY, take } from 'rxjs';
import { routes } from 'src/app/core/core.index';
import { AccountService } from 'src/app/core/services/account/account.service';
import { ConfirmationDialogComponent } from 'src/app/shared/dialogs/confirmation-dialog/confirmation-dialog.component';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { TeamDialogComponent } from '../team-dialog/team-dialog.component';
import { AddTeam } from 'src/app/core/helpers/models/team.model';
import { MatPaginator } from '@angular/material/paginator';
import { pageSelection } from 'src/app/core/helpers/models/common.model';
import { LoginUserData } from 'src/app/core/helpers/models/auth.model';

@Component({
  selector: 'app-teams',
  templateUrl: './teams.component.html',
  styleUrl: './teams.component.scss',
})
export class TeamsComponent {
  @Input() locationId: string = '';
  @Input() accountId: string = '';
  authUser!: LoginUserData;
  public searchDataValue = '';
  dataSource!: MatTableDataSource<AddTeam>;
  public routes = routes;
  // pagination variables
  public lastIndex = 0;
  public pageSize = 10;
  public totalData = 0;
  public skip = 0;
  public limit: number = this.pageSize;
  public pageIndex = 0;
  public serialNumberArray: Array<number> = [];
  public currentPage = 1;
  public pageNumberArray: Array<number> = [];
  public pageSelection: Array<pageSelection> = [];
  public totalPages = 0;
  //** / pagination variables

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  columnsToDisplay: string[] = ['action', 'teamName', 'status'];
  teams = new MatTableDataSource<AddTeam>();
  displayColumns: string[] = ['footer'];

  private accountService = inject(AccountService);
  readonly dialog = inject(MatDialog);
  private toaster = inject(ToasterService);

  constructor() {}

  ngOnInit(): void {
    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);
    this.getAllTeams();
  }

  ngAfterViewInit() {
    this.teams.paginator = this.paginator;
    this.teams.sort = this.sort;
  }

  private getAllTeams(): void {
    this.accountService
      .getAccountTeamList(this.locationId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.teams.data = response.data;
            this.totalData = response.data.length;
          }
        }
      });
  }

  // dialog
  addTeam(): void {
    const dialogRef = this.dialog.open(TeamDialogComponent, {
      width: '400px',
      data: {
        title: 'Add Team',
        accountId: this.accountId,
        locationId: this.locationId,
        submitBtn: 'Submit',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllTeams();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  editTeam(id: string): void {
    const dialogRef = this.dialog.open(TeamDialogComponent, {
      width: '400px',
      data: {
        title: 'Edit Team',
        accountId: this.accountId,
        locationId: this.locationId,
        submitBtn: 'Update',
        closeBtn: 'Close',
        id: id,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllTeams();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  openDeleteDialog(id: string): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '500px',
      data: {
        title: 'Delete Team',
        submitBtn: 'Delete',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.deleteTeam(id);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  deleteTeam(id: string): void {
    this.accountService
      .deleteAccountTeamById(id, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.getAllTeams();
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }
}
