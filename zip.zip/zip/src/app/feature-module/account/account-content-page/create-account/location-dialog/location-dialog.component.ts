import { Component, Inject, OnInit, inject } from '@angular/core';
import {
  AbstractControl,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { catchError, EMPTY, map, Observable, startWith, take } from 'rxjs';
import {
  LocationDialog,
  LocationModel,
} from 'src/app/core/helpers/models/account.model';
import { LoginUserData } from 'src/app/core/helpers/models/auth.model';
import {
  CityModel,
  CountryModel,
  StateModel,
} from 'src/app/core/helpers/models/common.model';
import { AccountService } from 'src/app/core/services/account/account.service';
import { DropdownService } from 'src/app/core/services/dropdown/dropdown.service';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';

@Component({
  selector: 'app-location-dialog',
  templateUrl: './location-dialog.component.html',
  styleUrls: ['./location-dialog.component.scss'],
})
export class LocationDialogComponent implements OnInit {
  isSubmitted = false;
  locationForm!: FormGroup;
  locationId!: string;
  locationDetails!: LocationModel;
  authUser!: LoginUserData;
  countries: CountryModel[] = [];
  filteredCountries!: Observable<CountryModel[]>;
  filteredStates!: Observable<StateModel[]>;
  filteredCities!: Observable<CityModel[]>;
  states: StateModel[] = [];
  cities: CityModel[] = [];
  countryId!: number;
  stateId!: number;
  cityId!: number;

  private accountService = inject(AccountService);
  public dropdownService = inject(DropdownService);
  private toaster = inject(ToasterService);

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: LocationDialog,
    public dialogRef: MatDialogRef<LocationDialogComponent>
  ) {}

  ngOnInit(): void {
    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);
    this.locationFormInit();
    if (this.data.id) {
      this.locationId = this.data.id;
      this.getLocationById(this.locationId);
    }
    this.getCountries();
    this.onCountryFocus();
    this.onStateFocus();
    this.onCityFocus();
  }

  onCountryFocus(): void {
    this.filteredCountries = this.c['country']?.valueChanges.pipe(
      startWith(''),
      map((value) => this._countryFilter(value ? value : ''))
    );
  }

  onStateFocus(): void {
    this.filteredStates = this.c['state']?.valueChanges.pipe(
      startWith(''),
      map((value) => this._stateFilter(value ? value : ''))
    );
  }

  onCityFocus(): void {
    this.filteredCities = this.c['city']?.valueChanges.pipe(
      startWith(''),
      map((value) => this._cityFilter(value ? value : ''))
    );
  }

  private getLocationById(id: string): void {
    this.accountService
      .getAccountLocationById(id)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.locationDetails = response.data;
            this.countryId = response.data.countryId;
            this.stateId = response.data.stateId;
            this.cityId = response.data.cityId;

            this.locationForm.patchValue({
              country: response.data.countryName,
              locationName: response.data.locationName,
              shortName: response.data.shortName,
              city: response.data.cityName,
              state: response.data.stateName,
              street: response.data.street,
              zipCode: response.data.zipCode,
            });

            this.getStates(this.countryId);
            this.getCities(this.stateId);
          }
        }
      });
  }

  private locationFormInit(): void {
    this.locationForm = new FormGroup({
      country: new FormControl('', Validators.required),
      locationName: new FormControl('', Validators.required),
      shortName: new FormControl('', Validators.required),
      city: new FormControl('', Validators.required),
      state: new FormControl('', Validators.required),
      address: new FormControl('', Validators.required),
      zipCode: new FormControl('', Validators.required),
    });
  }

  get c(): { [key: string]: AbstractControl } {
    return this.locationForm.controls;
  }

  private getCountries(): void {
    this.dropdownService
      .getCountriesDropdownList()
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response) {
          this.countries = response.data;
        }
      });
  }

  private _countryFilter(value: string): CountryModel[] {
    const filterValue = value ? value.toLowerCase() : '';
    return this.countries.filter((option) =>
      option.countryName.toLowerCase().includes(filterValue)
    );
  }

  private _stateFilter(value: string): StateModel[] {
    const filterValue = value ? value.toLowerCase() : '';
    return this.states.filter((option) =>
      option.stateName.toLowerCase().includes(filterValue)
    );
  }

  private _cityFilter(value: string): CityModel[] {
    const filterValue = value ? value.toLowerCase() : '';
    return this.cities.filter((option) =>
      option.cityName.toLowerCase().includes(filterValue)
    );
  }

  onCountrySelected(value: string): void {
    const selectedCountry = value;
    const item = this.countries.find(
      (option) => option.countryName === selectedCountry
    );
    if (item) {
      this.countryId = item.countryId;
      this.getStates(this.countryId);
    }
  }

  onStateSelected(value: string): void {
    const selectedState = value;
    const item = this.states.find(
      (option) => option.stateName === selectedState
    );
    if (item) {
      this.stateId = item.stateId;
      this.getCities(this.stateId);
    }
  }

  onCitySelected(value: string): void {
    const selectedCity = value;
    const item = this.cities.find((option) => option.cityName === selectedCity);
    if (item) {
      this.cityId = item.cityId;
    }
  }

  getStates(countryId: number): void {
    this.dropdownService
      .getStatesDropdownList(countryId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response) {
          this.states = response.data;
        }
      });
  }

  getCities(stateId: number): void {
    this.dropdownService
      .getCitiesDropdownList(stateId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response) {
          this.cities = response.data;
        }
      });
  }

  close(): void {
    this.dialogRef.close();
  }

  submit(): void {
    this.isSubmitted = true;
    if (this.locationForm.invalid) {
      return;
    }
    const locationPayload = {
      locationId: this.locationId ? this.locationId : '',
      accountId: this.data.accountId,
      accountName: this.data.accountName,
      locationAddress: this.locationForm.value.address,
      shortName: this.locationForm.value.shortName,
      locationName: this.locationForm.value.locationName,
      stateName: this.locationForm.value.state,
      countryName: this.locationForm.value.country,
      cityName: this.locationForm.value.city,
      zipCode: this.locationForm.value.zipCode,
      edit: this.locationId ? 1 : 0,
      street: this.locationForm.value.street,
      userId: this.authUser.employeeId,
      countryId: this.countryId,
      stateId: this.stateId,
      cityId: this.cityId,
    };

    this.accountService
      .addAccountLocation(locationPayload)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.dialogRef.close(true);
            this.toaster.typeSuccess(response?.message, 'Success');
          } else {
            this.toaster.typeError(response.message, 'Error');
            return;
          }
        }
      });
  }
}
