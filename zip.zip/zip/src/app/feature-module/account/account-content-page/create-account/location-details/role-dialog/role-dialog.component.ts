import { Component, inject, Inject } from '@angular/core';
import {
  AbstractControl,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { catchError, EMPTY, take } from 'rxjs';
import { LoginUserData } from 'src/app/core/helpers/models/auth.model';
import { AddRole, Roles } from 'src/app/core/helpers/models/role.model';
import { AccountService } from 'src/app/core/services/account/account.service';
import { DropdownService } from 'src/app/core/services/dropdown/dropdown.service';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';

@Component({
  selector: 'app-role-dialog',
  templateUrl: './role-dialog.component.html',
  styleUrl: './role-dialog.component.scss',
})
export class RoleDialogComponent {
  isSubmitted = false;
  roleForm!: FormGroup;
  roleId!: string;
  roleData!: AddRole;
  authUser!: LoginUserData;
  masterRoleList: Roles[] = [];

  private deopdownService = inject(DropdownService);
  private accountService = inject(AccountService);
  private toaster = inject(ToasterService);
  isEdit = false;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<RoleDialogComponent>
  ) {}

  ngOnInit(): void {
    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);
    this.getMasterRoles();
    if (this.data.id) {
      this.isEdit = true;
      this.getRoleById(this.data.id);
    }
    this.roleFormInit();
  }

  private getRoleById(id: string): void {
    this.accountService
      .getAccountRoleById(id)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.roleData = response.data;
            this.roleForm.patchValue({
              roleName: response.data.roleId,
              isActive: response.data.isActive,
            });

            if (response.data.roleId) {
              this.roleForm.get('roleName')?.disable();
            } else {
              this.roleForm.get('roleName')?.enable();
            }
          }
        }
      });
  }

  private roleFormInit(): void {
    this.roleForm = new FormGroup({
      roleName: new FormControl('', Validators.required),
      isActive: new FormControl(true, Validators.required),
    });
  }

  get c(): { [key: string]: AbstractControl } {
    return this.roleForm.controls;
  }

  private getMasterRoles(): void {
    this.deopdownService
      .getMasterRolesDropdownList()
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.masterRoleList = response.data;
          }
        }
      });
  }

  close(): void {
    this.dialogRef.close();
  }

  submit(): void {
    this.isSubmitted = true;
    if (this.roleForm.invalid) {
      return;
    }

    const rolePayload = {
      id: this.data.id ? this.data.id : null,
      roleId: this.roleForm.value.roleName
        ? this.roleForm.value.roleName
        : this.roleData.roleId,
      accountId: this.data.accountId ? this.data.accountId : '',
      locationId: this.data.locationId ? this.data.locationId : '',
      edit: this.data.id ? 1 : 0,
      isActive: this.roleForm.value.isActive,
      userId: this.authUser.employeeId,
    };
    this.accountService
      .addAccountRole(rolePayload)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.dialogRef.close(response);
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }
}
