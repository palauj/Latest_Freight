import { Component, Inject, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  Validators,
} from '@angular/forms';
import { category, Category } from 'src/app/core/helpers/models/role.model';
import { DropdownService } from 'src/app/core/services/dropdown/dropdown.service';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { catchError, EMPTY, take } from 'rxjs';
import { AccountService } from 'src/app/core/services/account/account.service';
import { LoginUserData } from 'src/app/core/helpers/models/auth.model';

@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrl: './add-category.component.scss',
})
export class AddCategoryComponent {
  isSubmitted = false;
  categoryForm!: FormGroup;
  categoryId!: string;
  categoryData!: Category;
  masterCategoryList: category[] = [];
  authUser!: LoginUserData;
  public subLookupList: any = [];
  public tableList: any = [];

  private dropdownService = inject(DropdownService);
  private accountService = inject(AccountService);
  private toaster = inject(ToasterService);
  isEdit = false;

  constructor(
    private fb: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<AddCategoryComponent>
  ) {}

  ngOnInit(): void {
    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);
    this.GetDropdownForCategoryMasterList();
    // this.getSubLookupList();
    
    this.createForm();
    this.getTablesRecordList();
  }

  // getSubLookupList() {
  //   let id = '64d12316-ff8d-47e2-99f9-284c7617f58f';
  //   this.dropdownService
  //     .getSubLookupList(id)
  //     .pipe(
  //       catchError((error) => {
  //         alert(error);
  //         return EMPTY;
  //       }),
  //       take(1)
  //     )
  //     .subscribe((res: any) => {
  //       if (res?.statusCode < 399) {
  //         this.subLookupList = res?.data?.subLookUpList;
  //       }
  //     });
  // }
 
  // ngAfterViewInit(): void {
  //   if (this.data?.parentId) {
  //     this.categoryForm.get('relatedToId')?.clearValidators();
  //     this.categoryForm.get('relatedToId')?.updateValueAndValidity();
  //   } else {
  //     this.categoryForm
  //       .get('relatedToId')
  //       ?.setValidators([Validators.required]);
  //     this.categoryForm.get('relatedToId')?.updateValueAndValidity();
  //   }
  // }

  createForm(): void {
    this.categoryForm = this.fb.group({
      objectName: [this.data?.objectName || '', [Validators.required]],
      // relatedToId: [this.data?.relatedToId || ''],
      // relatedToName: [this.data?.relatedToName || ''],
      name: [this.data?.name || '', [Validators.required]],
      isActive: [
        this.data?.isActive ? 'inactive' : 'active',
        [Validators.required],
      ],
    });
  }
  get c(): { [key: string]: AbstractControl } {
    return this.categoryForm.controls;
  }

  close(): void {
    this.dialogRef.close();
  }
  getTablesRecordList() {
    this.dropdownService.getTablesRecordList().pipe(
      catchError((error) => {
        alert(error);
        return EMPTY;
      }),
      take(1)
    ).subscribe(
      (res: any) => {
        if (res?.statusCode === 200) {
          this.tableList = res?.data; // Store API response
        } else {
          console.error('Failed to fetch dropdown data:', res?.message);
        }
      },
     
    );
  }

  submit(): void {
    this.isSubmitted = true;
    if (this.categoryForm.invalid) {
      return;
    }

    const categoryPayload = {
      id: this.data.id ? this.data.id : null,
      categoryId: this.categoryForm.value.name
        ? this.categoryForm.value.name
        : this.categoryData.categoryType,
      accountId: this.data.accountId ? this.data.accountId : '',
      locationId: this.data.locationId ? this.data.locationId : '',
      edit: this.data.id ? 1 : 0,
      objectName: this.categoryForm.value?.objectName,
      name: this.data?.name,
      isActive: this.categoryForm.value.isActive,
      // relatedToId: this.categoryForm.value?.relatedToId,
      // relatedToName: this.subLookupList.find(
      //   (e: any) => e.subLookUpId == this.categoryForm.value?.relatedToId
      // )?.lookUpName,
      // relatedTo: this.getLookupName(),
      userId: this.authUser.employeeId,
    };
    this.accountService
      .addAccountCategory(categoryPayload)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.dialogRef.close(response);
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }
  GetDropdownForCategoryMasterList() {
    this.dropdownService
      .getDropdownForCategoryMasterList()
      .pipe(
        catchError((error) => {
          alert(error);
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((res: any) => {
        if (res?.statusCode < 399) {
          this.masterCategoryList = res?.data;
        }
      });
  }
}
