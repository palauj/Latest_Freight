import { Component, Inject, inject, signal } from '@angular/core';
import {
  AbstractControl,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatChipInputEvent } from '@angular/material/chips';
import { catchError, EMPTY, take } from 'rxjs';
import {
  AccountDropDown,
  BasicInfoList,
} from 'src/app/core/helpers/models/account.model';
import { DropdownService } from 'src/app/core/services/dropdown/dropdown.service';
import { DatasModel } from '../create-account.component';
import { LiveAnnouncer } from '@angular/cdk/a11y';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { AccountService } from 'src/app/core/services/account/account.service';
import { environment } from 'src/environments/environment';
import { LoginUserData } from 'src/app/core/helpers/models/auth.model';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-basic-info-dialog',
  templateUrl: './basic-info-dialog.component.html',
  styleUrl: './basic-info-dialog.component.scss',
})
export class BasicInfoDialogComponent {
  isSubmitted: boolean = false;
  basicInfoForm!: FormGroup;
  base64Image!: string | ArrayBuffer | null;
  authUser!: LoginUserData;

  apiUrl = environment.apiUrl;
  isImageChanged = false;
  isEdit = false;
  accounts: AccountDropDown[] = [];
  accountName = '';
  accountId = '';
  responseImg = '';
  backBtnRoute = '';
  currentStep = 1;
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];
  readonly keywords = signal<string[]>([]);

  readonly announcer = inject(LiveAnnouncer);
  public dropdownService = inject(DropdownService);
  private accountService = inject(AccountService);
  private toaster = inject(ToasterService);

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<BasicInfoDialogComponent>
  ) {}

  ngOnInit(): void {
    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);

    this.basicFormInit();
    if (this.data.id) {
      this.accountId = this.data.id;
      this.getAccountDetails(this.data.basicData);
    }
    this.getAccountList();
  }

  private getAccountList(): void {
    this.accounts = [];

    this.dropdownService
      .getAccountList()
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response) {
          this.accounts = response.data;
        }
      });
  }

  close(): void {
    this.dialogRef.close();
  }

  private getAccountDetails(data: BasicInfoList): void {
    this.keywords.update((keywords) => {
      const newTags = data.tags || '';
      const tagsArray = newTags
        .split(',')
        .map((tag: string) => tag.trim())
        .filter((tag: string) => tag);

      return [...keywords, ...tagsArray];
    });

    this.accountName = data.companyName ? data.companyName : '';

    this.basicInfoForm.patchValue({
      companyName: data.companyName,
      email: data.email,
      phone1: data.phone1,
      phone2: data.phone2,
      fax: data.fax,
      website: data.website,
      owner: data.ownerName,
      tags: data.tags,
      aboutCompany: data.aboutCompany,
    });
  }

  private basicFormInit(): void {
    this.basicInfoForm = new FormGroup({
      profilePic: new FormControl(''),
      companyName: new FormControl('', [
        Validators.required,
        Validators.minLength(5),
      ]),
      email: new FormControl('', [Validators.required, Validators.email]),
      phone1: new FormControl('', [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(15),
      ]),
      phone2: new FormControl('', [
        Validators.minLength(10),
        Validators.maxLength(15),
      ]),
      fax: new FormControl('', Validators.required),
      website: new FormControl(''),
      owner: new FormControl('', Validators.required),
      tags: new FormControl([], Validators.required),
      aboutCompany: new FormControl('', [
        Validators.required,
        Validators.minLength(50),
        Validators.maxLength(100),
      ]),
    });
  }

  get c(): { [key: string]: AbstractControl } {
    return this.basicInfoForm.controls;
  }

  getAccountName(id: string): void {
    const account = this.accounts.find((x) => x.accountId === id);
    this.accountName = account ? account.accountName : '';
  }

  // Methods for managing chips (tags)
  trackByFn(index: number, item: DatasModel) {
    return item.name;
  }

  removeKeyword(keyword: string) {
    this.keywords.update((keywords) => {
      const index = keywords.indexOf(keyword);
      if (index < 0) {
        return keywords;
      }

      keywords.splice(index, 1);
      this.announcer.announce(`removed ${keyword}`);
      return [...keywords];
    });
  }

  add(event: MatChipInputEvent): void {
    const value = (event.value || '').trim();

    // Add our keyword
    if (value) {
      this.keywords.update((keywords) => [...keywords, value]);
    }

    // Clear the input value
    event.chipInput!.clear();
  }

  submit(): void {
    this.isSubmitted = true;
    if (this.basicInfoForm.invalid) {
      this.toaster.typeError('Form is invalid', 'Error');
      return;
    }
    const basicPayload = {
      accountId: this.accountId ? this.accountId : '',
      companyName: this.basicInfoForm.value.companyName,
      email: this.basicInfoForm.value.email,
      phone1: this.basicInfoForm.value.phone1,
      phone2: this.basicInfoForm.value.phone2,
      fax: this.basicInfoForm.value.fax,
      website: this.basicInfoForm.value.website,
      ownerName: this.authUser.accountId,
      tags: Array.isArray(this.basicInfoForm.value.tags)
        ? this.basicInfoForm.value.tags.join(', ')
        : this.basicInfoForm.value.tags,
      aboutCompany: this.basicInfoForm.value.aboutCompany,
      userId: this.authUser.employeeId,
    };
    this.accountService
      .updateBasicDetails(basicPayload)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.dialogRef.close(true);
            this.toaster.typeSuccess(response.message, 'Success');
          } else {
            this.toaster.typeError(response.message, 'Error');
            return;
          }
        }
      });
  }
}
