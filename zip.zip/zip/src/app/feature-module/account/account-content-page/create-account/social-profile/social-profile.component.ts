import { Component } from '@angular/core';

@Component({
  selector: 'app-social-profile',
  templateUrl: './social-profile.component.html',
  styleUrl: './social-profile.component.scss',
})
export class SocialProfileComponent {}
