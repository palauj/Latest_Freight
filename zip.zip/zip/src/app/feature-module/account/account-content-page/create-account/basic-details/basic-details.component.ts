import { Component, inject, OnInit, signal } from '@angular/core';
import {
  AbstractControl,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatChipInputEvent } from '@angular/material/chips';
import { catchError, EMPTY, take } from 'rxjs';
import { AccountDropDown } from 'src/app/core/helpers/models/account.model';
import { DropdownService } from 'src/app/core/services/dropdown/dropdown.service';
import { DatasModel } from '../create-account.component';
import { LiveAnnouncer } from '@angular/cdk/a11y';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { ActivatedRoute } from '@angular/router';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { AccountService } from 'src/app/core/services/account/account.service';
import { environment } from 'src/environments/environment';
import { LoginUserData } from 'src/app/core/helpers/models/auth.model';

@Component({
  selector: 'app-basic-details',
  templateUrl: './basic-details.component.html',
  styleUrl: './basic-details.component.scss',
})
export class BasicDetailsComponent implements OnInit {
  isSubmitted: boolean = false;
  basicInfoForm!: FormGroup;
  base64Image!: string | ArrayBuffer | null;
  authUser!: LoginUserData;

  apiUrl = environment.apiUrl;
  isImageChanged = false;
  isEdit = false;
  accounts: AccountDropDown[] = [];
  accountName = '';
  accountId = '';
  responseImg = '';
  backBtnRoute = '';
  currentStep = 1;
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];
  readonly keywords = signal<string[]>([]);

  readonly announcer = inject(LiveAnnouncer);
  private activateRoute = inject(ActivatedRoute);
  public dropdownService = inject(DropdownService);
  private accountService = inject(AccountService);
  private toaster = inject(ToasterService);

  ngOnInit(): void {
    this.backBtnRoute = '/admin/accounts/account-list';
    localStorage.setItem('currentStep', this.currentStep.toString());

    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);

    this.basicFormInit();
    this.activateRoute.params.subscribe((params) => {
      const accountId = params['id'];
      if (accountId) {
        localStorage.setItem('accountId', accountId);
        this.isEdit = true;
        this.accountId = accountId;
        this.getAccountDetails(this.accountId);
      }
    });
    this.getAccountList();
  }

  private getAccountList(): void {
    this.accounts = [];

    this.dropdownService
      .getAccountList()
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response) {
          this.accounts = response.data;
        }
      });
  }

  private getAccountDetails(id: string): void {
    this.accountService
      .getAccountDetailById(id)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.base64Image =
              this.apiUrl +
              '/' +
              response.data.accountBasicInfoList[0]?.profilePicture;
            this.responseImg =
              response.data.accountBasicInfoList[0]?.profilePicture;

            this.keywords.update((keywords) => {
              const newTags = response.data.accountBasicInfoList[0]?.tags || '';
              const tagsArray = newTags
                .split(',')
                .map((tag: string) => tag.trim())
                .filter((tag: string) => tag);

              return [...keywords, ...tagsArray];
            });

            if (response.data.accountBasicInfoList.length > 0) {
              this.accountName =
                response.data.accountBasicInfoList[0]?.companyName;

              this.basicInfoForm.patchValue({
                profilePic: '',
                companyName: response.data.accountBasicInfoList[0]?.companyName,
                email: response.data.accountBasicInfoList[0]?.email,
                phone1: response.data.accountBasicInfoList[0]?.phone1,
                phone2: response.data.accountBasicInfoList[0]?.phone2,
                fax: response.data.accountBasicInfoList[0]?.fax,
                website: response.data.accountBasicInfoList[0]?.website,
                owner: response.data.accountBasicInfoList[0]?.ownerName,
                tags: response.data.accountBasicInfoList[0]?.tags,
                aboutCompany:
                  response.data.accountBasicInfoList[0]?.aboutCompany,
              });
            }
          } else {
            this.toaster.typeError(response.message, 'Error');
            return;
          }
        }
      });
  }

  private basicFormInit(): void {
    this.basicInfoForm = new FormGroup({
      profilePic: new FormControl(''),
      companyName: new FormControl('', [
        Validators.required,
        Validators.minLength(5),
      ]),
      email: new FormControl('', [Validators.required, Validators.email]),
      phone1: new FormControl('', [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(15),
      ]),
      phone2: new FormControl('', [
        Validators.minLength(10),
        Validators.maxLength(15),
      ]),
      fax: new FormControl('', Validators.required),
      website: new FormControl(''),
      owner: new FormControl('', Validators.required),
      tags: new FormControl([], Validators.required),
      aboutCompany: new FormControl('', [
        Validators.required,
        Validators.minLength(50),
      ]),
    });
  }

  get c(): { [key: string]: AbstractControl } {
    return this.basicInfoForm.controls;
  }

  onFileChange(event: any): void {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const base64Data = reader.result;
        this.base64Image = base64Data;
        this.isImageChanged = true;
      };
      reader.readAsDataURL(file);
    }
  }

  resetImage(): void {
    this.basicInfoForm.get('profilePic')?.setValue('');
    this.base64Image = null;
  }

  getAccountName(id: string): void {
    const account = this.accounts.find((x) => x.accountId === id);
    this.accountName = account ? account.accountName : '';
  }

  // Methods for managing chips (tags)
  trackByFn(index: number, item: DatasModel) {
    return item.name;
  }

  removeKeyword(keyword: string) {
    this.keywords.update((keywords) => {
      const index = keywords.indexOf(keyword);
      if (index < 0) {
        return keywords;
      }

      keywords.splice(index, 1);
      this.announcer.announce(`removed ${keyword}`);
      return [...keywords];
    });
  }

  add(event: MatChipInputEvent): void {
    const value = (event.value || '').trim();

    // Add our keyword
    if (value) {
      this.keywords.update((keywords) => [...keywords, value]);
    }

    // Clear the input value
    event.chipInput!.clear();
  }

  submitBasicDetails(): void {
    this.isSubmitted = true;
    if (this.basicInfoForm.invalid) {
      return;
    }
    const basicPayload = {
      accountId: this.accountId ? this.accountId : '',
      companyName: this.basicInfoForm.value.companyName,
      email: this.basicInfoForm.value.email,
      phone1: this.basicInfoForm.value.phone1,
      phone2: this.basicInfoForm.value.phone2,
      fax: this.basicInfoForm.value.fax,
      website: this.basicInfoForm.value.website,
      ownerName: this.basicInfoForm.value.owner,
      tags: Array.isArray(this.basicInfoForm.value.tags)
        ? this.basicInfoForm.value.tags.join(', ')
        : this.basicInfoForm.value.tags,
      aboutCompany: this.basicInfoForm.value.aboutCompany,
      userId: this.authUser.employeeId,
    };
    if (this.isEdit) {
      this.accountService
        .updateBasicDetails(basicPayload)
        .pipe(
          catchError((error: any) => {
            return EMPTY;
          }),
          take(1)
        )
        .subscribe((response: any) => {
          if (response && response.message) {
            if (response.statusCode === 200) {
              // this.selectedFieldSet[0] = 1;
              this.toaster.typeSuccess(response.message, 'Success');
              // this.currentStep++;
            } else {
              this.toaster.typeError(response.message, 'Error');
              return;
            }
          }
        });
    } else {
      this.accountService
        .addBasicDetails(basicPayload)
        .pipe(
          catchError((error: any) => {
            return EMPTY;
          }),
          take(1)
        )
        .subscribe((response: any) => {
          if (response && response.message) {
            if (response.statusCode === 200) {
              // this.selectedFieldSet[0] = 1;
              // this.accountId = response.data.accountId;
              this.accountName = response.data.accountName;
              // localStorage.setItem('accountId', this.accountId);
              // localStorage.setItem('accountName', this.accountName);
              this.toaster.typeSuccess(response.message, 'Success');
              // this.currentStep++;
            } else {
              this.toaster.typeError(response.message, 'Error');
              return;
            }
          }
        });
    }
  }
}
