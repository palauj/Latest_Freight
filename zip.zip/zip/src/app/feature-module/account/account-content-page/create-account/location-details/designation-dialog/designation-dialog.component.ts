import { Component, inject, Inject, OnInit, signal } from '@angular/core';
import {
  AbstractControl,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { catchError, EMPTY, take } from 'rxjs';
import { LoginUserData } from 'src/app/core/helpers/models/auth.model';
import {
  AddDesignation,
  Designation,
  MasterDesignation,
} from 'src/app/core/helpers/models/designation.model';
import { AccountService } from 'src/app/core/services/account/account.service';
import { DropdownService } from 'src/app/core/services/dropdown/dropdown.service';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';

@Component({
  selector: 'app-designation-dialog',
  templateUrl: './designation-dialog.component.html',
  styleUrl: './designation-dialog.component.scss',
})
export class DesignationDialogComponent implements OnInit {
  isSubmitted = false;
  designationForm!: FormGroup;
  designationId!: string;
  designationData!: AddDesignation;
  authUser!: LoginUserData;
  masterDesignationList: Designation[] = [];

  private dropdownService = inject(DropdownService);
  private accountService = inject(AccountService);
  private toaster = inject(ToasterService);
  isEdit = false;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<DesignationDialogComponent>
  ) {}

  ngOnInit(): void {
    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);
    this.getMasterDesignations();
    if (this.data.id) {
      this.isEdit = true;
      this.getDesignationById(this.data.id);
    }
    this.designationFormInit();
  }

  private getDesignationById(id: string): void {
    this.accountService
      .getAccountDesignationById(id)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.designationData = response.data;
            this.designationForm.patchValue({
              designationName: response.data.designationId,
              isActive: response.data.isActive,
            });

            if (response.data.designationId) {
              this.designationForm.get('designationName')?.disable();
            } else {
              this.designationForm.get('designationName')?.enable();
            }
          }
        }
      });
  }

  private designationFormInit(): void {
    this.designationForm = new FormGroup({
      designationName: new FormControl('', Validators.required),
      isActive: new FormControl(true, Validators.required),
    });
  }

  get c(): { [key: string]: AbstractControl } {
    return this.designationForm.controls;
  }

  private getMasterDesignations(): void {
    this.dropdownService
      .getMasterDesignationDropdownList()
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.masterDesignationList = response.data;
          }
        }
      });
  }

  close(): void {
    this.dialogRef.close();
  }

  submit(): void {
    this.isSubmitted = true;
    if (this.designationForm.invalid) {
      return;
    }

    const designationPayload = {
      id: this.data.id ? this.data.id : null,
      designationId: this.designationForm.value.designationName
        ? this.designationForm.value.designationName
        : this.designationData.designationId,
      accountId: this.data.accountId ? this.data.accountId : '',
      locationId: this.data.locationId ? this.data.locationId : '',
      edit: this.data.id ? 1 : 0,
      isActive: this.designationForm.value.isActive,
      userId: this.authUser.employeeId,
    };
    this.accountService
      .addAccountDesignation(designationPayload)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.dialogRef.close(response);
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }
}
