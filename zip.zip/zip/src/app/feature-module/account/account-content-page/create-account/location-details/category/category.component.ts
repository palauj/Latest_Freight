import { Component, inject, Input, OnInit, ViewChild } from '@angular/core';
import { LoginUserData } from 'src/app/core/helpers/models/auth.model';
import { routes } from 'src/app/core/core.index';
import { pageSelection } from 'src/app/core/helpers/models/common.model';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Category } from 'src/app/core/helpers/models/role.model';
import { AccountService } from 'src/app/core/services/account/account.service';
import { MatDialog } from '@angular/material/dialog';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { catchError, EMPTY, take } from 'rxjs';
import { AddCategoryComponent } from './add-category/add-category.component';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrl: './category.component.scss'
})
export class CategoryComponent implements OnInit {
  @Input() locationId: string = '';
  @Input() categoryType: string = '';
  @Input() accountId: string = '';
  public searchDataValue = '';
  authUser!: LoginUserData;
  public routes = routes;
  totalCount:number=0
  pageNo:number=1;
  public lastIndex = 0;
  public pageSize = 10;
  public totalData = 0;
  public skip = 0;
  public limit: number = this.pageSize;
  public pageIndex = 0;
  public serialNumberArray: Array<number> = [];
  public currentPage = 1;
  public pageNumberArray: Array<number> = [];
  public pageSelection: Array<pageSelection> = [];
  public totalPages = 0;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  columnsToDisplay: string[] = ['action', 'name',  'isActive'];
  category = new MatTableDataSource<Category>();
  displayColumns: string[] = ['footer'];

  private accountService = inject(AccountService);
  readonly dialog = inject(MatDialog);
  private toaster = inject(ToasterService);

  constructor() { }

  ngOnInit(): void {
    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);
    this.getAllCategory();
  }
  ngAfterViewInit() {
    this.category.paginator = this.paginator;
    this.category.sort = this.sort;
  }
  private getAllCategory(): void {
    let param = {
      pageNo: this.pageNo,
      pageSize: this.pageSize,
      categoryType: 'Parent',
      parentId: ''
    };
    this.accountService
      .getAccountCategoryList(param)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.category.data = response.data?.masterCategoryList;
            this.totalData = response.data.length;
          }
        }
      });
  }
  // dialog
  addCategory(): void {
    const dialogRef = this.dialog.open(AddCategoryComponent, {
      width: '400px',
      data: {
        title: 'Add Category',
        accountId: this.accountId,
        locationId: this.locationId,
        submitBtn: 'Submit',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllCategory();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  editCategory(id: string): void {
    const dialogRef = this.dialog.open(AddCategoryComponent, {
      width: '400px',
      data: {
        title: 'Edit Category',
        accountId: this.accountId,
        locationId: this.locationId,
        submitBtn: 'Update',
        closeBtn: 'Close',
        id: id,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllCategory();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  openDeleteDialog(id: string): void {
    const dialogRef = this.dialog.open(AddCategoryComponent, {
      width: '500px',
      data: {
        title: 'Delete Category',
        submitBtn: 'Delete',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.deleteCategory(id);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  deleteCategory(id: string): void {
    this.accountService
      .deleteAccountCategoryById(id, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.getAllCategory();
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }
}
