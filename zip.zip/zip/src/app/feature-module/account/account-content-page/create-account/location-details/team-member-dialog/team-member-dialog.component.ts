import { Component, inject, Inject } from '@angular/core';
import {
  AbstractControl,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { catchError, EMPTY, take } from 'rxjs';
import { LoginUserData } from 'src/app/core/helpers/models/auth.model';
import {
  Department,
  Employee,
} from 'src/app/core/helpers/models/department.model';
import { AddTeamMember, Team } from 'src/app/core/helpers/models/team.model';
import { AccountService } from 'src/app/core/services/account/account.service';
import { DropdownService } from 'src/app/core/services/dropdown/dropdown.service';
import { TeamsService } from 'src/app/core/services/teams/teams.service';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';

@Component({
  selector: 'app-team-member-dialog',
  templateUrl: './team-member-dialog.component.html',
  styleUrl: './team-member-dialog.component.scss',
})
export class TeamMemberDialogComponent {
  isSubmitted = false;
  teamForm!: FormGroup;
  teamId!: string;
  teamData!: AddTeamMember;
  authUser!: LoginUserData;
  teamList: Team[] = [];
  employeeList: Employee[] = [];
  employeePayload: Employee[] = [];
  departmentList: Department[] = [];

  private teamService = inject(TeamsService);
  private accountService = inject(AccountService);
  private toaster = inject(ToasterService);
  private dropdownService = inject(DropdownService);
  isEdit = false;
  teamName!: string;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<TeamMemberDialogComponent>
  ) {}

  ngOnInit(): void {
    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);

    this.getMasterTeams();
    this.getEmployeeList();
    this.getDepartmentList();
    if (this.data.id) {
      this.isEdit = true;
      this.getTeamById(this.data.id);
    }
    this.teamFormInit();
  }

  private getTeamById(id: string): void {
    this.accountService
      .getAccountTeamMemberById(id)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.teamData = response.data;

            this.teamForm.patchValue({
              teamName: this.teamData.teamId,
              department: this.teamData.departmentId,
              employees: this.teamData.employeeId
                .split(',')
                .map((item) => item.trim()),
              isActive: this.teamData.isActive,
            });

            if (this.teamData.accountTeamId) {
              this.teamForm.get('teamName')?.disable();
            } else {
              this.teamForm.get('teamName')?.enable();
            }
          }
        }
      });
  }

  private teamFormInit(): void {
    this.teamForm = new FormGroup({
      teamName: new FormControl('', Validators.required),
      department: new FormControl('', Validators.required),
      employees: new FormControl('', Validators.required),
      isActive: new FormControl(true, Validators.required),
    });
  }

  get c(): { [key: string]: AbstractControl } {
    return this.teamForm.controls;
  }

  private getMasterTeams(): void {
    this.dropdownService
      .getTeamList()
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.teamList = response.data;

            const team = this.teamList.find(
              (x) => x.teamId === this.data.teamId
            );

            this.teamForm.patchValue({
              teamName: team ? team.teamId : '',
            });

            if (team && team.teamId) {
              this.teamForm.get('teamName')?.disable();
            } else {
              this.teamForm.get('teamName')?.enable();
            }
          }
        }
      });
  }

  private getEmployeeList(): void {
    this.dropdownService
      .getEmployeeList(this.data.accountId, this.data.locationId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.employeeList = response.data;
          }
        }
      });
  }

  private getDepartmentList(): void {
    this.dropdownService
      .getDepartmentList(this.data.accountId, this.data.locationId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.departmentList = response.data;
          }
        }
      });
  }

  getEmployeeName(id: string[]): void {
    this.employeePayload = [];
    id.forEach((id) => {
      const employee = this.employeeList.find((x) => x.employeeId === id);
      if (employee) this.employeePayload.push(employee);
    });
  }

  close(): void {
    this.dialogRef.close();
  }

  submit(): void {
    this.isSubmitted = true;
    if (this.teamForm.invalid) {
      return;
    }

    const teamMemberPayload = {
      teamMemberId: this.teamData ? this.teamData.teamMemberId : '',
      teamId: this.data.teamId,
      employeeId: this.teamForm.value.employees.join(', '),
      departmentId: this.teamForm.value.department,
      locationId: this.data.locationId,
      accountId: this.data.accountId,
      accountTeamId: this.data.id,
      isActive: this.teamForm.value.isActive,
      userId: this.authUser.employeeId,
    };
    this.accountService
      .addAccountTeamMember(teamMemberPayload)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.dialogRef.close(response);
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }
}
