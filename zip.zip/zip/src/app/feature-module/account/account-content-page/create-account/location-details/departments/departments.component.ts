import { Component, inject, Input, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { catchError, EMPTY, take } from 'rxjs';
import { AddDepartment } from 'src/app/core/helpers/models/department.model';
import { routes } from 'src/app/core/helpers/routes/routes';
import { AccountService } from 'src/app/core/services/account/account.service';
import { DataService } from 'src/app/core/services/data/data.service';
import {
  allroles,
  getDepartment,
  getTimeSheet,
  members,
} from 'src/app/core/services/interface/models';
import { DepartmentDialogComponent } from '../department-dialog/department-dialog.component';
import { ConfirmationDialogComponent } from 'src/app/shared/dialogs/confirmation-dialog/confirmation-dialog.component';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { MatPaginator } from '@angular/material/paginator';
import { pageSelection } from 'src/app/core/helpers/models/common.model';
import { LoginUserData } from 'src/app/core/helpers/models/auth.model';

@Component({
  selector: 'app-departments',
  templateUrl: './departments.component.html',
  styleUrl: './departments.component.scss',
})
export class DepartmentsComponent {
  @Input() locationId: string = '';
  @Input() accountId: string = '';
  readonly dialog = inject(MatDialog);
  public searchDataValue = '';
  public routes = routes;
  // pagination variables
  public lastIndex = 0;
  public pageSize = 10;
  public totalData = 0;
  public skip = 0;
  public limit: number = this.pageSize;
  public pageIndex = 0;
  public serialNumberArray: Array<number> = [];
  public currentPage = 1;
  public pageNumberArray: Array<number> = [];
  public pageSelection: Array<pageSelection> = [];
  public totalPages = 0;
  public lstTimesheet: Array<getTimeSheet> = [];
  //** / pagination variables

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  columnsToDisplay: string[] = ['action', 'departmentName', 'status'];
  displayColumns: string[] = ['footer'];

  public allroles: Array<allroles>;
  member!: members[];
  departments = new MatTableDataSource<AddDepartment>();
  private accountService = inject(AccountService);
  private toaster = inject(ToasterService);
  selectedDepartmentId!: string;
  authUser!: LoginUserData;

  constructor(public router: Router, private data: DataService) {
    this.allroles = this.data.allroles;
  }

  ngOnInit(): void {
    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);
    this.getAllDepartments();
  }

  ngAfterViewInit() {
    this.departments.paginator = this.paginator;
    this.departments.sort = this.sort;
  }

  viewTeamMember(member: getDepartment) {
    this.member = member.members;
  }

  addDepartment(): void {
    const dialogRef = this.dialog.open(DepartmentDialogComponent, {
      width: '400px',
      data: {
        title: 'Add Department',
        accountId: this.accountId,
        locationId: this.locationId,
        submitBtn: 'Submit',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllDepartments();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  editDepartment(id: string): void {
    const dialogRef = this.dialog.open(DepartmentDialogComponent, {
      width: '400px',
      data: {
        title: 'Edit Department',
        accountId: this.accountId,
        locationId: this.locationId,
        submitBtn: 'Update',
        closeBtn: 'Close',
        id: id,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllDepartments();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  private getAllDepartments(): void {
    this.accountService
      .getAccountDepartmentList(this.locationId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.departments.data = response.data;
            this.totalData = response.data.length;
          }
        }
      });
  }

  openDeleteDialog(id: string): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '500px',
      data: {
        title: 'Delete Department',
        submitBtn: 'Delete',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.deleteDepartment(id);
      } else {
        // console.log('Dialog was closed without deleting the department.');
      }
    });
  }

  deleteDepartment(id: string): void {
    this.accountService
      .deleteAccountDepartmentById(id, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.getAllDepartments();
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }
}
