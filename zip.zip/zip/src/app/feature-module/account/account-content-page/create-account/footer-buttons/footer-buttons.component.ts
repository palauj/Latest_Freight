import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-footer-buttons',
  templateUrl: './footer-buttons.component.html',
  styleUrl: './footer-buttons.component.scss',
})
export class FooterButtonsComponent {
  @Input({ required: true }) backBtnRoute!: string;
  @Input() backBtnText: string = 'Back';
  @Input() nextBtnText: string = 'Next';
  @Input() nextBtnRoute!: string;

  @Output() nextBtnClick = new EventEmitter();

  onNextBtnClick(): void {
    this.nextBtnClick.emit(null);
  }
}
