import { Component, inject, Input, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { catchError, EMPTY, take } from 'rxjs';
import { routes } from 'src/app/core/core.index';
import { AddDesignation } from 'src/app/core/helpers/models/designation.model';
import { AccountService } from 'src/app/core/services/account/account.service';
import { DesignationDialogComponent } from '../designation-dialog/designation-dialog.component';
import { ConfirmationDialogComponent } from 'src/app/shared/dialogs/confirmation-dialog/confirmation-dialog.component';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { MatPaginator } from '@angular/material/paginator';
import { pageSelection } from 'src/app/core/helpers/models/common.model';
import { LoginUserData } from 'src/app/core/helpers/models/auth.model';

@Component({
  selector: 'app-location-designations',
  templateUrl: './designations.component.html',
  styleUrl: './designations.component.scss',
})
export class DesignationsComponent implements OnInit {
  @Input() locationId: string = '';
  @Input() accountId: string = '';
  public searchDataValue = '';
  public routes = routes;
  // pagination variables
  public lastIndex = 0;
  public pageSize = 10;
  public totalData = 0;
  public skip = 0;
  public limit: number = this.pageSize;
  authUser!: LoginUserData;
  public pageIndex = 0;
  public serialNumberArray: Array<number> = [];
  public currentPage = 1;
  public pageNumberArray: Array<number> = [];
  public pageSelection: Array<pageSelection> = [];
  public totalPages = 0;
  designationIds: string[] = [];

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  columnsToDisplay: string[] = ['action', 'designationName', 'status'];
  displayColumns: string[] = ['footer'];

  //** / pagination variables
  designations = new MatTableDataSource<AddDesignation>();
  selectedDesignationId!: string;
  private accountService = inject(AccountService);
  readonly dialog = inject(MatDialog);
  private toaster = inject(ToasterService);

  constructor() {}

  ngOnInit(): void {
    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);
    this.getAllDesignations();
  }

  ngAfterViewInit() {
    this.designations.paginator = this.paginator;
    this.designations.sort = this.sort;
  }

  private getAllDesignations(): void {
    this.accountService
      .getAccountDesignationList(this.locationId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.designations.data = response.data;
            this.totalData = response.data.length;
          }
        }
      });
  }

  // dialog
  addDesignation(): void {
    const dialogRef = this.dialog.open(DesignationDialogComponent, {
      width: '400px',
      data: {
        title: 'Add Designation',
        accountId: this.accountId,
        locationId: this.locationId,
        submitBtn: 'Submit',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllDesignations();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  editDesignation(id: string): void {
    const dialogRef = this.dialog.open(DesignationDialogComponent, {
      width: '400px',
      data: {
        title: 'Edit Designation',
        accountId: this.accountId,
        locationId: this.locationId,
        submitBtn: 'Update',
        closeBtn: 'Close',
        id: id,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllDesignations();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  openDeleteDialog(id: string): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '500px',
      data: {
        title: 'Delete Designation',
        submitBtn: 'Delete',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.deleteDesignation(id);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  deleteDesignation(id: string): void {
    this.accountService
      .deleteAccountDesignationById(id, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.getAllDesignations();
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }
}
