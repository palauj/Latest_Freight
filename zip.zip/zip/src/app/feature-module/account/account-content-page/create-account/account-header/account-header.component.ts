import { Component, OnInit } from '@angular/core';
import { StepsData } from 'src/app/core/helpers/constants/account.constant';

@Component({
  selector: 'app-account-header',
  templateUrl: './account-header.component.html',
  styleUrl: './account-header.component.scss',
})
export class AccountHeaderComponent implements OnInit {
  stepsData = StepsData.steps;
  isStepCompleted: boolean[] = [];
  currentStep!: number;

  ngOnInit(): void {
    this.stepsData.map((item) => {
      this.isStepCompleted.push(item.isStepCompleted);
      localStorage.setItem(
        'isStepCompleted',
        JSON.stringify(this.isStepCompleted)
      );
    });

    const currentStep = localStorage.getItem('currentStep');
    if (currentStep) this.currentStep = Number(currentStep);
  }
}
