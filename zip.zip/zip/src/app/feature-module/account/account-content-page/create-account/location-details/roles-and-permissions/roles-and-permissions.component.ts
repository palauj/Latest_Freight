import { Component, inject, Input, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { catchError, EMPTY, take } from 'rxjs';
import { routes } from 'src/app/core/core.index';
import { AccountService } from 'src/app/core/services/account/account.service';
import { ConfirmationDialogComponent } from 'src/app/shared/dialogs/confirmation-dialog/confirmation-dialog.component';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { AddRole } from 'src/app/core/helpers/models/role.model';
import { RoleDialogComponent } from '../role-dialog/role-dialog.component';
import { MatPaginator } from '@angular/material/paginator';
import { pageSelection } from 'src/app/core/helpers/models/common.model';
import { LoginUserData } from 'src/app/core/helpers/models/auth.model';

@Component({
  selector: 'app-roles-and-permissions',
  templateUrl: './roles-and-permissions.component.html',
  styleUrl: './roles-and-permissions.component.scss',
})
export class RolesAndPermissionsComponent implements OnInit {
  @Input() locationId: string = '';
  @Input() accountId: string = '';
  public searchDataValue = '';
  authUser!: LoginUserData;
  public routes = routes;
  // pagination variables
  public lastIndex = 0;
  public pageSize = 10;
  public totalData = 0;
  public skip = 0;
  public limit: number = this.pageSize;
  public pageIndex = 0;
  public serialNumberArray: Array<number> = [];
  public currentPage = 1;
  public pageNumberArray: Array<number> = [];
  public pageSelection: Array<pageSelection> = [];
  public totalPages = 0;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  columnsToDisplay: string[] = ['action', 'roleName', 'status'];
  roles = new MatTableDataSource<AddRole>();
  displayColumns: string[] = ['footer'];

  private accountService = inject(AccountService);
  readonly dialog = inject(MatDialog);
  private toaster = inject(ToasterService);

  constructor() {}

  ngOnInit(): void {
    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);
    this.getAllRoles();
  }

  ngAfterViewInit() {
    this.roles.paginator = this.paginator;
    this.roles.sort = this.sort;
  }

  private getAllRoles(): void {
    this.accountService
      .getAccountRoleList(this.locationId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.roles.data = response.data;
            this.totalData = response.data.length;
          }
        }
      });
  }

  // dialog
  addRole(): void {
    const dialogRef = this.dialog.open(RoleDialogComponent, {
      width: '400px',
      data: {
        title: 'Add Role',
        accountId: this.accountId,
        locationId: this.locationId,
        submitBtn: 'Submit',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllRoles();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  editRole(id: string): void {
    const dialogRef = this.dialog.open(RoleDialogComponent, {
      width: '400px',
      data: {
        title: 'Edit Role',
        accountId: this.accountId,
        locationId: this.locationId,
        submitBtn: 'Update',
        closeBtn: 'Close',
        id: id,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllRoles();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  openDeleteDialog(id: string): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '500px',
      data: {
        title: 'Delete Role',
        submitBtn: 'Delete',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.deleteRole(id);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  deleteRole(id: string): void {
    this.accountService
      .deleteAccountRoleById(id, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.getAllRoles();
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }
}
