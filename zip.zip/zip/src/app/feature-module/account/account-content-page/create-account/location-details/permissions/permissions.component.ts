import { Location } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { ActivatedRoute, Router } from '@angular/router';
import { forkJoin } from 'rxjs';
import { AccountService } from 'src/app/feature-module/account/account.service';
import { catchError, EMPTY, take } from 'rxjs';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
@Component({
  selector: 'app-permissions',
  templateUrl: './permissions.component.html',
  styleUrls: ['./permissions.component.scss'],
})
export class PermissionsComponent implements OnInit {
  pages: any[] = [];
  isLoading: boolean = false;
  role: any = {
    id: '',
    locationId: '',
    name: '',
    accountRoleId: '',
    userRoles: [],
    roleClaims: []
  };
  private location = inject(Location);
  private actionService = inject(AccountService)
  constructor(private activateRoute: ActivatedRoute,
    private router: Router,
    private toasterService: ToasterService
  ) {
    this.activateRoute.params.subscribe((params) => {
      this.role.id = params['id'];
      this.role.accountRoleId = params['id'];
    })
    this.activateRoute.queryParams.subscribe((params) => {
      this.role.locationId = params['locationId'];
      this.role.name = params['roleName'];
    })

  }

  // permissionSections: PermissionSection[] = [
  //   {
  //     name: 'Dashboard',
  //     permissions: [
  //       { label: 'View Statistics', selected: true },
  //       { label: 'Category Wise Graph', selected: true },
  //       { label: 'View Reminders', selected: true },
  //       { label: 'Source Wise Count', selected: true },
  //       { label: 'Status Wise Count', selected: true },
  //     ],
  //   },
  //   {
  //     name: 'Reports',
  //     permissions: [
  //       { label: 'View Interaction Report', selected: true },
  //       { label: 'View Open Report', selected: true },
  //       { label: 'View ReOpen Report', selected: true },
  //       { label: 'View GRP TAT Report', selected: true },
  //       { label: 'View Login Report', selected: true },
  //     ],
  //   },
  //   {
  //     name: 'Reminder',
  //     permissions: [
  //       { label: 'View Reminders', selected: true },
  //       { label: 'Add Reminder', selected: true },
  //       { label: 'Update Reminder', selected: true },
  //       { label: 'Delete Reminder', selected: true },
  //     ],
  //   },
  //   {
  //     name: 'Roles',
  //     permissions: [
  //       { label: 'View Roles', selected: true },
  //       { label: 'Add Role', selected: true },
  //       { label: 'Update Role', selected: true },
  //       { label: 'Delete Role', selected: true },
  //     ],
  //   },
  // ];
  ngOnInit(): void {
    this.getPageList();
    this.getRolePermissionsList();
  }

  // toggleAllPermissions(event: any) {
  //   const isChecked = event.target.checked;
  //   this.permissionSections.forEach((section) => {
  //     section.permissions.forEach((permission) => {
  //       permission.selected = isChecked;
  //     });
  //   });
  // }

  // toggleSectionPermissions(index: number, event: any) {
  //   const isChecked = event.target.checked;
  //   this.permissionSections[index].permissions.forEach((permission) => {
  //     permission.selected = isChecked;
  //   });
  // }

  // isSectionFullySelected(index: number): boolean {
  //   return this.permissionSections[index].permissions.every(
  //     (permission) => permission.selected
  //   );
  // }

  // isAllSelected(): boolean {
  //   return this.permissionSections.every((section) =>
  //     section.permissions.every((permission) => permission.selected)
  //   );
  // }

  // isSomeSelected(): boolean {
  //   return this.permissionSections.some((section) =>
  //     section.permissions.some((permission) => permission.selected)
  //   );
  // }

  goBack(): void {
    this.location.back();
  }
  getRolePermissionsList() {
    this.actionService.getRolePermissions(this.role?.accountRoleId).pipe().subscribe((res: any) => {
      this.role.roleClaims = res?.data?.roleClaims;
      this.role.locationId = res?.data?.locationId;
      this.role.accountRoleId = res?.data?.accountRoleId;
    })
  }
  // onPermissionChange() {
  //   // Custom logic if needed on individual permission change
  // }




  getPageList() {
    const namesToRemove = ['Master', 'Lookup Master', 'Status Master', 'Super Admin','Action','Pages'];
    const getAction = this.actionService.getActionList();
    const getPage = this.actionService.getPageList();
    forkJoin({ getAction, getPage }).subscribe((response: any) => {
      this.pages = response.getPage.data;
      this.pages = this.pages.map((p: any) => {
        const pageActions = response.getAction.data.filter((c: any) => c.pageId == p.id);
        const result = Object.assign({}, p, { pageActions: pageActions });
        return result;
      })
      if (this.role?.name !== 'Super Admin') {
        this.pages = this.pages.filter(item => !namesToRemove.includes(item.name))
      }
      // this.pages = this.pages.filter((e:any)=>e.name !="Master" || e.name!='Lookup Master' || e.name!='Status Master');
    })

  }
  onPageSelect(event: MatCheckboxChange, page: any) {
    if (event.checked) {
      page.pageActions.forEach((action: any) => {
        if (!this.checkPermission(action.id)) {
          this.role.roleClaims.push({
            roleId: this.role.id,
            claimType: action.code,
            claimValue: '',
            actionId: action.id,
          });
        }
      });
    } else {
      var actions = page.pageActions?.map((c: any) => c.id);
      this.role.roleClaims = this.role?.roleClaims?.filter((c: any) => actions.indexOf(c.actionId) < 0);
    }
  }



  checkPermission(actionId: string): boolean {
    const pageAction = this.role?.roleClaims?.find((c: any) => c.actionId === actionId);
    if (pageAction) {
      return true;
    } else {
      return false;
    }
  }
  selectAll(event: MatCheckboxChange) {
    if (event.checked) {
      this.isLoading = true
      this.pages.forEach(page => {
        page.pageActions.forEach((action: any) => {
          if (!this.checkPermission(action.id)) {
            this.role?.roleClaims?.push({
              roleId: this.role.id,
              claimType: action.code,
              claimValue: '',
              actionId: action.id
            });
          }
        });
      });
      this.isLoading = false;
    } else {
      this.isLoading = true
      this.role.roleClaims = [];
      this.isLoading = false

    }
  }

  onPermissionChange(flag: any, page: any, action: any) {
    if (flag.checked) {
      this.role.roleClaims.push({
        id: 0,
        roleId: this.role.id,
        claimType: action.code,
        claimValue: '',
        actionId: action.id,
      })
    } else {
      const roleClaimToRemove = this.role?.roleClaims?.find((c: any) => c.actionId === action.id);
      const index = this.role.roleClaims.indexOf(roleClaimToRemove, 0);
      if (index > -1) {
        this.role?.roleClaims?.splice(index, 1);
      }
    }
  }

  saveRole() {
    if (this.role?.roleClaims.length) {
      this.isLoading = true;
      let data = {
        locationId: this.role?.locationId,
        accountRoleId: this.role?.accountRoleId,
        roleClaims: this.role?.roleClaims
      }
      this.actionService.updateRolePermissions(data).pipe(
        catchError((error: any) => {
          this.isLoading = false;
          return EMPTY;
        }),
        take(1)
      ).subscribe((res: any) => {
        if (res?.statusCode < 399) {
          this.toasterService.typeSuccess('Permissions Added Successfully');
          this.isLoading = false;
          this.router.navigate(['admin/accounts/location-details', this.role?.locationId],
            { queryParams: { tab: 'permissions' } })
        }
      })
    } else {
      this.isLoading = false;
      alert('Please add at least one permission')
    }

  }


}










interface Permission {
  label: string;
  selected: boolean;
}

interface PermissionSection {
  name: string;
  permissions: Permission[];
}
