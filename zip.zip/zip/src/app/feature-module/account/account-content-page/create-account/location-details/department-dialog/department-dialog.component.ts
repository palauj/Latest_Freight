import { Component, inject, Inject } from '@angular/core';
import {
  AbstractControl,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { catchError, EMPTY, take } from 'rxjs';
import { LoginUserData } from 'src/app/core/helpers/models/auth.model';
import {
  AddDepartment,
  Department,
} from 'src/app/core/helpers/models/department.model';
import { AccountService } from 'src/app/core/services/account/account.service';
import { DropdownService } from 'src/app/core/services/dropdown/dropdown.service';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';

@Component({
  selector: 'app-department-dialog',
  templateUrl: './department-dialog.component.html',
  styleUrls: ['./department-dialog.component.scss'],
})
export class DepartmentDialogComponent {
  isSubmitted = false;
  departmentForm!: FormGroup;
  departmentId!: string;
  departmentData!: AddDepartment;
  authUser!: LoginUserData;
  departmentList: Department[] = [];

  private dropdownService = inject(DropdownService);
  private accountService = inject(AccountService);
  private toaster = inject(ToasterService);
  isEdit = false;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<DepartmentDialogComponent>
  ) {}

  ngOnInit(): void {
    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);
    this.getMasterDepartments();
    if (this.data.id) {
      this.isEdit = true;
      this.getDepartmentById(this.data.id);
    }
    this.departmentFormInit();
  }

  private getDepartmentById(id: string): void {
    this.accountService
      .getAccountDepartmentById(id)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.departmentData = response.data;
            this.departmentForm.patchValue({
              departmentName: response.data.departmentId,
              isActive: response.data.isActive,
            });

            if (response.data.departmentId) {
              this.departmentForm.get('departmentName')?.disable();
            } else {
              this.departmentForm.get('departmentName')?.enable();
            }
          }
        }
      });
  }

  private departmentFormInit(): void {
    this.departmentForm = new FormGroup({
      departmentName: new FormControl('', [Validators.required]),
      isActive: new FormControl(true, [Validators.required]),
    });
  }

  get c(): { [key: string]: AbstractControl } {
    return this.departmentForm.controls;
  }

  private getMasterDepartments(): void {
    this.dropdownService
      .getMasterDepartmentDropdownList()
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.departmentList = response.data;
          }
        }
      });
  }

  close(): void {
    this.dialogRef.close();
  }

  submit(): void {
    this.isSubmitted = true;
    if (this.departmentForm.invalid) {
      this.departmentForm.markAllAsTouched(); // This will trigger validation messages if any field is invalid
      return;
    }

    const departmentPayload = {
      id: this.data.id ? this.data.id : null,
      departmentId: this.departmentForm.value.departmentName
        ? this.departmentForm.value.departmentName
        : this.departmentData.departmentId,
      accountId: this.data.accountId ? this.data.accountId : '',
      locationId: this.data.locationId ? this.data.locationId : '',
      edit: this.data.id ? 1 : 0,
      isActive: this.departmentForm.value.isActive,
      userId: this.authUser.employeeId,
    };
    this.accountService
      .addAccountDepartment(departmentPayload)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.dialogRef.close(response);
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }
}
