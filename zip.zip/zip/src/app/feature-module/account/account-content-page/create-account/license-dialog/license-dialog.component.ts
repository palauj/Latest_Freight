import { Component, Inject, inject } from '@angular/core';
import {
  AbstractControl,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { catchError, EMPTY, map, startWith, take } from 'rxjs';
import { LicensePlanList } from 'src/app/core/helpers/models/account.model';
import { LoginUserData } from 'src/app/core/helpers/models/auth.model';

import { AccountService } from 'src/app/core/services/account/account.service';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
@Component({
  selector: 'app-license-dialog',
  templateUrl: './license-dialog.component.html',
  styleUrl: './license-dialog.component.scss',
})
export class LicenseDialogComponent {
  isLicenseSubmitted = false;
  licenseForm!: FormGroup;
  accountId!: string;
  licenseId!: string;
  authUser!: LoginUserData;

  private accountService = inject(AccountService);
  private toaster = inject(ToasterService);

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<LicenseDialogComponent>
  ) {}

  ngOnInit(): void {
    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);
    this.licenseFormInit();
    if (this.data) {
      this.accountId = this.data.accountId;
      this.licenseId = this.data.licenseId;
      this.patchFormValues(this.data.licenseData);
    }
  }

  patchFormValues(data: LicensePlanList): void {
    this.licenseId = data ? data.licenseId : '';
    this.licenseForm.patchValue({
      users: data.noOfUser,
      startDate: new Date(data.licenseStartDate),
      endDate: new Date(data.licenseEndDate),
      licenseType: data.licenseType,
      projects: data.noOfProject,
    });
  }

  private licenseFormInit(): void {
    this.licenseForm = new FormGroup({
      users: new FormControl('', Validators.required),
      startDate: new FormControl('', Validators.required),
      endDate: new FormControl('', Validators.required),
      licenseType: new FormControl('', Validators.required),
      projects: new FormControl('', Validators.required),
    });
  }

  get l(): { [key: string]: AbstractControl } {
    return this.licenseForm.controls;
  }

  close(): void {
    this.dialogRef.close();
  }

  submit(): void {
    this.isLicenseSubmitted = true;

    if (this.licenseForm.invalid) {
      return;
    }

    const payload = {
      licenseId: this.licenseId ? this.licenseId : '',
      accountId: this.accountId ? this.accountId : '',
      licenseType: this.licenseForm.value.licenseType,
      licenseStartDate: this.licenseForm.value.startDate,
      licenseEndDate: this.licenseForm.value.endDate,
      noOfUser: Number(this.licenseForm.value.users),
      noOfProject: Number(this.licenseForm.value.projects),
      userId: this.authUser.employeeId,
    };

    this.accountService
      .addLicenseDetails(payload)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.data.success && response.statusCode === 200) {
            this.dialogRef.close(true);
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }
}
