import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpService } from 'src/app/core/services/http/http.service';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
  private http = inject(HttpService);
  constructor() { }

  public getPageList(): Observable<any[]> {
    const url = `/api/Page/GetPageList`
    return this.http.get(url);
  }

  public getActionList(): Observable<any[]> {
    const url = `/api/Action/GetActionRecordList`;
    return this.http.get(url);
  }
  
  
  public getRolePermissions(id:string): Observable<any[]> {
    const url = `/api/RoleClaim/GetRoleClaimsDataByAccountRoleId?accountRoleId=${id}`;
    return this.http.get(url);
  }
  
  public updateRolePermissions(data:any): Observable<any[]> {
    const url = `/api/RoleClaim/UpsertRoleClaimRecord`;
    return this.http.post(url,data);
  }

 

}
