import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AccountModuleRoutingModule } from './account-module-routing.module';
import { MatSortModule } from '@angular/material/sort';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AccountListComponent } from './account-list/account-list.component';
import { AccountComponent } from './account.component';
import { AccountContentPageComponent } from './account-content-page/account-content-page.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { AccountDetailsComponent } from './account-details/account-details.component';

import { LocationDialogComponent } from './account-content-page/create-account/location-dialog/location-dialog.component';
import { LocationDetailsComponent } from './account-content-page/create-account/location-details/location-details.component';
import { ProjectsComponent } from './account-content-page/create-account/location-details/projects/projects.component';
import { EmployeesMatrixComponent } from './account-content-page/create-account/location-details/employees-matrix/employees-matrix.component';
import { DepartmentsComponent } from './account-content-page/create-account/location-details/departments/departments.component';
import { TeamsComponent } from './account-content-page/create-account/location-details/teams/teams.component';
import { DesignationsComponent } from './account-content-page/create-account/location-details/designations/designations.component';
import { DesignationDialogComponent } from './account-content-page/create-account/location-details/designation-dialog/designation-dialog.component';
import { DepartmentDialogComponent } from './account-content-page/create-account/location-details/department-dialog/department-dialog.component';
import { TeamDialogComponent } from './account-content-page/create-account/location-details/team-dialog/team-dialog.component';
import { RoleDialogComponent } from './account-content-page/create-account/location-details/role-dialog/role-dialog.component';
import { PermissionsComponent } from './account-content-page/create-account/location-details/permissions/permissions.component';
import { TeamMemberDialogComponent } from './account-content-page/create-account/location-details/team-member-dialog/team-member-dialog.component';
import { TeamMemberComponent } from './account-content-page/create-account/location-details/team-member/team-member.component';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { AccessComponent } from './account-content-page/create-account/access/access.component';
import { LicenseComponent } from './account-content-page/create-account/license/license.component';
import { LocationListComponent } from './account-content-page/create-account/location-list/location-list.component';
import { AddressComponent } from './account-content-page/create-account/address/address.component';
import { BasicDetailsComponent } from './account-content-page/create-account/basic-details/basic-details.component';
import { SocialProfileComponent } from './account-content-page/create-account/social-profile/social-profile.component';
import { FooterButtonsComponent } from './account-content-page/create-account/footer-buttons/footer-buttons.component';
import { AccountHeaderComponent } from './account-content-page/create-account/account-header/account-header.component';
import { CreateAccountComponent } from './account-content-page/create-account/create-account.component';
import { BasicInfoDialogComponent } from './account-content-page/create-account/basic-info-dialog/basic-info-dialog.component';
import { LicenseDialogComponent } from './account-content-page/create-account/license-dialog/license-dialog.component';
import { AddCategoryComponent } from './account-content-page/create-account/location-details/category/add-category/add-category.component';

@NgModule({
  declarations: [
    AccountListComponent,
    AccountComponent,
    AccountContentPageComponent,
    AccountDetailsComponent,
    ProjectsComponent,
    EmployeesMatrixComponent,
    DepartmentsComponent,
    TeamsComponent,
    LocationDialogComponent,
    LocationDetailsComponent,
    DesignationsComponent,
    DesignationDialogComponent,
    DepartmentDialogComponent,
    TeamDialogComponent,
    RoleDialogComponent,
    AddCategoryComponent,
    PermissionsComponent,
    TeamMemberDialogComponent,
    TeamMemberComponent,
    AccountHeaderComponent,
    AccessComponent,
    AddressComponent,
    LicenseComponent,
    LocationListComponent,
    BasicDetailsComponent,
    SocialProfileComponent,
    FooterButtonsComponent,
    CreateAccountComponent,
    BasicInfoDialogComponent,
    LicenseDialogComponent,
  ],

  imports: [
    CommonModule,
    AccountModuleRoutingModule,
    MatSortModule,
    MatCheckboxModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
  ],
})
export class AccountModuleModule {}
