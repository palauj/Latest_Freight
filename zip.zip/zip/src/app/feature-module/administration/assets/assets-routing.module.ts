import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AssetsComponent } from './assets.component';
import { AssetsCategoryComponent } from './assets-category/assets-category.component';
import { AssetsDetailsComponent } from './assets-details/assets-details.component';
import { AssetsMainComponent } from './assets-main/assets-main.component';
import { AssetsNewComponent } from './assets-new/assets-new.component';
import { AssetsReportsComponent } from './assets-reports/assets-reports.component';
import { AnalyticsComponent } from './analytics/analytics.component';
import { CostManagementComponent } from './cost-management/cost-management.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RegistrationComponent } from './registration/registration.component';
import { TrackingComponent } from './tracking/tracking.component';
import { WorkflowComponent } from './workflow/workflow.component';
import { AssetsDetailComponent } from './assets-detail/assets-detail.component';

const routes: Routes = [
  { 
    path: '', 
    component: AssetsComponent,
    children: [
      // { path: "assets-category", component: AssetsCategoryComponent },
      // { path: "assets-details", component: AssetsDetailsComponent },
      // { path: "assets-main", component: AssetsMainComponent },
      // { path: "assets-new", component: AssetsNewComponent },
      // { path: "assets-reports", component: AssetsReportsComponent },
      { path: 'assets-details/:id', component: AssetsDetailComponent },

      { path: "assets-dashboard", component: DashboardComponent },
      { path: "assets-registration", component: RegistrationComponent },
      { path: "assets-track", component: TrackingComponent },
      { path: "assets-cost", component: CostManagementComponent },
      { path: "assets-workflow", component: WorkflowComponent },
      { path: "assets-analytics", component: AnalyticsComponent },
      { path: "assets-report", component: AssetsReportsComponent },
    ] 
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AssetsRoutingModule { }
