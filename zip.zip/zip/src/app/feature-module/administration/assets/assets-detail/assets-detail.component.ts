import { Component, inject, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Assets } from '../registration/assets.model';
import { ActivatedRoute, Router } from '@angular/router';
import { NotesDialogComponent } from 'src/app/feature-module/employee/projects/notes-dialog/notes-dialog.component';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AssetsConstant } from 'src/app/core/helpers/constants/common.constant';
import { ActivityService } from 'src/app/core/services/activity/activity.service';
import { LeadService } from 'src/app/feature-module/crm/leads/lead.service';
import {
  AssetsData,
  LoginUserData,
} from 'src/app/core/helpers/models/auth.model';
import { NotesService } from 'src/app/core/services/notes/notes.service';
import { catchError, EMPTY, take } from 'rxjs';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { ConfirmationDialogComponent } from 'src/app/shared/dialogs/confirmation-dialog/confirmation-dialog.component';
import { DocumentsService } from 'src/app/core/services/documents/documents.service';
import { NoteList, ProjectDocuments } from 'src/app/core/helpers/models/project.model';
import { PreviewDialogComponent } from 'src/app/shared/dialogs/preview-dialog/preview-dialog.component';
import { DepartmentContent } from 'src/app/core/helpers/constants/modals.constants';
import { AssetsServiceService } from '../assets-service.service';
import { Activities } from 'src/app/core/helpers/models/common.model';

@Component({
  selector: 'app-assets-detail',
  templateUrl: './assets-detail.component.html',
  styleUrl: './assets-detail.component.scss',
})
export class AssetsDetailComponent implements OnInit {
  projectDocuments: ProjectDocuments[] = [];
  showForbiddenMessage: boolean = false;
  forbiddenMessage: string = '';
  multipleFiles: File[] = [];
  fileSrc: string[] = [];
  isfile: boolean = false;
  isSuccess = false;
  notesList: NoteList[] = [];
  assetsActivities:  Activities[] = [];
  id: string = '';
  public companyId: string = '';
  public accountId: string = '';
  public locationId: string = '';
  totalRecords!: number;
  public router = inject(Router);
  assetsDetail!: AssetsData;
  authUser!: LoginUserData;
  private notesService = inject(NotesService);
  private toaster = inject(ToasterService);
  private documentService = inject(DocumentsService);

  constructor(
    public dialog: MatDialog,
    private assetsService: AssetsServiceService,
    private leadService: LeadService,
    private route: ActivatedRoute,
    private activityService: ActivityService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.route.params.subscribe((data) => {
      this.id = data['id'];
      let userData = JSON.parse(localStorage.getItem('authObj') || '');
      this.accountId = userData?.accountId;
      this.locationId = userData?.employeeLocation[0]?.locationId;
      // this.userId = userData.employeeId
    });
  }

  ngOnInit(): void {
    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);
    this.getAssetsDetailById();
    this.fetchAssetsActivities();
    if (this.id) {
      this.getNotesList();
      this.getDocumentList();
    }
  }

  getAssetsDetailById() {
    this.assetsService
      .getAssetsDetailById(this.id)
      .pipe()
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode < 399) {
            this.assetsDetail = response?.data;
          } else {
            console.error('this Assets is not found');
          }
        }
      });
  }
  private getDocumentList(): void {
    this.documentService
      .getDocumentList(
        1,
        50,
        this.id,
        this.authUser.accountId,
        this.authUser.employeeLocation[0].locationId
      )
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.projectDocuments = response.data.documentList;
          }
        }
      });
  }
  createNote(): void {
    let userDetail = JSON.parse(localStorage.getItem('authObj') || '');
    const dialogRef = this.dialog.open(NotesDialogComponent, {
      width: '500px',
      data: {
        title: 'Add Note',
        submitBtn: 'Create',
        closeBtn: 'Close',
        id: this.id,
        accountId: userDetail.accountId,
        accountName: userDetail.accountName,
        locationId: userDetail.employeeLocation[0].locationId,
        locationName: userDetail.employeeLocation[0].locationName,
        relatedToId: this.id,
            activityRelatedTo: AssetsConstant.relatedTo,
        relatesTo: AssetsConstant.relatedTo,
        relatedToName: this.assetsDetail.transactionNumber,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.createActivity('Added', 'ADD', 'note');
        this.getNotesList();
        this.fetchAssetsActivities();
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }
  openDeleteNoteDialog(id: string): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '500px',
      data: {
        title: `Delete Note`,
        submitBtn: 'Delete',
        closeBtn: 'Close',
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.deleteNote(id);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }

  deleteNote(id: string): void {
    this.notesService
      .deleteNote(id, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200 || response.statusCode === 201) {
            this.createActivity('deleted', 'DELETE', 'note');
            this.getNotesList();
            this.fetchAssetsActivities();
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
            return;
          }
        }
      });
  }
  getNotesList(): void {
    this.notesList = [];
    this.notesService
      .getAllNotes(
        this.id,
        this.authUser.accountId,
        this.authUser.employeeLocation[0].locationId,
        1,
        50
      )
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.notesList = response.data?.notesList.map((note: any) => ({
              ...note,
              backgroundColor: this.generateRandomColor(), // Add a random background color
            }));
            this.totalRecords = response.data.totalRecords;
          }
        }
      });
  }
  generateRandomColor(): string {
    const r = Math.floor(Math.random() * 156) + 100; // Red: Range 100-255
    const g = Math.floor(Math.random() * 156) + 100; // Green: Range 100-255
    const b = Math.floor(Math.random() * 156) + 100; // Blue: Range 100-255
    return `rgba(${r}, ${g}, ${b}, 0.2)`; // Add opacity (0.8 for a subtle effect)
  }
  createActivity(status: string, action: string, type: string): void {
    let userDetail = JSON.parse(localStorage.getItem('authObj') || '');
    let description = `${type} ${status} by ${userDetail?.employeeName}`;
    let data = {
      activityActionName: action,
      activityStatus: action === 'ADD' ? 'S' : action.charAt(0),
      activityDescription: description,
      activityRelatedToId: this.id,
      activityRelatedTo: AssetsConstant.relatedTo,
      activityRelatedToName: this.assetsDetail.productName,
      accountId: userDetail.accountId,
      accountName: userDetail.accountName,
      locationId: userDetail.employeeLocation[0].locationId,
      locationName: userDetail.employeeLocation[0].locationName,
      userId: userDetail?.employeeId,
    };
    this.activityService
      .addActivity(data)
      .pipe(
        catchError((error: any) => {
          console.error('Error saving documents:', error);
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((res) => {
        if (res?.statusCode < 399) {
          this.toaster.typeSuccess(res?.message);
        } else {
          this.toaster.typeError(res?.message);
        }
      });
  }
  fetchAssetsActivities(): void {
     this.activityService
          .getActivityList(this.id, AssetsConstant.relatedTo, 1, 50)
          .subscribe({
            next: (response) => {
              if (response.statusCode === 200) {
                this.assetsActivities = response.data.activityHistoryList;
                this.showForbiddenMessage = false; // Hide forbidden message
              } else {
                console.error('Failed to fetch lead activities:', response.message);
              }
            },
            error: (error) => {
              if (error.status === 403) {
                this.showForbiddenMessage = true;
                this.forbiddenMessage = 'Access Denied: You do not have permission to view this data.';
              } else {
                console.error('Error fetching lead activities:', error);
              }
            }
          });
        }


   onMultipleSelect(event: any): void {
      this.multipleFiles = event; 
  
      this.fileSrc = [];
      let filesRead = 0;
  
      // Loop through the selected files and read them
      this.multipleFiles.forEach((file, index) => {
        const reader = new FileReader();
  
        reader.onload = () => {
          this.fileSrc[index] = reader.result as string;
          filesRead++;
          // Once all files are read, proceed with further processing
          if (filesRead === this.multipleFiles.length) {
            this.isfile = this.fileSrc.length > 0;
  
            if (this.fileSrc.length > 0) {
              const formData = new FormData();
  
              // Append files to formData
              Array.from(this.multipleFiles).forEach((file) => {
                formData.append('Documents', file, file.name);
              });
  
              formData.append('Id', this.id ? this.id : '');
              formData.append('RelatedToId', this.id);
              formData.append('RelatedTo', AssetsConstant.relatedTo);
              formData.append('RelatedToName', AssetsConstant.relatedToName);
              formData.append('AccountId', this.authUser.accountId);
              formData.append(
                'LocationId',
                this.authUser.employeeLocation[0].locationId
              );
  
              this.documentService
                .saveAndUpdateDocument(formData)
                .pipe(
                  catchError((error: any) => {
                    console.error('Error saving documents:', error);
                    return EMPTY; // Gracefully handle error
                  }),
                  take(1)
                )
                .subscribe((response: any) => {
                  if (response && response.message) {
                    if (
                      response.statusCode === 200 ||
                      response.statusCode === 201
                    ) {
                      this.isSuccess = response.data.success;
                      this.createActivity('added', 'ADD', 'Document');
                      this.getDocumentList(); // Update document list
                      this.fetchAssetsActivities();
                      this.toaster.typeSuccess(
                        response.data ? response.data.message : response.message,
                        'Success'
                      );
                    } else {
                      this.toaster.typeError(
                        response.data ? response.data.message : response.message,
                        'Error'
                      );
                    }
                  }
                });
            }
          }
        };
        reader.onerror = (error) => {
          console.error('Error reading file:', error);
        };
  
        reader.readAsDataURL(file); // Read the file as data URL
      });
    }  
  
  
  convertIntoNumber(value: string): number {
    return Number(value);
  }
  
  openDeleteDocumentDialog(id: string, flag: string): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '500px',
      data: {
        title: `Delete ${flag}`,
        submitBtn: 'Delete',
        closeBtn: 'Close',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.onRemoveMultiple(id);
      } else {
        // console.log('Dialog was closed without adding a department.');
      }
    });
  }
  // Handle file removal
  onRemoveMultiple(id: string): void {
    this.documentService
      .deleteDocumentById(id, this.authUser.employeeId)
      .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.createActivity('deleted', 'DELETE', 'Document');
            this.getDocumentList();
            this.fetchAssetsActivities();
            this.toaster.typeSuccess(
              response.data ? response.data.message : response.message,
              'Success'
            );
          } else {
            this.toaster.typeError(
              response.data ? response.data.message : response.message,
              'Error'
            );
          }
        }
      });
  }
  previewDoc(event: { file: ProjectDocuments; flag: string }): any {
    const { file, flag } = event;
    if (flag === 'download') {
      this.documentService
        .getDownloadViewDocumentById(file?.id, flag)
        .pipe(
          catchError((error: any) => {
            return EMPTY;
          }),
          take(1)
        )
        .subscribe((pdfBlob: any) => {
          let receivedData = new Blob([pdfBlob], {
            type: file?.documentExtension,
          });
          const url = window.URL.createObjectURL(receivedData);
          const link = document.createElement('a');

          link.href = url;
          link.download = file?.documentFileName;
          link.click();
          URL.revokeObjectURL(url);
        });
    } else {
      const dialogRef = this.dialog.open(PreviewDialogComponent, {
        width: '90vw',
        height: '90vh',

        data: {
          title: 'Preview',
          file: file,
          submitBtn: 'Submit',
          closeBtn: 'Close',
        },
      });

      dialogRef.afterClosed().subscribe((result) => {
        if (result) {
          // console.log('Department added:', result);
        } else {
          // console.log('Dialog was closed without adding a department.');
        }
      });
    }
  }
  openDeleteDialog(id: string): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '500px',
      data: {
        title: `Delete Document`,
        submitBtn: 'Delete',
        closeBtn: 'Close',
      },
    });

}
}
