import { Component, OnInit } from '@angular/core';
import { Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import {
  DataService,
  apiResultFormat,
  getAssets,
  routes,
} from 'src/app/core/core.index';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { pageSelection } from 'src/app/core/helpers/models/common.model';

@Component({
  selector: 'app-assets-main',
  templateUrl: './assets-main.component.html',
  styleUrls: ['./assets-main.component.scss'],
})
export class AssetsMainComponent implements OnInit {
  selected1 = '1';
  public statusValue!: string;
  public assetsForm!: FormGroup;
  public allAssets: Array<getAssets> = [];
  public searchDataValue = '';
  dataSource!: MatTableDataSource<getAssets>;
  public routes = routes;
  // pagination variables
  public lastIndex = 0;
  public pageSize = 10;
  public totalData = 0;
  public skip = 0;
  public limit: number = this.pageSize;
  public pageIndex = 0;
  public serialNumberArray: Array<number> = [];
  public currentPage = 1;
  public pageNumberArray: Array<number> = [];
  public pageSelection: Array<pageSelection> = [];
  public totalPages = 0;
  //** / pagination variables

  constructor(private formBuilder: FormBuilder, private data: DataService) {}

  ngOnInit() {
    this.getTableData();
    this.addAssetFormInit();
  }

  private addAssetFormInit(): void {
    this.assetsForm = new FormGroup({
      account: new FormControl('', Validators.required),
      installationDate: new FormControl('', Validators.required),
      assetName: new FormControl('', Validators.required),
      assetId: new FormControl('', Validators.required),
      purchaseDate: new FormControl('', Validators.required),
      poNumber: new FormControl('', Validators.required),
      warrantyStartDate: new FormControl('', Validators.required),
      warrantyEndDate: new FormControl('', Validators.required),
      manufacturer: new FormControl('', Validators.required),
      model: new FormControl('', Validators.required),
      serialNo: new FormControl('', Validators.required),
      supplier: new FormControl('', Validators.required),
      condition: new FormControl('', Validators.required),
      warranty: new FormControl('', Validators.required),
      value: new FormControl('', Validators.required),
      assetUser: new FormControl('', Validators.required),
      status: new FormControl('', Validators.required),
      description: new FormControl('', Validators.required),
    });
  }

  //getting the status value
  getStatus(data: string) {
    this.statusValue = data;
  }

  private getTableData(): void {
    this.allAssets = [];
    this.serialNumberArray = [];

    this.data.getAssets().subscribe((res: apiResultFormat) => {
      this.totalData = res.totalData;
      res.data.map((res: getAssets, index: number) => {
        const serialNumber = index + 1;
        if (index >= this.skip && serialNumber <= this.limit) {
          res.id = serialNumber;
          this.allAssets.push(res);
          this.serialNumberArray.push(serialNumber);
        }
      });
      this.dataSource = new MatTableDataSource<getAssets>(this.allAssets);
      this.calculateTotalPages(this.totalData, this.pageSize);
    });
  }

  public sortData(sort: Sort) {
    const data = this.allAssets.slice();

    /* eslint-disable @typescript-eslint/no-explicit-any */
    if (!sort.active || sort.direction === '') {
      this.allAssets = data;
    } else {
      this.allAssets = data.sort((a: any, b: any) => {
        const aValue = (a as any)[sort.active];
        const bValue = (b as any)[sort.active];
        return (aValue < bValue ? -1 : 1) * (sort.direction === 'asc' ? 1 : -1);
      });
    }
  }

  public searchData(value: string): void {
    this.dataSource.filter = value.trim().toLowerCase();
    this.allAssets = this.dataSource.filteredData;
  }

  public getMoreData(event: string): void {
    if (event === 'next') {
      this.currentPage++;
      this.pageIndex = this.currentPage - 1;
      this.limit += this.pageSize;
      this.skip = this.pageSize * this.pageIndex;
      this.getTableData();
    } else if (event === 'previous') {
      this.currentPage--;
      this.pageIndex = this.currentPage - 1;
      this.limit -= this.pageSize;
      this.skip = this.pageSize * this.pageIndex;
      this.getTableData();
    }
  }

  public moveToPage(pageNumber: number): void {
    this.currentPage = pageNumber;
    this.skip = this.pageSelection[pageNumber - 1].skip;
    this.limit = this.pageSelection[pageNumber - 1].limit;
    if (pageNumber > this.currentPage) {
      this.pageIndex = pageNumber - 1;
    } else if (pageNumber < this.currentPage) {
      this.pageIndex = pageNumber + 1;
    }
    this.getTableData();
  }

  public changePageSize(): void {
    this.pageSelection = [];
    this.limit = this.pageSize;
    this.skip = 0;
    this.currentPage = 1;
    this.getTableData();
  }

  private calculateTotalPages(totalData: number, pageSize: number): void {
    this.pageNumberArray = [];
    this.totalPages = totalData / pageSize;
    if (this.totalPages % 1 !== 0) {
      this.totalPages = Math.trunc(this.totalPages + 1);
    }
    for (let i = 1; i <= this.totalPages; i++) {
      const limit = pageSize * i;
      const skip = limit - pageSize;
      this.pageNumberArray.push(i);
      this.pageSelection.push({ skip: skip, limit: limit });
    }
  }
}
