import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-report-generation',
  templateUrl: './report-generation.component.html',
  styleUrl: './report-generation.component.scss'
})
export class ReportGenerationComponent {

}
