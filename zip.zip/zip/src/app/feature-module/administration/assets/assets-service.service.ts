import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpService } from 'src/app/core/services/http/http.service';

@Injectable({
  providedIn: 'root'
})
export class AssetsServiceService {
 private http = inject(HttpService);
  constructor() { }
  public getAssetsList(data: any, relatedToId: any): Observable<any[]> {
    let param = `PageNumber=${data?.pageNo}&PageSize=${data?.pageSize}`;
    if (data?.search) param += `&SearchQuery=${data?.search}`;
    const url = `/api/Assets/GetAssetList?relatedToId=${""}&${param}`;
    return this.http.get(url);
  }

    public addAssetsData(data: any): Observable<any> {
      const url = '/api/Assets/InsertAssetRecord';
      return this.http.post(url, data);
    }
  
    public updateAssetsDetails(data: any): Observable<any> {
      const url = '/api/Assets/UpdateAssetRecord';
      return this.http.put(url, data);
    }
  
    public deleteAssetsRecord(assetId: string, userId: string): Observable<any> {
      const url = `/api/Assets/DeleteAssetRecordById?assetId=${assetId}&userId=${userId}`;
      return this.http.delete(url);
    }
    

    public getAssetsListCount(accountId: string, locationId: string){
      const url = `/api/Assets/GetAssetsCount?accountId=${accountId}&locationId=${locationId}`;
      return this.http.get(url);
    }
    public getAssetsDetailById(id: any): Observable<any[]> {
      const url = `/api/Assets/GetAssetDataByAssetId?assetId=${id}`;
      return this.http.get(url);
    }

    public getAssetsDetails(fromDate: string, toDate: string, accountId: string, locationId: string ){
      const url = `/api/Assets/GetAssetsDetail?fromDate=${fromDate}&toDate=${toDate}&accountId=${accountId}&locationId=${locationId}`;
      return this.http.get(url);
    }
    public getAssetDetailForLocation(){
      const url ='/api/Assets/GetAssetDetailForLocation';
      return this.http.get(url);
    }
}
