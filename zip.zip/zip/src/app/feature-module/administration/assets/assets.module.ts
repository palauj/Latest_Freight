import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { AssetsRoutingModule } from './assets-routing.module';
import { AssetsComponent } from './assets.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { AssetsCategoryComponent } from './assets-category/assets-category.component';
import { AssetsDetailsComponent } from './assets-details/assets-details.component';
import { AssetsNewComponent } from './assets-new/assets-new.component';
import { AssetsReportsComponent } from './assets-reports/assets-reports.component';
import { AssetsMainComponent } from './assets-main/assets-main.component';
import { AnalyticsComponent } from './analytics/analytics.component';
import { CostManagementComponent } from './cost-management/cost-management.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RegistrationComponent } from './registration/registration.component';
import { ReportGenerationComponent } from './report-generation/report-generation.component';
import { TrackingComponent } from './tracking/tracking.component';
import { WorkflowComponent } from './workflow/workflow.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddTrackComponent } from './tracking/add-track/add-track.component';
import { AddCostComponent } from './cost-management/add-cost/add-cost.component';
import { AddWorkflowComponent } from './workflow/add-workflow/add-workflow.component';
import { AddAssetsRegistrationComponent } from './registration/add-assets-registration/add-assets-registration.component';
import { AddAssetsAnalyticsComponent } from './analytics/add-assets-analytics/add-assets-analytics.component';
import { AssetsDetailComponent } from './assets-detail/assets-detail.component';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from '@angular/material/tabs';
import { FileUploadModule } from 'primeng/fileupload';
import { EditorModule } from 'primeng/editor';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { ForbiddenIssueComponent } from 'src/app/shared/common/forbidden-issue/forbidden-issue.component';


@NgModule({
  declarations: [
    AssetsComponent,
    AssetsCategoryComponent,
    AssetsDetailsComponent,
    AssetsNewComponent,
    AssetsReportsComponent,
    AssetsMainComponent,
    DashboardComponent,
    RegistrationComponent,
    TrackingComponent,
    CostManagementComponent,
    WorkflowComponent,
    AnalyticsComponent,
    ReportGenerationComponent,
    AddTrackComponent,
    AddCostComponent,
    AddWorkflowComponent,
    AddAssetsRegistrationComponent,
    AddAssetsAnalyticsComponent,
    AssetsDetailComponent,
     
  ],
  imports: [
    CommonModule,
    AssetsRoutingModule,
    SharedModule,
    ReactiveFormsModule,
    FormsModule,
    MatDialogModule,
    MatTabsModule,
    MatPaginatorModule,
    MatSelectModule,
    FileUploadModule,
     EditorModule,
     MatDatepickerModule,
     MatFormFieldModule,
     MatNativeDateModule,
  ],
  providers: [DatePipe,
     { provide: MAT_DIALOG_DATA, useValue: {} },
        { provide: MatDialogRef, useValue: {} },
  ],
})
export class AssetsModule { }
