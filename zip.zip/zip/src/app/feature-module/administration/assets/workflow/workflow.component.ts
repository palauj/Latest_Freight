import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { catchError, EMPTY, take } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { DropdownService } from 'src/app/core/services/dropdown/dropdown.service';
import { ToastrService } from 'ngx-toastr';
import { CategoryModalComponent } from 'src/app/feature-module/master/category/category-modal/category-modal.component';
import { AddCostComponent } from '../cost-management/add-cost/add-cost.component';
import { Category } from 'src/app/core/helpers/models/role.model';

@Component({
  selector: 'app-workflow',
  templateUrl: './workflow.component.html',
  styleUrl: './workflow.component.scss',
   animations: [
      trigger('detailExpand', [
        state('collapsed', style({ height: '0px', minHeight: '0' })),
        state('expanded', style({ height: '*' })),
        transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
      ]),
    ],
})

 
export class WorkflowComponent implements OnInit
  {
   
 categories:Category[] =[];
  pageSize:number=10;
  totalCount:number=0
  pageNo:number=1;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  displayColumns: string[] = ["footer"];
  columnsToDisplay: string[] =['act','categoryName', 'active', 'action'];
  // subCategoryColumnToDisplay: string[] = ['subcategory', 'name', 'description', 'action'];
  // // categoryColumnToDisplay: string[] = ['categoryName', 'active', 'action'];
   subCategoryColumnToDisplayInner: string[] =['categoryName', 'active', 'action'];
  subCategories: any[] = [];
  expandedElement: any | null;
  constructor( private dialog: MatDialog,
    private dropdownService: DropdownService,
    private cd: ChangeDetectorRef,
    private toastrService: ToastrService,
  ) { }


  ngOnInit(): void {
    this.getCategories();
   
  
  }
  // ngAfterViewInit() {
  //   this.sort?.sortChange.subscribe(() => this.paginator.pageIndex = 0);
  //   merge(this.sort?.sortChange, this.paginator.page)
  //     .pipe(take(1),
  //       tap(() => {
  //         this.paginator.pageIndex * this.paginator.pageSize;
  //         this.paginator.pageSize;
  //         this.sort.active + ' ' + this.sort.direction;
  //       //  api call here
  //       })
  //     )
  //     .subscribe();x`
  // }
  getCategories(): void {
    let param = {
      pageNo: this.pageNo,
      pageSize: this.pageSize,
      totalCount: this.totalCount,
      categoryType: 'Parent',
      parentId: ''
    };
    this.dropdownService.getCategoryMasterList(param).subscribe((response: any) => {
      this.categories = response.data?.categoryMasterList;
      
    });
    // FIXME change the product api service with interaction category
   
  }

  deleteInteractionCategory(id: string): void {
    // this.InteractionCategoryService.delete(id).subscribe(d => {
    //   this.toastrService.success(this.translationService.getValue(`CATEGORY_DELETED_SUCCESSFULLY`));
    //   this.getCategories();
    // });
  }

 
  toggleRow(element: any) {
      this.subCategories = []
      let data = {
        parentId : element?.categoryId,
        categoryType: 'Child'
      }
      this.dropdownService.getCategoryMasterList(data).pipe(catchError((error: any) => {
        return EMPTY;
      }),
        take(1)).subscribe((res: any) => {
          this.subCategories = res?.data?.categoryMasterList;
        })
      this.expandedElement = this.expandedElement === element ? null : element;
        this.cd.detectChanges();
     
    }
 

  deleteCategory(category: any): void {
  //  this.commonDialogService
  //     .deleteConformationDialog(`Are you sure you want to delete`)
  //     .subscribe((isTrue:boolean) => {
  //       if (isTrue) {
  //         this.deleteCategoryById(category?.id)
  //       }
  //     });
  }


  deleteCategoryById(id:string) {
    // this.InteractionCategoryService.deleteCategory(id).subscribe((res: any) => {
    //   if (res) {
    //     this.toastrService.success('Category deleted Sucessfully')
    //     this.getCategories();
    //   }
    // }, error => {
    //   this.toastrService.error(error);
    // })
  }

  manageCategory(category: any): void {
    const dialogRef = this.dialog.open(CategoryModalComponent, {
      width: '350px',
      disableClose: true,
      data:  category,
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.getCategories();
      }
    });
  }


  addSubCategory(category: any) {
    this.manageCategory({
      parentId: category?.categoryId,
     categoryType: 'Child'
    });
  }



  openAddCost(data?: any): void {
    const dialogRef = this.dialog.open(AddCostComponent, {
      width: '400px',
      data: data,
      disableClose: true,
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result.data?.success) {
        // this.loadLookUpList();
        this.toastrService.success(result.data.message);
      }
    });
  }
  
}