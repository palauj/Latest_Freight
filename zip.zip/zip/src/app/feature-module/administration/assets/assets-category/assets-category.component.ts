import { Component, OnInit } from '@angular/core';
 
@Component({
  selector: 'app-assets-category',
  templateUrl: './assets-category.component.html',
  styleUrls: ['./assets-category.component.scss'],
})
export class AssetsCategoryComponent   {
   
}
 
