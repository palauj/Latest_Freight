import { Component, EventEmitter, inject, Inject, OnInit, Output } from '@angular/core';
import {
  FormGroup,
  Validators,
  FormControl,
  UntypedFormGroup,
  UntypedFormBuilder,
  ValidatorFn,
  AbstractControl,
  FormBuilder,
} from '@angular/forms';
import { catchError, EMPTY, take } from 'rxjs';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import {
  ActivatedRoute,
  Router,
} from '@angular/router';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
 import {  LookUp, Product } from 'src/app/core/core.index';
import { AccountDropDown, AccountLocationDropDown } from 'src/app/core/helpers/models/account.model';
import { DropdownService } from 'src/app/core/services/dropdown/dropdown.service';
import { AssetsServiceService } from '../../assets-service.service';
import { StatusService } from 'src/app/core/services/status/status.service';
import { employeeListModel, StatusData } from 'src/app/core/helpers/models/common.model';
import { AssetsDomainLookUps, CompanyDomainLookUps } from 'src/app/core/helpers/constants/common.constant';
import { LeadService } from 'src/app/feature-module/crm/leads/lead.service';
import { MasterService } from 'src/app/feature-module/master/master.service';
import { DatePipe } from '@angular/common';
import { Employee } from 'src/app/core/helpers/models/department.model';
import { Category } from 'src/app/core/helpers/models/role.model';

@Component({
  selector: 'app-add-assets-registration',
  templateUrl: './add-assets-registration.component.html',
  styleUrl: './add-assets-registration.component.scss'
})
export class AddAssetsRegistrationComponent implements OnInit {
  public  addAssetsForm!: UntypedFormGroup;
  isSubmitted = false;
  changeAccessType = false;
  Date = new Date();
  status: StatusData[] = [];
  public assetsDomain: any[] = [];
  public employees: any[] = [];
  employeeList: Employee[] = [];
  listData: Product[] = [];
  categories:Category[] =[];
  subCategories:Category[] =[];
  accountName!: string;
  selectedCategory: any;
  accountList: AccountDropDown[] = [];
  LocationList: AccountLocationDropDown[] = [];
  minDate= new Date();
  public accountId: string = '';
  public parentId: string = '';
  public locationId: string = '';
  public employeeId: string = '';
  public userId: string = '';
  selectedEmployeeID: string = '';
    private dropdownService = inject(DropdownService);
 constructor(
   public dialogRef: MatDialogRef<AddAssetsRegistrationComponent>,
    private dialog: MatDialog,
      private masterService: MasterService,
    private fb: FormBuilder,
    private leadService: LeadService,
    private assetsService: AssetsServiceService,
    private toast: ToasterService,
    private statusService: StatusService,
    private datePipe: DatePipe,
    @Inject(MAT_DIALOG_DATA) public data: any
 ){
 
  let userData = JSON.parse(localStorage.getItem('authObj') || '');
  this.accountId = userData?.accountId;
  this.locationId = userData?.employeeLocation[0]?.locationId;
  this.userId = userData.employeeId;
  // this.parentId = userData.parentId;
 
  
 }
 ngOnInit(): void {
  this.createForm();
   this.getStatusList();
   this.getAccounts();
   this.getAssetsDomain();
   this.loadProductList();
   this.patchValueForm();
   this.getCategories();
  this.getSubCategory(this.data?.categoryId);
   
   this.getEmployeeList(this.accountId, this.locationId);
 }
 get c(): { [key: string]: AbstractControl } {
  return this.addAssetsForm.controls;
}
selectEmployee(event: any) {
  const selectedEmployee = this.employeeList.find(
    (e: any) => e.employeeId === event?.value
  );
  this.selectedEmployeeID = event?.value;
  if (selectedEmployee) {
    this.addAssetsForm.patchValue({
      employeeName: selectedEmployee.employeeName,
    });
  }
}
getEmployeeList(accountId: string, locationId: string): void {
  this.employees = [];
  this.leadService
    .getEmployeeList(accountId, locationId)
    .pipe(
      catchError((error: any) => {
        return EMPTY;
      }),
      take(1)
    )
    .subscribe((response: any) => {
      if (response) {
        this.employees = response.data;
      }
    });
}
loadProductList() {
    
  this.listData = [];
  this.masterService.getProductList(1, 50)
  .pipe(
    catchError((error: any) => {
      return EMPTY;
    }),
    take(1)
  ).subscribe((response: any) => {
    if (response.data) {
     
      if (response.statusCode === 200) {
      this.listData = response.data?.productList;
      
    }
  }
  });
}
 private getAccounts(): void {
  this.dropdownService
    .getAccountList()
    .pipe(
      catchError((error: any) => {
        return EMPTY;
      }),
      take(1)
    )
    .subscribe((response: any) => {
      if (response && response.message) {
        if (response.statusCode === 200) {
          this.accountList = response.data;
        }
      }
    });
}
 getAccountName(id: string): void {
  const account = this.accountList.find((x) => x.accountId === id);
  this.accountName = account ? account.accountName : '';
  this.getLocations(id);
}
private getLocations(id: string): void {
  this.dropdownService
    .getLocationList(id)
    .pipe(
      catchError((error: any) => {
        return EMPTY;
      }),
      take(1)
    )
    .subscribe((response: any) => {
      if (response && response.message) {
        if (response.statusCode === 200) {
          this.LocationList = response.data;
        }
      }
    });
}

 getAssetsDomain() {
    let lookUpId = AssetsDomainLookUps.domainLookUpId;
    this.leadService
      .getSubLookUpById(lookUpId)
      .pipe()
      .subscribe((res) => {
        this.assetsDomain = res?.data?.subLookUpList;
      });
  }
private getStatusList(): void {
  this.status = [];

  const payload = {
    pageNumber: 1,
    pageSize: 100,
    statusType: 'Parent',
  };

  this.statusService
    .getStatusMasterList(payload)
    .pipe(
      catchError((error: any) => {
        return EMPTY;
      }),
      take(1)
    )
    .subscribe((response: any) => {
      if (response) {
        this.status = response.data?.statusMatserList;
      }
    });
}
patchValueForm(): void {
 
  if (!this.data) return; // Ensure data exists before patching values.

  // Format the purchaseDate to match the expected input format (YYYY-MM-DD).
  const formattedDate = this.data.purchaseDate
    ? this.datePipe.transform(this.data.purchaseDate, 'yyyy-MM-dd'): '';

    const installationDate = this.data.installationDate
    ? this.datePipe.transform(this.data.installationDate, 'yyyy-MM-dd'): '';

    const warrantyDate = this.data.installationDate
    ? this.datePipe.transform(this.data.installationDate, 'yyyy-MM-dd'): '';

    const warrantyEndDate = this.data.installationDate
    ? this.datePipe.transform(this.data.installationDate, 'yyyy-MM-dd'): '';

  this.addAssetsForm.patchValue({
    // productName: this.data?.productName || '',
    serialNo: this.data?.serialNumber || '', 
    relatedToName: this.data?.relatedToId || '',
    categoryName: this.data?.categoryId || '',
    subCategoryName: this.data?.subCategoryId || '',
    description: this.data?.description || '',
    purchaseDate: formattedDate, // Patch the formatted date here.
    status: this.data?.status || '',
    poNumber: this.data?.poNumber || '',
    model: this.data?.model || '',
    installationDate: installationDate,
    warrantyStartDate: warrantyDate,
    warrantyEndDate: warrantyEndDate,
    // currency: this.data?.currency || '',
    // amount: this.data?.amount || '',
  });
}
createForm(): void{
  this.addAssetsForm = this.fb.group({
    productId: [this.data?.productId || '',[Validators.required]],
    productName: [this.data?.productName || ''],
    serialNo: [this.data?.serialNo || '',[Validators.required]],
    relatedToId: [this.data?.relatedToId || '', [Validators.required]],
    relatedToName: [this.data?.relatedToName || ''],
    categoryId: [this.data?.categoryId || '',[Validators.required]],
    categoryName: [this.data?.categoryName || ''],
    subCategoryId: [this.data?.subCategoryId || '',[Validators.required]],
    subCategoryName: [this.data?.subCategoryName || ''],
    // amount: [this.data?.amount || '',[Validators.required]],
    model: [this.data?.model || '',[Validators.required]],
    // currency: [this.data?.currency  || '',[Validators.required]],
    description: [this.data?.description  || '',[Validators.required]],
    status: [this.data?.status || ''],
    statusId: [this.data?.statusId || '',[Validators.required]],
   purchaseDate: [this.data?.purchaseDate || '',[Validators.required]],
   installationDate: [this.data?.installationDate || '',[Validators.required]],
   warrantyStartDate: [this.data?.warrantyStartDate || '',[Validators.required]],
   warrantyEndDate: [this.data?.warrantyEndDate || '',[Validators.required]],
   poNumber: [this.data?.poNumber || '',[Validators.required]],
  //  employeeId: [this.data?.employeeId || '',[Validators.required]],
  //  assetsDomain: [this.data?.assetsDomain || '',[Validators.required]],
  })
 }
submit(){
 
  if(this.addAssetsForm.invalid){
    this.addAssetsForm.markAllAsTouched();
  }
  const localData = JSON.parse(localStorage.getItem('authObj') || '{}');
  let assetsData = {
    id: this.data?.id,
    userId: localData?.employeeId,
    accountId: localData?.accountId,
    accountName: localData?.accountName,
    locationId: localData?.employeeLocation[0]?.locationId,
    locationName: localData?.employeeLocation[0]?.locationName,
    relatedTo: this.addAssetsForm.value?.relatedTo,
    relatedToId: this.addAssetsForm.value?.relatedToId,
    relatedToName: this.employees.find((e: any) => e?.employeeId === this.addAssetsForm.value?.relatedToId)?.employeeName,
    ownerId: localData?.employeeId,
    serialNo: this.addAssetsForm.value?.serialNo,
    productId: this.addAssetsForm.value?.productId,
    productName: this.listData.find((e: any) => e?.productId === this.addAssetsForm.value?.productId)?.productName,
    categoryId: this.addAssetsForm.value?.categoryId,
    categoryName: this.categories.find((e:any) => e?.categoryId === this.addAssetsForm.value?.categoryId)?.categoryName,
    subCategoryId: this.addAssetsForm.value?.subCategoryId,
    subCategoryName: this.subCategories.find((e: any) => e?.categoryId === this.addAssetsForm.value?.subCategoryId)?.categoryName,
    amount: this.addAssetsForm.value?.amount,
    currency: this.addAssetsForm.value?.currency,
    description: this.addAssetsForm.value?.description,
    status: this.assetsDomain.find((e:any) => e?.subLookUpId === this.addAssetsForm.value?.statusId)?.lookUpName,
    statusId: this.addAssetsForm.value?.statusId,
    model: this.addAssetsForm.value?.model,
    purchaseDate: this.addAssetsForm.value?.purchaseDate,
    installationDate: this.addAssetsForm.value?.installationDate,
    warrantyEndDate: this.addAssetsForm.value?.warrantyEndDate,
    warrantyStartDate: this.addAssetsForm.value?.warrantyStartDate,
    poNumber: this.addAssetsForm.value?.poNumber,
    // employees:
    //     this.employeeList.find(
    //       (e) => e.employeeId === this.addAssetsForm.value?.employeeId
    //     )?.employeeName || '',
    // assetsDomain: this.addAssetsForm.value?.assetsDomain,

  }
  if(this.data?.id){
    this.assetsService
    .updateAssetsDetails(assetsData)
    .pipe(
      catchError((error) => {
        console.error('Error updating Assets:', error);
        alert(error.message || 'Failed to update Assets.');
        return EMPTY;
      }),
      take(1) 
    )
    .subscribe((res: any) => {
      if (res?.statusCode < 399) {
        this.dialogRef.close(true);
        this.toast.typeSuccess(
          res?.data?.message || 'Assets updated successfully!'
        );
       }
    });
} else {
  this.assetsService
    .addAssetsData(assetsData)
    .pipe(
      catchError((error) => {
        console.error('Error adding Assets:', error);
        alert(error.message || 'Failed to add Assets.');
        return EMPTY;
      }),
      take(1)
    )
    .subscribe((res: any) => {
     if (res?.statusCode < 399) {
        this.dialogRef.close(true);
        this.toast.typeSuccess(
          res?.data?.message || 'Assets added successfully!'
        );
        }
    });
}

}
filterDates = (d: Date | null): boolean => {
  const today = new Date(); // Get today's date
  today.setHours(0, 0, 0, 0); // Normalize to start of the day
  return d ? d.getTime() >= today.getTime() : false; // Allow only today and future dates
};

getCategories(): void {
  this.dropdownService.getDropdownForCategoryMasterList().subscribe((response: any) => {
    this.categories = response?.data;
    
  });
  // FIXME change the product api service with interaction category
 
}
getSubCategory(id: string) {
  this.dropdownService.getDropdownForSubCategoryMasterListById(id).subscribe((response: any) => {
    this.subCategories = response?.data;
  });
}

  // Fetch Subcategories Based on Selected Category
  onCategoryChange(category: any): void {
    this.selectedCategory = category;
    this.getSubCategory(category);
  }
}