import { Component, inject, OnInit, ViewChild } from '@angular/core';
import { DataService, LookUp, routes, Ticket } from 'src/app/core/core.index';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { CommonDialogService } from 'src/app/shared/common/common-dialog/common-dialog.service';
import { AddAssetsRegistrationComponent } from './add-assets-registration/add-assets-registration.component';
import { CountsDetail, DataCount } from 'src/app/core/helpers/models/attendance.model';
import { HeaderCountName } from 'src/app/core/helpers/constants/common.constant';
import { pageSelection } from 'src/app/core/helpers/models/common.model';
import { MatPaginator } from '@angular/material/paginator';
import { AssetsServiceService } from '../assets-service.service';
import { catchError, EMPTY, take } from 'rxjs';
import { Assets } from './assets.model';
import { AssetsData } from 'src/app/core/helpers/models/auth.model';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrl: './registration.component.scss',
})

export class RegistrationComponent implements OnInit {
  employeeId!: string;
   cardData: CountsDetail[] = [{
              name: HeaderCountName.Total,
              count: 0,
              icon: 'fa-solid fa-user-plus',
              class: 'bg-primary text-white',
            }, {
              name: HeaderCountName.Active,
              count: 0,
              icon: 'fa-solid fa-hourglass-half',
              class: 'bg-success text-white',
            }, {
              name: HeaderCountName.InActive,
              count: 0,
              icon: 'fa-solid fa-thumbs-down',
              class: 'bg-danger text-white',
            }, {
              name: HeaderCountName.Amc,
              count: 0,
              icon: 'fa-solid fa-sync-alt',
              class: 'bg-warning text-white',
            },
            {
              name: HeaderCountName.WarrantyExpired,
              count: 0,
              icon: 'fa-solid fa-hourglass-half',
              class: 'bg-secondary text-white',
            },
            {
              name: HeaderCountName.UnderWarranty,
              count: 0,
              icon: 'fa-solid fa-hourglass-half',
              class: 'bg-info text-white',
            },];

  public accountId: string = '';
  public locationId: string = '';
  public relatedToId: string = '';
  public id: string = '';
  public userId: string = '';
  public routes = routes;
  selected1 = '1';
  selected2 = '1';
  listData: any[] = [];
  assetsCount!: DataCount;
  authUser!: AssetsData;
  bsValue = new Date();
    public lastIndex = 0;
    pageSize: number = 10;
    totalCount: number = 0;
    pageNo: number = 1;
  
    public skip = 0;
    public limit: number = this.pageSize;
    public pageIndex = 0;
    public serialNumberArray: Array<number> = [];
    public currentPage = 1;
    public pageNumberArray: Array<number> = [];
    public pageSelection: Array<pageSelection> = [];
    public totalPages = 0;
    public searchDataValue = '';
    //** / pagination variables
    assetsList = new MatTableDataSource<Assets>();
    
    columnsToDisplay: string[] = [
      'action',
      'transactionNumber',
      'productName',
      'relatedToName',
      'categoryName',
      'subCategoryName',
      'serialNumber',
      'status',
      'poNumber',
      'description',
      // 'installationDate',
      // 'warrantyStartDate',
      // 'warrantyEndDate',
      'purchaseDate',
      // 'amount',
      // 'currency',
      
       
      
    ];
    displayColumns: string[] = ['footer'];
    @ViewChild(MatPaginator) paginator!: MatPaginator;
    @ViewChild(MatSort) sort!: MatSort;
      private activateRoute = inject(ActivatedRoute);
  constructor(  private dialog: MatDialog,
    private toast: ToasterService,
    private commonService: CommonDialogService,
    private assetsService: AssetsServiceService){
      let userData = JSON.parse(localStorage.getItem('authObj') || '');
      this.accountId = userData?.accountId;
      this.relatedToId = userData?.accountId;
      this.userId = userData?.employeeId;
     
      this.locationId = userData?.employeeLocation[0]?.locationId;
  }
  
  ngOnInit(): void {
    const authUser = localStorage.getItem('authObj');
    if (authUser) this.authUser = JSON.parse(authUser);
    this.activateRoute.params.subscribe((params) => {
      const employeeId = params['id'];
      this.employeeId = employeeId;
      
    });
    this.fetchAssetsCount();
    this.getAssetsList(this.relatedToId);
  }
  ngAfterViewInit() {
    this.assetsList.paginator = this.paginator;
    this.assetsList.sort = this.sort;
  }
  public searchData(value: string): void {
    this.assetsList.filter = value.trim().toLowerCase();
   
  }
    getAssetsList(id:string) {
      let param = {
        search: '',
        pageNo: this.pageNo,
        pageSize: this.pageSize,
        totalCount: this.totalCount,
      };
      this.assetsService.getAssetsList(param, id) .pipe(
        catchError((error: any) => {
          return EMPTY;
        }),
        take(1)
      )
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.assetsList.data = response.data?.assetList;
            this.totalCount = response.data.totalRecords;
          }
        }
      });
    }
    openAssetsModal(assetsList?: any): void {
        const dialogRef = this.dialog.open(AddAssetsRegistrationComponent, {
          height: '80vh',
          width: '80vw',
          disableClose: true,
          data: assetsList || null,
        });
        dialogRef.afterClosed().subscribe((result: any) => {
          if (result) {
             this.getAssetsList(this.relatedToId);
          }
        });
      }
    
    
      public deleteAssets(id: string): void {
        this.commonService
          .deleteConformationDialog('Are you sure you want to delete this Assets?')
          .subscribe((res: Boolean) => {
            if (res) {
              this.assetsService
                .deleteAssetsRecord(id, this.userId)
                .pipe(
                  catchError((error) => {
                    alert(error);
                    return EMPTY;
                  }),
                  take(1)
                )
                .subscribe((res: any) => {
                  if (res?.statusCode < 400) {
                    this.toast.typeSuccess('Assets deleted successfully');
                    this.getAssetsList(this.relatedToId);
                  } else {
                    this.toast.typeError(res?.message);
                  }
                });
            }
          });
      }
      fetchAssetsCount() {
        this.assetsService.getAssetsListCount(this.accountId, this.locationId)
        .pipe(
          catchError((error: any) => {
            return EMPTY;
          }),
          take(1)
        )
        .subscribe((response: any) => {
          
          if (response && response.message) {
            if (response.statusCode === 200) {
              this.assetsCount = response?.data;
              this.cardData.forEach((e: any) => {
                e.count =
                  e.name == 'Total'
                    ? this.assetsCount?.total
                    : e.name == 'Active'
                    ? this.assetsCount?.active
                    : e.name == 'In-Active'
                    ? this.assetsCount?.inActive
                    : e.name == 'Amc'
                    ? this.assetsCount?.amc
                    : e.name == 'WarrantyExpired'
                    ? this.assetsCount?.warrantyExpired
                    : this.assetsCount?.underWarranty;
              });
            } else {
              this.toast.typeError(response?.message);
            }
          }
        });
    }
    getStatusClass(status: string): string {
      switch (status) {
        case 'Under Repair':
          return 'border-under-repair';
        case 'Damage':
          return 'border-damage';
        case 'Out of warranty':
          return 'border-out-of-warranty';
        case 'Under warranty':
          return 'border-under-warranty';
        case 'CMC':
          return 'border-cmc';
        case 'AMC':
          return 'border-amc';
        default:
          return '';
      }
    }
}
