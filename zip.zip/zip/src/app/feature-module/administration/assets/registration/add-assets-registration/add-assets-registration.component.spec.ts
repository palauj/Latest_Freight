import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAssetsRegistrationComponent } from './add-assets-registration.component';

describe('AddAssetsRegistrationComponent', () => {
  let component: AddAssetsRegistrationComponent;
  let fixture: ComponentFixture<AddAssetsRegistrationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddAssetsRegistrationComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AddAssetsRegistrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
