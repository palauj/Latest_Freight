export interface Assets {
    accountId: string;
    accountName: string;
    amount: string;
    category: string;
    categoryId: string;
    contractStartDate: string;
    createdByName: string;
    currency: string;
    description: string;
    serialNumber: string;
    subCategory: string;
    relatedToName: string;
    installationDate: string;
    warrantyStartDate: string;
    warrantyEndDate: string;
    purchaseDate: string;
    poNumber: string;
   
}