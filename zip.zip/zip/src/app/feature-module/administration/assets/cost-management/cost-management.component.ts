import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataService, LookUp, routes } from 'src/app/core/core.index';
import { Sort } from '@angular/material/sort';
import { catchError, EMPTY, take } from 'rxjs';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { CommonDialogService } from 'src/app/shared/common/common-dialog/common-dialog.service';
import { AddCostComponent } from './add-cost/add-cost.component';

@Component({
  selector: 'app-cost-management',
  templateUrl: './cost-management.component.html',
  styleUrl: './cost-management.component.scss',
})
export class CostManagementComponent implements OnInit {
  public routes = routes;
  listData: LookUp[] = [];
  // pagination variables
  public lastIndex = 0;
  public pageSize = 10;
  public totalData: any = 0;
  public skip = 0;
  public limit: number = this.pageSize;
  public pageIndex = 0;
  public serialNumberArray: Array<number> = [];
  public currentPage = 1;
  public pageNumberArray: Array<number> = [];
  // public pageSelection: Array<pageSelection> = [];
  public totalPages = 0;

  constructor(
    // private lookupService: MasterService,
    private data: DataService,
    public dialog: MatDialog,
    private toast: ToasterService,
    private commonService: CommonDialogService
  ) {}
  ngOnInit(): void {
    this.loadCostList();
  }
  public sortData(sort: Sort) {}
  // private getTableData(): void {
  //   this.IsLookUp = [];
  //   this.serialNumberArray = [];
  //   let param = {
  //     pageNo: this.currentPage,
  //     pageSize: this.pageSize,
  //     search: '',
  //   };
  //   this.data
  //     .getCostList(param)
  //     .pipe(
  //       catchError((error) => {
  //         // error?this.isloading = false:''
  //         alert(error);
  //         return EMPTY;
  //       }),
  //       take(1)
  //     )
  //     .subscribe((res: any) => {
  //       this.totalData = res.data?.totalRecords;
  //       this.IsLookUp = res?.data?.employeeList;
  //       this.dataSource = new MatTableDataSource<LookUp>(this.IsLookUp);
  //       this.calculateTotalPages(this.totalData, this.pageSize);
  //     });
  // }
  private calculateTotalPages(totalData: number, pageSize: number): void {
    // this.pageNumberArray = [];
    // this.totalPages = totalData / pageSize;
    // if (this.totalPages % 1 !== 0) {
    //   this.totalPages = Math.trunc(this.totalPages + 1);
    // }
    // for (let i = 1; i <= this.totalPages; i++) {
    //   const limit = pageSize * i;
    //   const skip = limit - pageSize;
    //   this.pageNumberArray.push(i);
    //   this.pageSelection.push({ skip: skip, limit: limit });
    // }
  }
  public changePageSize(): void {
    // this.pageSelection = [];
    // this.limit = this.pageSize;
    // this.skip = 0;
    // this.currentPage = 1;
    // this.getTableData();
  }
  loadCostList() {
    // this.lookupService.addLookUpList().subscribe((response: any) => {
    //   this.listData = response?.data;
    // });
  }

  openAddCost(data?: any): void {
    const dialogRef = this.dialog.open(AddCostComponent, {
      width: '400px',
      data: data,
      disableClose: true,
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result.data?.success) {
        // this.loadLookUpList();
        this.toast.typeSuccess(result.data.message);
      }
    });
  }
  public deleteCost(data: any): void {
    // this.commonService.deleteConformationDialog('Are you sure you want to delete this LookUp?').subscribe((res:Boolean)=>{
    //   if(res){
    //     this.lookupService.deleteLookUpRecord(data?.lookUpId).pipe(
    //       catchError((error) => {
    //         alert(error);
    //         return EMPTY;
    //       }),
    //       take(1)
    //     ).subscribe(
    //       (res: any) => {
    //         if(res?.statusCode == 200  )
    //         {
    //           this.toast.typeSuccess('LookUp added successfully');
    //           this.loadLookUpList();
    //         }
    //         else{
    //           this.toast.typeError('LookUp is not deleted')
    //         }
    //        });
    //       }
    //   })
    // }
  }
}
