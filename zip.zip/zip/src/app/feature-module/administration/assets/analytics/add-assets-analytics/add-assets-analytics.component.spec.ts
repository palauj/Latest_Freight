import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAssetsAnalyticsComponent } from './add-assets-analytics.component';

describe('AddAssetsAnalyticsComponent', () => {
  let component: AddAssetsAnalyticsComponent;
  let fixture: ComponentFixture<AddAssetsAnalyticsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddAssetsAnalyticsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AddAssetsAnalyticsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
