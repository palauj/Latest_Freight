import { Component, EventEmitter, Inject, OnInit, Output } from '@angular/core';
import {
  FormGroup,
  Validators,
  FormControl,
  UntypedFormGroup,
  UntypedFormBuilder,
  ValidatorFn,
  AbstractControl,
  FormBuilder,
} from '@angular/forms';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import {
  ActivatedRoute,
  Router,
} from '@angular/router';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
 import { LookUp } from 'src/app/core/core.index';
 
@Component({
  selector: 'app-add-assets-analytics',
  templateUrl: './add-assets-analytics.component.html',
  styleUrl: './add-assets-analytics.component.scss'
})
export class AddAssetsAnalyticsComponent implements OnInit {
  public addtrackForm!: FormGroup;
  public department: any[] = [];
  public designation: any[] = [];
  public listData: any;
  public lookupdata: any;
  public lookId: any;
  tittle: string = 'Add Track';
  constructor(
    private fb: FormBuilder,

    private toast: ToasterService,
    private router: Router,
    private routes: ActivatedRoute,
    // private lookupService: MasterService,
    public dialogRef: MatDialogRef<AddAssetsAnalyticsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: LookUp | any,
  ) { }

  ngOnInit(): void {
    this.createForm();
  }


  createForm(): void {
    // this.addtrackForm = this.fb.group({
    //   LookupName: new FormControl(this.data?.lookUpName || '', [Validators.required]),
    //   isActive: new FormControl(this.data?.isActive ? 'active' : 'inactive', [Validators.required]),
    // });
  }

  submit() {
  //   if (this.addtrackForm.invalid) {
  //     this.addtrackForm.markAllAsTouched();
  //     return;
  //   }
  //   const lookupData = {
  //     lookUpId: this.data.lookUpId || '',
  //     LookupName: this.addtrackForm.value?.LookupName,
  //     isActive: this.addtrackForm.value?.isActive == 'active' ? true : false,
  //     edit: this.data.lookUpId ? 1 : 0,

  //   };

  //   this.lookupService
  //     .addlookUp(lookupData)
  //     .pipe(
  //       catchError((error) => {
  //         alert(error);
  //         return EMPTY;
  //       }),
  //       take(1)
  //     )
  //     .subscribe((res: any) => {
  //       if (res?.statusCode < 400) {
  //         this.toast.typeSuccess(res?.message)
  //         this.dialogRef.close(true);
  //       }

  //     });
  // }
}
}

