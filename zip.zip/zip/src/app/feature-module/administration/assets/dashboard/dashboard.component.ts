import { Component, OnInit } from '@angular/core';
import { Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import {
  DataService,
  getAssetsNew,
  apiResultFormat,
  routes,
} from 'src/app/core/core.index';
import { FormBuilder, FormControl, FormGroup, UntypedFormGroup, Validators } from '@angular/forms';
import { pageSelection } from 'src/app/core/helpers/models/common.model';
import { assetsCount } from 'src/app/core/helpers/models/attendance.model';
import { AssetsServiceService } from '../assets-service.service';
import { catchError, EMPTY, take } from 'rxjs';
interface data {
  value: string;
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss',
})
export class DashboardComponent implements OnInit {
  public accountId: string = '';
  public locationId: string = '';
  assetsCount!: assetsCount;
  bsValue = new Date();
  bsRangeValue: Date[];
  maxDate = new Date();
  newAssetsForm!: FormGroup;
  addAssigneeForm!: FormGroup;
  searchFormYearWise!: UntypedFormGroup;
  
  public selectedValue1 = '';
  public selectedValue2 = '';
  public selectedValue3 = '';
  public selectedValue4 = '';
  public routes = routes;
  public assetsStatusDetail: any[] = [];
  
fetched: boolean = false;
public assetsDetailForLocation: any[] =[];
  constructor(private data: DataService, private assetsService: AssetsServiceService, private fb: FormBuilder, ) {
    this.searchFormYearWise = this.fb.group({
      fromDate: [''],
      toDate: [''],
    });
   
    let userData = JSON.parse(localStorage.getItem('authObj') || '');
    this.accountId = userData?.accountId;
    this.locationId = userData?.employeeLocation[0]?.locationId;
    this.maxDate.setDate(this.maxDate.getDate() + 7);
    this.bsRangeValue = [this.bsValue, this.maxDate];
  }
  selectedList1: data[] = [{ value: 'Category 1' }, { value: 'Category 2' }];
  selectedList2: data[] = [
    { value: 'Department 1' },
    { value: 'Department 2' },
  ];
  selectedList3: data[] = [{ value: 'Customer' }, { value: 'Client' }];
  selectedList4: data[] = [{ value: 'Laptop' }, { value: 'Keyboard' }];
  public assetsNew: Array<getAssetsNew> = [];
  dataSource!: MatTableDataSource<getAssetsNew>;

  // pagination variables
  public lastIndex = 0;
  public pageSize = 10;
  public totalData = 0;
  public skip = 0;
  public limit: number = this.pageSize;
  public pageIndex = 0;
  public serialNumberArray: Array<number> = [];
  public currentPage = 1;
  public pageNumberArray: Array<number> = [];
  public pageSelection: Array<pageSelection> = [];
  public totalPages = 0;
  //** / pagination variables

  ngOnInit() {
    this.setDefaultDateRange();
    this.onSearchAssetsStatus();
    this.fetchAssetsCount();
    this.GetAssetDetailForLocation();
  }

  public  fetchAssetsCount() {
    this.assetsService
      .getAssetsListCount(this.accountId, this.locationId)
      .subscribe((response: any) => {
        if (response && response.message) {
          if (response.statusCode === 200) {
            this.assetsCount = response?.data;
          } else {
            console.error('this count is not found');
          }
        }
      });
  }
   
  public GetAssetDetailForLocation(){
    this.assetsService.getAssetDetailForLocation().subscribe( (res: any) => {
      this.assetsDetailForLocation = res?.data;
    })
  }
  onDropdownSelect(option: string): void {
    const currentDate = new Date();
    let fromDate: Date | null = null;

    switch (option) {
      case 'today':
        fromDate = new Date(currentDate); // Today means the same day
        break;
      case 'weekly':
        fromDate = new Date(currentDate);
        fromDate.setDate(currentDate.getDate() - 7); // Last 7 days
        break;
      case 'monthly':
        fromDate = new Date(currentDate);
        fromDate.setMonth(currentDate.getMonth() - 1); // Last 1 month
        break;
      case '3-months':
        fromDate = new Date(currentDate);
        fromDate.setMonth(currentDate.getMonth() - 3); // Last 3 months
        break;
      case '6-months':
        fromDate = new Date(currentDate);
        fromDate.setMonth(currentDate.getMonth() - 6); // Last 6 months
        break;
      case '12-months':
        fromDate = new Date(currentDate);
        fromDate.setFullYear(currentDate.getFullYear() - 1); // Last 12 months
        break;
      default:
        console.warn('Invalid option selected.');
        return;
    }

    if (fromDate) {
      const formattedFromDate = fromDate.toISOString().split('T')[0];
      const formattedToDate = currentDate.toISOString().split('T')[0];

      this.searchFormYearWise.patchValue({
        fromDate: formattedFromDate,
        toDate: formattedToDate
      });

      this.onSearchAssetsStatus();
    }
  }

  onSearchAssetsStatus (): void {
    const fromDate = this.searchFormYearWise.get('fromDate')?.value;
    const toDate = this.searchFormYearWise.get('toDate')?.value;

    if (fromDate && toDate) {
      this.assetsService
        .getAssetsDetails(fromDate, toDate, this.accountId, this.locationId)
        .pipe(
          take(1),
          catchError((error: any) => {
            console.error('Error fetching Assets status data:', error);
            this.assetsStatusDetail = [];
            this.fetched = false;
            return EMPTY;
          })
        )
        .subscribe((response: any) => {
          if (response?.data?.length) {
            this.assetsStatusDetail = response.data;
            this.fetched = true;
          } else {
            this.assetsStatusDetail = [];
            this.fetched = true;
          }
        });
    } else {
      alert('Please select both From Date and To Date.');
      this.fetched = false;
    }
  }
  setDefaultDateRange(): void {
    const currentDate = new Date();
    const fromDate = new Date(currentDate);
    fromDate.setDate(currentDate.getDate() - 7); // Default to the last 7 days

    // Format dates as yyyy-MM-dd
    const formattedFromDate = fromDate.toISOString().split('T')[0];
    const formattedToDate = currentDate.toISOString().split('T')[0];

    // Set default values in the form
    this.searchFormYearWise.patchValue({
      fromDate: formattedFromDate,
      toDate: formattedToDate
    });
  }
  
}
