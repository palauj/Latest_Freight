import { Component, OnInit } from '@angular/core';
import { Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import {
  DataService,
  getAssetsNew,
  apiResultFormat,
  routes,
} from 'src/app/core/core.index';
 import { FormControl, FormGroup, Validators } from '@angular/forms';
interface data {
  value: string;
}
@Component({
  selector: 'app-assets-new',
  templateUrl: './assets-new.component.html',
  styleUrls: ['./assets-new.component.scss'],
})
export class AssetsNewComponent implements OnInit {
  bsValue = new Date();
  bsRangeValue: Date[];
  maxDate = new Date();
  newAssestForm!: FormGroup;
  addAssigneeForm!: FormGroup;
  public selectedValue1 = '';
  public selectedValue2 = '';
  public selectedValue3 = '';
  public selectedValue4 = '';
  public routes = routes;

  constructor(private data: DataService) {
    this.maxDate.setDate(this.maxDate.getDate() + 7);
    this.bsRangeValue = [this.bsValue, this.maxDate];
  }
  selectedList1: data[] = [{ value: 'Category 1' }, { value: 'Category 2' }];
  selectedList2: data[] = [
    { value: 'Department 1' },
    { value: 'Department 2' },
  ];
  selectedList3: data[] = [{ value: 'Customer' }, { value: 'Client' }];
  selectedList4: data[] = [{ value: 'Laptop' }, { value: 'Keyboard' }];

  public assetsNew: Array<getAssetsNew> = [];
  dataSource!: MatTableDataSource<getAssetsNew>;

  // pagination variables
  public lastIndex = 0;
  public pageSize = 10;
  public totalData = 0;
  public skip = 0;
  public limit: number = this.pageSize;
  public pageIndex = 0;
  public serialNumberArray: Array<number> = [];
  public currentPage = 1;
  public pageNumberArray: Array<number> = [];
   public totalPages = 0;
  //** / pagination variables

  ngOnInit() {
    this.getTableData();
    this.newAssestFormInit();
    this.assigneeFormInit();
  }

  private newAssestFormInit(): void {
    this.newAssestForm = new FormGroup({
      assestName: new FormControl('', Validators.required),
      assestId: new FormControl(
        { value: 'AST-235', disabled: true },
        Validators.required
      ),
      category: new FormControl('', Validators.required),
      startDate: new FormControl('', Validators.required),
      endDate: new FormControl('', Validators.required),
      type: new FormControl('', Validators.required),
      brand: new FormControl('', Validators.required),
      model: new FormControl('', Validators.required),
      serialNo: new FormControl('', Validators.required),
      vendor: new FormControl('', Validators.required),
      cost: new FormControl('', Validators.required),
      location: new FormControl('', Validators.required),
      assestImage: new FormControl('', Validators.required),
    });
  }

  private assigneeFormInit(): void {
    this.newAssestForm = new FormGroup({
      assestName: new FormControl('', Validators.required),
      assestId: new FormControl(
        { value: 'AST-235', disabled: true },
        Validators.required
      ),
      category: new FormControl('', Validators.required),
      startDate: new FormControl('', Validators.required),
      endDate: new FormControl('', Validators.required),
      type: new FormControl('', Validators.required),
      brand: new FormControl('', Validators.required),
      model: new FormControl('', Validators.required),
      serialNo: new FormControl('', Validators.required),
      vendor: new FormControl('', Validators.required),
      cost: new FormControl('', Validators.required),
      location: new FormControl('', Validators.required),
      assestImage: new FormControl('', Validators.required),
    });
  }

  //getting the status value
  private getTableData(): void {
    this.assetsNew = [];
    this.serialNumberArray = [];

    this.data.getAssetsNew().subscribe((res: apiResultFormat) => {
      this.totalData = res.totalData;
      res.data.map((res: getAssetsNew, index: number) => {
        const serialNumber = index + 1;
        if (index >= this.skip && serialNumber <= this.limit) {
          res.id = serialNumber;
          this.assetsNew.push(res);
          this.serialNumberArray.push(serialNumber);
        }
      });
      this.dataSource = new MatTableDataSource<getAssetsNew>(this.assetsNew);
      this.calculateTotalPages(this.totalData, this.pageSize);
    });
  }

  public sortData(sort: Sort) {
    const data = this.assetsNew.slice();

    /* eslint-disable @typescript-eslint/no-explicit-any */
    if (!sort.active || sort.direction === '') {
      this.assetsNew = data;
    } else {
      this.assetsNew = data.sort((a: any, b: any) => {
        const aValue = (a as any)[sort.active];
        const bValue = (b as any)[sort.active];
        return (aValue < bValue ? -1 : 1) * (sort.direction === 'asc' ? 1 : -1);
      });
    }
  }

  public getMoreData(event: string): void {
    if (event === 'next') {
      this.currentPage++;
      this.pageIndex = this.currentPage - 1;
      this.limit += this.pageSize;
      this.skip = this.pageSize * this.pageIndex;
      this.getTableData();
    } else if (event === 'previous') {
      this.currentPage--;
      this.pageIndex = this.currentPage - 1;
      this.limit -= this.pageSize;
      this.skip = this.pageSize * this.pageIndex;
      this.getTableData();
    }
  }

  public moveToPage(pageNumber: number): void {
     
  }

  public changePageSize(): void {
    
    this.limit = this.pageSize;
    this.skip = 0;
    this.currentPage = 1;
    this.getTableData();
  }

  private calculateTotalPages(totalData: number, pageSize: number): void {
    this.pageNumberArray = [];
    this.totalPages = totalData / pageSize;
    if (this.totalPages % 1 !== 0) {
      this.totalPages = Math.trunc(this.totalPages + 1);
    }
    for (let i = 1; i <= this.totalPages; i++) {
      const limit = pageSize * i;
      const skip = limit - pageSize;
      this.pageNumberArray.push(i);
     }
  }
}
