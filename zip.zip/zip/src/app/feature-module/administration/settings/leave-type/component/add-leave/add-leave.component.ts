import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';

@Component({
  selector: 'app-add-leave',
  templateUrl: './add-leave.component.html',
  styleUrl: './add-leave.component.scss'
})
export class AddLeaveComponent {
  leaveForm!: FormGroup;
  constructor(private fb: FormBuilder,
     public dialogRef: MatDialogRef<AddLeaveComponent>,
        private dialog: MatDialog,
        private toast: ToasterService,
  ) {
   
  }

  ngOnInit(): void {
    this.cerateForm();
  }

  cerateForm(){
    this.leaveForm = this.fb.group({
      leaveType: ['', Validators.required],
      numberOfDays: ['', [Validators.required, Validators.pattern('^[0-9]+$')]]
    });
  }
  submitForm(): void {
    if (this.leaveForm.valid) {
      console.log('Form Data:', this.leaveForm.value);
    } else {
      this.leaveForm.markAllAsTouched();
    }
  }
}
