import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddLeaveComponent } from './component/add-leave/add-leave.component';
 
@Component({
  selector: 'app-leave-type',
  templateUrl: './leave-type.component.html',
  styleUrls: ['./leave-type.component.scss'],
})
export class LeaveTypeComponent implements OnInit {
  constructor(private dialog: MatDialog,){
 
   }
  ngOnInit(): void {
    
  }
  openLeaveModal(){
     const dialogRef = this.dialog.open(AddLeaveComponent,{
          height: '45vh',
          width: '35vw',
          disableClose: true,
          data: '',
        });
        dialogRef.afterClosed().subscribe((result: any) =>{
          if(result){
    
          }
        });
  }
}
