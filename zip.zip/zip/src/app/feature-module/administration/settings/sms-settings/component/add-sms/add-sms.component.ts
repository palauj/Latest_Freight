import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';

@Component({
  selector: 'app-add-sms',
  templateUrl: './add-sms.component.html',
  styleUrl: './add-sms.component.scss'
})
export class AddSmsComponent {
  smsSettingsForm!: FormGroup;
constructor(private fb: FormBuilder,
    public dialogRef: MatDialogRef<AddSmsComponent>,
    private dialog: MatDialog,
    private toast: ToasterService,) {
    }
    ngOnInit(): void { 
      this.createForm();
    }
    createForm(){
      this.smsSettingsForm = this.fb.group({
        apiKey: ['', Validators.required],
        apiSecret: ['', Validators.required],
        senderId: ['', Validators.required],
        status: ['Active', Validators.required]
      });
    }
    onSubmit(): void {
      if (this.smsSettingsForm.valid) {
        console.log('Form Submitted', this.smsSettingsForm.value);
      }
    }
}
