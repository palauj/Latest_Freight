import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { AddSmsComponent } from './component/add-sms/add-sms.component';

@Component({
  selector: 'app-sms-settings',
  templateUrl: './sms-settings.component.html',
  styleUrl: './sms-settings.component.scss'
})
export class SmsSettingsComponent {
  constructor(private fb: FormBuilder, private dialog: MatDialog) {}
openSmsModal(){
  const dialogRef = this.dialog.open(AddSmsComponent, {
            height: '68vh',
            width: '30vw',
            disableClose: true,
            data: '',
          });
          dialogRef.afterClosed().subscribe((result: any) => {
            if (result) {
               
            }
          });
  }
}
