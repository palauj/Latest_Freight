import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SettingsRoutingModule } from './settings-routing.module';
import { SettingsComponent } from './settings.component';
import { ApprovalComponent } from './approval/approval.component';
import { ChangePasswordComponent } from '../../auth/change-password/change-password.component';
import { CompanySettingsComponent } from './company-settings/company-settings.component';
import { CronComponent } from './cron/cron.component';
import { EmailSettingsComponent } from './email-settings/email-settings.component';
import { InvoiceSettingsComponent } from './invoice-settings/invoice-settings.component';
import { LeaveTypeComponent } from './leave-type/leave-type.component';
import { LocalizationComponent } from './localization/localization.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { PerformanceComponent } from './performance/performance.component';
import { RoleComponent } from './role/role.component';
import { SalarySettingsComponent } from './salary-settings/salary-settings.component';
import { ThemeSettingsComponent } from './theme-settings/theme-settings.component';
import { TokboxComponent } from './tokbox/tokbox.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';
import { ProfileComponent } from './profile/profile.component';
import { SecuritySettingsComponent } from './security-settings/security-settings.component';
import { CustomSettingsComponent } from './custom-settings/custom-settings.component';
import { PaymentSettingsComponent } from './payment-settings/payment-settings.component';
import { CurrenciesSettingsComponent } from './currencies-settings/currencies-settings.component';
import { TaxSettingsComponent } from './tax-settings/tax-settings.component';
import { BanIpSettingsComponent } from './ban-ip-settings/ban-ip-settings.component';
import { SmsTemplateComponent } from './sms-template/sms-template.component';
import { SmsSettingsComponent } from './sms-settings/sms-settings.component';
import { OtpSettingsComponent } from './otp-settings/otp-settings.component';
import { ChangesPasswordComponent } from './security-settings/company/changes-password/changes-password.component';
import { ChangeNumberComponent } from './security-settings/company/change-number/change-number.component';
import { DeleteAccountComponent } from './security-settings/company/delete-account/delete-account.component';
import { ConnectedAppsComponent } from './connected-apps/connected-apps.component';
import { AddLeaveComponent } from './leave-type/component/add-leave/add-leave.component';
import { AddPaypalComponent } from './payment-settings/component/add-paypal/add-paypal.component';
import { AddTaxComponent } from './tax-settings/component/add-tax/add-tax.component';
import { AddCurrenciesComponent } from './currencies-settings/component/add-currencies/add-currencies.component';
import { AddCustomComponent } from './custom-settings/component/add-custom/add-custom.component';
import { AddEmailComponent } from './email-settings/compopnent/add-email/add-email.component';
import { AddSmsComponent } from './sms-settings/component/add-sms/add-sms.component';
import { AddCronComponent } from './cron/component/add-cron/add-cron.component';
import { AddAddressComponent } from './ban-ip-settings/component/add-address/add-address.component';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
 

@NgModule({
  declarations: [
    SettingsComponent,
    ApprovalComponent,
    ChangePasswordComponent,
    CompanySettingsComponent,
    CronComponent,
    EmailSettingsComponent,
    InvoiceSettingsComponent,
    LeaveTypeComponent,
    LocalizationComponent,
    NotificationsComponent,
    PerformanceComponent,
    RoleComponent,
    SalarySettingsComponent,
    ThemeSettingsComponent,
    TokboxComponent,
    ProfileComponent,
    SecuritySettingsComponent,
    CustomSettingsComponent,
    PaymentSettingsComponent,
    CurrenciesSettingsComponent,
    TaxSettingsComponent,
    BanIpSettingsComponent,
    SmsTemplateComponent,
    SmsSettingsComponent,
    OtpSettingsComponent,
    ChangesPasswordComponent,
    ChangeNumberComponent,
    DeleteAccountComponent,
    ConnectedAppsComponent,
    AddLeaveComponent,
    AddPaypalComponent,
    AddTaxComponent,
    AddCurrenciesComponent,
    AddCustomComponent,
    AddEmailComponent,
    AddSmsComponent,
    AddCronComponent,
    AddAddressComponent
  ],
  imports: [
    CommonModule,
    SettingsRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    MatSlideToggleModule,
  ],
})
export class SettingsModule {}
