import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { AddAddressComponent } from './component/add-address/add-address.component';
import { SettingsService } from '../settings.service';
import { catchError, EMPTY, take } from 'rxjs';
import { IpData } from 'src/app/core/core.index';
 
@Component({
  selector: 'app-ban-ip-settings',
  templateUrl: './ban-ip-settings.component.html',
  styleUrl: './ban-ip-settings.component.scss'
})
export class BanIpSettingsComponent {
  addressList: IpData[] = [];
  constructor(private fb: FormBuilder, private dialog: MatDialog,
      private settingsService: SettingsService,
    
  ) {}
  ngOnInit(): void {
    this.getIpAddressDetails();
  }
  openIPAddressModal(address?: IpData){
     const dialogRef = this.dialog.open(AddAddressComponent, {
               height: '62vh',
               width: '30vw',
               disableClose: true,
               data: address || null,
             });
             dialogRef.afterClosed().subscribe((result: any) => {
               if (result) {
                this.getIpAddressDetails();
               }
             });
     }
     public getIpAddressDetails(){
       this.settingsService.getWhiteIPAddress() .pipe(
            catchError((error: any) => {
              return EMPTY;
            }),
            take(1)
          )
          .subscribe((response: any) => {
            if (response && response.message) {
              if (response.statusCode === 200) {
                this.addressList = response?.data;
              }
            }
          });
     }
    
  
   
    updateIPAddress() {
      this.settingsService.updateWhiteIPAddress(this.addressList)
        .pipe(
          catchError(() => EMPTY),
          take(1)
        )
        .subscribe((response: any) => {
          if (response?.statusCode === 200) {
            alert('IP Address Updated Successfully!');
            this.getIpAddressDetails(); 
          }
        });
    }
  
  }
  
 
