import { Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { SettingsService } from '../../../settings.service';
import { catchError, EMPTY, take } from 'rxjs';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { IpData } from 'src/app/core/core.index';

@Component({
  selector: 'app-add-address',
  templateUrl: './add-address.component.html',
  styleUrl: './add-address.component.scss'
})
export class AddAddressComponent {
  addressList: IpData[] = [];
  banIpForm!: FormGroup;
  submitted = false;

  constructor(private fb: FormBuilder,
    private toast: ToasterService,
    private settingsService: SettingsService,
    public dialogRef: MatDialogRef<AddAddressComponent>,
    private dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  ngOnInit(): void {
    this.data;
    debugger 
    this.createForm();
  }

  createForm() {
    this.banIpForm = this.fb.group({
      userId: [this.data?.id || ''],
      remoteIP: [this.data?.createdIP || ''],
      remarks: [this.data?.remarks || '', [Validators.required]],
      isActive: [this.data ? !this.data?.isActive ? false : true : true, [Validators.required]],
    });
  }
  onSubmit() {
    if (this.banIpForm.invalid) {
      this.banIpForm.markAllAsTouched();
      return;
    }

    const localData = JSON.parse(localStorage.getItem('authObj') || '{}');

    const payload = {
      id: this.data?.id || '',
      userId: localData?.employeeId,
      remoteIP: this.banIpForm.value.remoteIP,
      remarks: this.banIpForm.value.remarks,
      isActive: this.banIpForm.value.isActive,
    };

    if (this.data && this.data.id) {
      this.settingsService
        .updateWhiteIPAddress(payload)
        .pipe(
          catchError((error) => {
            console.error('Error updating IP Address:', error);
            alert(error.message || 'Failed to update IP Address.');
            return EMPTY;
          }),
          take(1)
        )
        .subscribe((res: any) => {
          if (res?.statusCode <= 399) {
            this.dialogRef.close(true);
            this.toast.typeSuccess(res?.data?.message || 'IP Address updated successfully!');
          }
        });
    } else {
      this.settingsService
        .addWhiteIPAddress(payload)
        .pipe(
          catchError((error) => {
            console.error('Error adding IP Address:', error);
            alert(error.message || 'Failed to add IP Address.');
            return EMPTY;
          }),
          take(1)
        )
        .subscribe((res: any) => {
          if (res?.statusCode <= 399) {
            this.dialogRef.close(true);
            this.toast.typeSuccess(res?.data?.message || 'IP Address added successfully!');
          }
        });
    }
  }

}
