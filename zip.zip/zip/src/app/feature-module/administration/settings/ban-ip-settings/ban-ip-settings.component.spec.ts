import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BanIpSettingsComponent } from './ban-ip-settings.component';

describe('BanIpSettingsComponent', () => {
  let component: BanIpSettingsComponent;
  let fixture: ComponentFixture<BanIpSettingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BanIpSettingsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BanIpSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
