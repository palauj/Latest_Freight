import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SettingsComponent } from './settings.component';
import { CompanySettingsComponent } from './company-settings/company-settings.component';
import { LocalizationComponent } from './localization/localization.component';
import { ThemeSettingsComponent } from './theme-settings/theme-settings.component';
import { RoleComponent } from './role/role.component';
import { EmailSettingsComponent } from './email-settings/email-settings.component';
import { InvoiceSettingsComponent } from './invoice-settings/invoice-settings.component';
import { SalarySettingsComponent } from './salary-settings/salary-settings.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { ChangePasswordComponent } from '../../auth/change-password/change-password.component';
import { LeaveTypeComponent } from './leave-type/leave-type.component';
import { TokboxComponent } from './tokbox/tokbox.component';
import { CronComponent } from './cron/cron.component';
import { PerformanceComponent } from './performance/performance.component';
import { ApprovalComponent } from './approval/approval.component';
import { ProfileComponent } from './profile/profile.component';
import { SecuritySettingsComponent } from './security-settings/security-settings.component';
import { CustomSettingsComponent } from './custom-settings/custom-settings.component';
import { PaymentSettingsComponent } from './payment-settings/payment-settings.component';
import { TaxSettingsComponent } from './tax-settings/tax-settings.component';
import { CurrenciesSettingsComponent } from './currencies-settings/currencies-settings.component';
import { BanIpSettingsComponent } from './ban-ip-settings/ban-ip-settings.component';
import { SmsTemplateComponent } from './sms-template/sms-template.component';
import { SmsSettingsComponent } from './sms-settings/sms-settings.component';
import { OtpSettingsComponent } from './otp-settings/otp-settings.component';
import { ConnectedAppsComponent } from './connected-apps/connected-apps.component';

const routes: Routes = [
  {
    path:"",
    component:SettingsComponent,
    children:[
      {
        path:"company-settings",
        data: { claimType: ['SETT_VIEW']},
        component:CompanySettingsComponent
      },
      {
        path:"localization",
        data: { claimType: ['SETT_VIEW']},
        component:LocalizationComponent
      },
      {
        path:"theme-settings",
        data: { claimType: ['SETT_VIEW']},
        component:ThemeSettingsComponent
      },
      
      {
        path:"role",
        data: { claimType: ['SETT_VIEW']},
        component:RoleComponent
      },
      {
        path:"email-settings",
        data: { claimType: ['SYS_SETT_VIEW']},
        component:EmailSettingsComponent
      },
      {
        path:"connected-apps",
        data: { claimType: ['GNRL_SETT_VIEW']},
        component:ConnectedAppsComponent
      },
      {
        path:"sms-templates",
        data: { claimType: ['SYS_SETT_VIEW']},
        component:SmsTemplateComponent
      },
      {
        path:"sms-settings",
        data: { claimType: ['SYS_SETT_VIEW']},
        component:SmsSettingsComponent
      },
      {
        path:"otp",
        data: { claimType: ['SYS_SETT_VIEW']},
        component:OtpSettingsComponent
      },
      {
        path:"invoice-settings",
        data: { claimType: ['APP_SETT_VIEW']},
        component:InvoiceSettingsComponent
      },
      {
        path:"salary-settings",
        data: { claimType: ['APP_SETT_VIEW']},
        component:SalarySettingsComponent
      },
      {
        path:"notifications-settings",
        data: { claimType: ['GNRL_SETT_VIEW']},
        component:NotificationsComponent
      },
      {
        path:"custom-settings",
        data: { claimType: ['APP_SETT_VIEW']},
        component:CustomSettingsComponent
      },
      {
        path:"leave-settings",
        data: { claimType: ['APP_SETT_VIEW']},
        component:LeaveTypeComponent
      },
      {
        path:"tokbox-settings",
        data: { claimType: ['SETT_VIEW']},
        component:TokboxComponent
      },
      {
        path:"cron-settings",
        data: { claimType: ['OTR_SETT_VIEW']},
        component:CronComponent
      },
      {
        path:"ban-ip-address",
        data: { claimType: ['OTR_SETT_VIEW']},
        component:BanIpSettingsComponent
      },
      {
        path:"performance-settings",
        data: { claimType: ['SETT_VIEW']},
        component:PerformanceComponent
      },
      {
        path:"approval-settings",
        data: { claimType: ['APP_SETT_VIEW']},
        component:ApprovalComponent
      },
      {
        path:"profile-settings",
        data: { claimType: ['GNRL_SETT_VIEW']},
        component:ProfileComponent
      },
      {
        path:"security-settings",
        data: { claimType: ['GNRL_SETT_VIEW']},
        component:SecuritySettingsComponent
      },
      {
        path:"payment-settings",
        data: { claimType: ['FNC_SETT_VIEW']},
        component:PaymentSettingsComponent
      },
      {
        path:"tax-settings",
        data: { claimType: ['FNC_SETT_VIEW']},
        component:TaxSettingsComponent
      },
      {
        path:"currencies-settings",
        data: { claimType: ['FNC_SETT_VIEW']},
        component:CurrenciesSettingsComponent
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SettingsRoutingModule { }
