import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-sms-template',
  templateUrl: './sms-template.component.html',
  styleUrl: './sms-template.component.scss'
})
export class SmsTemplateComponent {

}
