import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import {  MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
 
@Component({
  selector: 'app-add-cron',
  templateUrl: './add-cron.component.html',
  styleUrl: './add-cron.component.scss'
})
export class AddCronComponent {
  cronJobForm!: FormGroup;
  submitted = false;

constructor(private fb: FormBuilder,
    public dialogRef: MatDialogRef<AddCronComponent>,
    private dialog: MatDialog,
    private toast: ToasterService,) {
    }
  ngOnInit(): void {
    this.cronJobForm = this.fb.group({
      name: ['', Validators.required],
      schedule: ['', Validators.required],
      nextRunDate: ['', Validators.required],
      nextRunTime: ['', Validators.required],
      url: ['', [Validators.required, Validators.pattern('https?://.+')]],
    });
  }

  onSubmit() {
    if (this.cronJobForm.valid) {
      console.log('Form Submitted:', this.cronJobForm.value);
       
    } else {
      console.log('Form is invalid');
    }
  }
}
