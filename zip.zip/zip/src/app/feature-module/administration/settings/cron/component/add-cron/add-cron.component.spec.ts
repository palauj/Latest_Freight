import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddCronComponent } from './add-cron.component';

describe('AddCronComponent', () => {
  let component: AddCronComponent;
  let fixture: ComponentFixture<AddCronComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddCronComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AddCronComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
