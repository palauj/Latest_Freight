import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { AddCronComponent } from './component/add-cron/add-cron.component';

@Component({
  selector: 'app-cron',
  templateUrl: './cron.component.html',
  styleUrls: ['./cron.component.scss'],
})
export class CronComponent implements OnInit {

  ngOnInit(): void {
  }
   constructor(private fb: FormBuilder, private dialog: MatDialog) {}
   openCronJobModal(){
   const dialogRef = this.dialog.open(AddCronComponent, {
             height: '66vh',
             width: '30vw',
             disableClose: true,
             data: '',
           });
           dialogRef.afterClosed().subscribe((result: any) => {
             if (result) {
                
             }
           });
   }
}
