import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-tax',
  templateUrl: './add-tax.component.html',
  styleUrl: './add-tax.component.scss'
})
export class AddTaxComponent {
  taxForm!: FormGroup;
 constructor(
    public dialogRef: MatDialogRef<AddTaxComponent>,
    private dialog: MatDialog,
    private fb: FormBuilder,
    private toast: ToasterService,

  ) {
   
  }
  ngOnInit(): void { 
    this.createForm();
  }
  createForm(){
    this.taxForm = this.fb.group({
      taxName: ['GST', Validators.required],
      taxRate: ['14%', [Validators.required, Validators.pattern('^[0-9]+%$')]],
      status: ['Active', Validators.required]
    });
  }
  onSubmit(): void {
    if (this.taxForm.valid) {
      console.log('Form Submitted:', this.taxForm.value);
      
    } else {
      this.taxForm.markAllAsTouched();
    }
  }
}
