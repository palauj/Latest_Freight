import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder } from '@angular/forms';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';

@Component({
  selector: 'app-delete-tax',
  templateUrl: './delete-tax.component.html',
  styleUrl: './delete-tax.component.scss'
})
export class DeleteTaxComponent {
 
 constructor(
    public dialogRef: MatDialogRef<DeleteTaxComponent>,
    private dialog: MatDialog,
    private fb: FormBuilder,
    private toast: ToasterService,

  ) {
   
  }
}
