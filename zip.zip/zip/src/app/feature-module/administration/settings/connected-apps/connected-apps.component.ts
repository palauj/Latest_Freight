import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-connected-apps',
  templateUrl: './connected-apps.component.html',
  styleUrl: './connected-apps.component.scss'
})
export class ConnectedAppsComponent {

}
