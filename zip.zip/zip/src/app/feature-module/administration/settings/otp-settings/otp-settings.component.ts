import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-otp-settings',
  templateUrl: './otp-settings.component.html',
  styleUrl: './otp-settings.component.scss'
})
export class OtpSettingsComponent {

}
