import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder } from '@angular/forms';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';

@Component({
  selector: 'app-manage-list',
  templateUrl: './manage-list.component.html',
  styleUrl: './manage-list.component.scss'
})
export class ManageListComponent {
 constructor(
    public dialogRef: MatDialogRef<ManageListComponent>,
    private dialog: MatDialog,
    private fb: FormBuilder,
    private toast: ToasterService,

  )
  {}
}
