import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder } from '@angular/forms';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';

@Component({
  selector: 'app-view-security',
  templateUrl: './view-security.component.html',
  styleUrl: './view-security.component.scss'
})
export class ViewSecurityComponent {

 constructor(
    public dialogRef: MatDialogRef<ViewSecurityComponent>,
    private dialog: MatDialog,
    private fb: FormBuilder,
    private toast: ToasterService,

  )
  {}
}