import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
 

@Component({
  selector: 'app-changes-password',
  templateUrl: './changes-password.component.html',
  styleUrl: './changes-password.component.scss'
})
export class ChangesPasswordComponent {
  public passwordForm!: FormGroup;
  showPassword = false;
  showNewPassword = false;
  showConfirmPassword = false;
  constructor(
    public dialogRef: MatDialogRef<ChangesPasswordComponent>,
    private dialog: MatDialog,
    private fb: FormBuilder,
    private toast: ToasterService,

  ) {
   
  }
  ngOnInit(): void { 
    this.createForm();
  }
  createForm(){
    this.passwordForm = this.fb.group({
      currentPassword: ['', Validators.required],
      newPassword: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
    });
  }
  togglePassword() {
    this.showPassword = !this.showPassword;
  }

  toggleNewPassword() {
    this.showNewPassword = !this.showNewPassword;
  }

  toggleConfirmPassword() {
    this.showConfirmPassword = !this.showConfirmPassword;
  }

  onSubmit() {
    if (this.passwordForm.valid) {
      console.log('Form Submitted:', this.passwordForm.value);
    }
  }
}

