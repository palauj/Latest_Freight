import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';

@Component({
  selector: 'app-change-number',
  templateUrl: './change-number.component.html',
  styleUrl: './change-number.component.scss'
})
export class ChangeNumberComponent {
  public phoneForm!: FormGroup;
  showPassword: boolean = false;

  constructor(private fb: FormBuilder,
    public dialogRef: MatDialogRef<ChangeNumberComponent>,
    private dialog: MatDialog,
    private toast: ToasterService,) {
    
  }
  ngOnInit(): void { 
    this.createForm();
  }

  createForm(){
    this.phoneForm = this.fb.group({
      newPhone: [
        '',
        [
          Validators.required,
          Validators.pattern('^[0-9]*$'),
          Validators.maxLength(10)
        ]
      ],
      currentPhone: [
        '',
        [
          Validators.required,
          Validators.pattern('^[0-9]*$'),   
          Validators.maxLength(10)   
        ]
      ],
     
      confirmPassword: ['', Validators.required]
    });
  }

  togglePassword(): void {
    this.showPassword = !this.showPassword;
  }

  onSubmit(): void {
    if (this.phoneForm.valid) {
      console.log('Form Submitted', this.phoneForm.value);
    }
  }
}