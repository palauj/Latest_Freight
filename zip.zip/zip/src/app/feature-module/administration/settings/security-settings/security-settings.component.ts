import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
 import { MatDialog } from '@angular/material/dialog';
import { ChangesPasswordComponent } from './company/changes-password/changes-password.component';
import { ChangeNumberComponent } from './company/change-number/change-number.component';
import { ManageListComponent } from './company/manage-list/manage-list.component';
import { DeleteAccountComponent } from './company/delete-account/delete-account.component';
import { ViewSecurityComponent } from './company/view-security/view-security.component';

@Component({
  selector: 'app-security-settings',
  templateUrl: './security-settings.component.html',
  styleUrl: './security-settings.component.scss'
})
export class SecuritySettingsComponent {
  constructor(private dialog: MatDialog,){

  }
  ngOnInit(): void { }
  openChangePasswordModal(){
    const dialogRef = this.dialog.open(ChangesPasswordComponent, {
          height: '55vh',
          width: '30vw',
          disableClose: true,
          data: '',
        });
        dialogRef.afterClosed().subscribe((result: any) => {
          if (result) {
             
          }
        });
  }

  openChangeModal(){
    const dialogRef = this.dialog.open(ChangeNumberComponent, {
          height: '60vh',
          width: '30vw',
          disableClose: true,
          data: '',
        });
        dialogRef.afterClosed().subscribe((result: any) => {
          if (result) {
             
          }
        });
  }
  openManageList(){
    const dialogRef = this.dialog.open(ManageListComponent,{
      height: '60vh',
      width: '40vw',
      disableClose: true,
      data: '',
    });
    dialogRef.afterClosed().subscribe((result: any) =>{
      if(result){

      }
    });
  }
  openDeleteModal(){
    const dialogRef = this.dialog.open(DeleteAccountComponent,{
      height: '40vh',
      width: '40vw',
      disableClose: true,
      data: '',
    });
    dialogRef.afterClosed().subscribe((result: any) =>{
      if(result){

      }
    });
  }
  openViewModal(){
    const dialogRef = this.dialog.open(ViewSecurityComponent,{
      height: '60vh',
      width: '40vw',
      disableClose: true,
      data: '',
    });
    dialogRef.afterClosed().subscribe((result: any) =>{
      if(result){

      }
    });
  }
}
