import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';

@Component({
  selector: 'app-delete-account',
  templateUrl: './delete-account.component.html',
  styleUrl: './delete-account.component.scss'
})
export class DeleteAccountComponent {
  deleteAccountForm: FormGroup;
  showPassword: boolean = false;
  constructor(private fb: FormBuilder,
    public dialogRef: MatDialogRef<DeleteAccountComponent>,
    private dialog: MatDialog,
    private toast: ToasterService,
  ) {
    this.deleteAccountForm = this.fb.group({
      confirmPassword: ['', [Validators.required, Validators.minLength(6)]]
    });
  }
  createForm(){
    
  }
  togglePassword(): void {
    this.showPassword = !this.showPassword;
  }

  onSubmit(): void {
    if (this.deleteAccountForm.valid) {
      console.log('Account deletion confirmed with password:', this.deleteAccountForm.value);
      // Here you can call an API to delete the account
    }
  }
}

