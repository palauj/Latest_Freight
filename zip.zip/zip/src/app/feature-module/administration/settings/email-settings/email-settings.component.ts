import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { AddEmailComponent } from './compopnent/add-email/add-email.component';

@Component({
  selector: 'app-email-settings',
  templateUrl: './email-settings.component.html',
  styleUrls: ['./email-settings.component.scss'],
})
export class EmailSettingsComponent implements OnInit {
 
  constructor(private fb: FormBuilder, private dialog: MatDialog) {}

  ngOnInit() {
    
  }
 
  openEmailModal(){
  const dialogRef = this.dialog.open(AddEmailComponent, {
            height: '55vh',
            width: '30vw',
            disableClose: true,
            data: '',
          });
          dialogRef.afterClosed().subscribe((result: any) => {
            if (result) {
               
            }
          });
  }
}
