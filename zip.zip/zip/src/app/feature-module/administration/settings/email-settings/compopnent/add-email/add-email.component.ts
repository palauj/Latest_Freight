import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';

@Component({
  selector: 'app-add-email',
  templateUrl: './add-email.component.html',
  styleUrl: './add-email.component.scss'
})
export class AddEmailComponent {
  emailSettingsForm!: FormGroup;
constructor(private fb: FormBuilder,
    public dialogRef: MatDialogRef<AddEmailComponent>,
    private dialog: MatDialog,
    private toast: ToasterService,) {
    }
    ngOnInit(): void { 
      this.createForm();
    }
    createForm(){
      this.emailSettingsForm = this.fb.group({
        fromEmail: ['', [Validators.required, Validators.email]],
        emailPassword: ['', Validators.required],
        fromName: ['', Validators.required]
      });
    }
    onSubmit(): void {
      if (this.emailSettingsForm.valid) {
        console.log('Form Submitted', this.emailSettingsForm.value);
      }
    }
}
