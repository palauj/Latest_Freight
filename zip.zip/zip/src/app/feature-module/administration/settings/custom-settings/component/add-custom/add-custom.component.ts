import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';

@Component({
  selector: 'app-add-custom',
  templateUrl: './add-custom.component.html',
  styleUrl: './add-custom.component.scss'
})
export class AddCustomComponent implements OnInit {
  customFieldForm!: FormGroup;
  constructor(private fb: FormBuilder,
    public dialogRef: MatDialogRef<AddCustomComponent>,
    private dialog: MatDialog,
    private toast: ToasterService,
  ) {

  }

  ngOnInit(): void {
    this.cerateForm();
  }
  cerateForm() {
    this.customFieldForm = this.fb.group({
      module: ['', Validators.required],
      label: ['', Validators.required],
      defaultValue: [''],
      inputType: ['', Validators.required],
      required: ['Yes'],
      status: ['Active', Validators.required],
    });
  }
  onSubmit(): void {
    if (this.customFieldForm.valid) {
      console.log('Form Submitted', this.customFieldForm.value);
    }
  }
}
