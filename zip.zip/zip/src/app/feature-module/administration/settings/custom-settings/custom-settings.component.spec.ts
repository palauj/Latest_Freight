import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomSettingsComponent } from './custom-settings.component';

describe('CustomSettingsComponent', () => {
  let component: CustomSettingsComponent;
  let fixture: ComponentFixture<CustomSettingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CustomSettingsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CustomSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
