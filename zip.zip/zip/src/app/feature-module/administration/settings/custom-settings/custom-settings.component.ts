import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { AddCustomComponent } from './component/add-custom/add-custom.component';

@Component({
  selector: 'app-custom-settings',
  templateUrl: './custom-settings.component.html',
  styleUrl: './custom-settings.component.scss'
})
export class CustomSettingsComponent {

 constructor(private dialog: MatDialog,){
 
   }
  ngOnInit(): void {
    
  }
  openCustomFieldModal(){
     const dialogRef = this.dialog.open(AddCustomComponent,{
          height: '82vh',
          width: '35vw',
          disableClose: true,
          data: '',
        });
        dialogRef.afterClosed().subscribe((result: any) =>{
          if(result){
    
          }
        });
  }
}
