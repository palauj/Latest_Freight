import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddPaypalComponent } from './component/add-paypal/add-paypal.component';

@Component({
  selector: 'app-payment-settings',
  templateUrl: './payment-settings.component.html',
  styleUrl: './payment-settings.component.scss'
})
export class PaymentSettingsComponent {
constructor( private dialog: MatDialog){

}
openPaymentModal(){
const dialogRef = this.dialog.open(AddPaypalComponent, {
          height: '48vh',
          width: '30vw',
          disableClose: true,
          data: '',
        });
        dialogRef.afterClosed().subscribe((result: any) => {
          if (result) {
             
          }
        });
}
}
