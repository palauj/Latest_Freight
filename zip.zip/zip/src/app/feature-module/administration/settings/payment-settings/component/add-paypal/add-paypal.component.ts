import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { Validators } from 'ngx-editor';

@Component({
  selector: 'app-add-paypal',
  templateUrl: './add-paypal.component.html',
  styleUrl: './add-paypal.component.scss'
})
export class AddPaypalComponent {
  apiForm!: FormGroup;
  constructor(private fb: FormBuilder,
    public dialogRef: MatDialogRef<AddPaypalComponent>,
    private dialog: MatDialog,
    private toast: ToasterService,) {
  }
  ngOnInit(): void {
    this.createForm();
  }
  createForm() {
    this.apiForm = this.fb.group({
      clientId: ['', Validators.required],
      clientSecret: ['', Validators.required]
    });
  }
  onSubmit(): void {
    if (this.apiForm.valid) {
      console.log('Form Submitted:', this.apiForm.value);
      // Perform API call or navigation logic here
    } else {
      this.apiForm.markAllAsTouched();
    }
  }
}
