import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthService } from 'src/app/core/core.index';
import { HttpService } from 'src/app/core/services/http/http.service';

@Injectable({
  providedIn: 'root'
})
export class SettingsService {

   private http = inject(HttpService);
    private authService = inject(AuthService);
    constructor() {
    }

    public addWhiteIPAddress(data: any): Observable<any> {
      const url = '/api/WhiteListIP/SaveWhitelistIPRecord';
      return this.http.post(url, data);
    }
    public updateWhiteIPAddress(data: any): Observable<any> {
      const url = '/api/WhiteListIP/UpdateWhitelistIPRecord';
      return this.http.put(url, data);
    }
  
    public getWhiteIPAddress(): Observable<any> {
      const url = '/api/WhiteListIP/GetWhitelistIPList';
      return this.http.get(url);
    }

     
}
