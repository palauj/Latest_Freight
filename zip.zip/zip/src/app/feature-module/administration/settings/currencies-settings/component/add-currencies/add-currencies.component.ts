import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Validators } from 'ngx-editor';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';

@Component({
  selector: 'app-add-currencies',
  templateUrl: './add-currencies.component.html',
  styleUrl: './add-currencies.component.scss'
})
export class AddCurrenciesComponent {
  currencyForm!: FormGroup;
  constructor(private fb: FormBuilder,
    public dialogRef: MatDialogRef<AddCurrenciesComponent>,
    private dialog: MatDialog,
    private toast: ToasterService,
  ) {

  }

  ngOnInit(): void {
    this.createForm();
  }

  createForm() {
    this.currencyForm = this.fb.group({
      currencyName: ['', Validators.required],
      currencySymbol: ['', Validators.required],
      currencyCode: ['', Validators.required],
      currencyPosition: ['Front', Validators.required],
      status: ['', Validators.required]
    });
  }
  onSubmit(): void {
    if (this.currencyForm.valid) {
      console.log('Form Submitted:', this.currencyForm.value);
      // Perform API call or processing logic here
    } else {
      this.currencyForm.markAllAsTouched();
    }
  }

}
