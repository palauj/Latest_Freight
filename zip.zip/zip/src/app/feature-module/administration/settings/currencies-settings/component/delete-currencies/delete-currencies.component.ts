import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-delete-currencies',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './delete-currencies.component.html',
  styleUrl: './delete-currencies.component.scss'
})
export class DeleteCurrenciesComponent {

}
