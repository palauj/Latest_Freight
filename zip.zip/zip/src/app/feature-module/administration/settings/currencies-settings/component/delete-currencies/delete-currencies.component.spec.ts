import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteCurrenciesComponent } from './delete-currencies.component';

describe('DeleteCurrenciesComponent', () => {
  let component: DeleteCurrenciesComponent;
  let fixture: ComponentFixture<DeleteCurrenciesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DeleteCurrenciesComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DeleteCurrenciesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
