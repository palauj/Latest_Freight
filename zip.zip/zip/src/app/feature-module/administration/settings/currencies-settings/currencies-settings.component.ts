import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { AddCurrenciesComponent } from './component/add-currencies/add-currencies.component';

@Component({
  selector: 'app-currencies-settings',
  templateUrl: './currencies-settings.component.html',
  styleUrl: './currencies-settings.component.scss'
})
export class CurrenciesSettingsComponent {

  constructor(private dialog: MatDialog,) {

  }
  openCurrenciesModal() {
    const dialogRef = this.dialog.open(AddCurrenciesComponent, {
      height: '72vh',
      width: '30vw',
      disableClose: true,
      data: '',
    });
    dialogRef.afterClosed().subscribe((result: any) => {
      if (result) {

      }
    });
  }
}
